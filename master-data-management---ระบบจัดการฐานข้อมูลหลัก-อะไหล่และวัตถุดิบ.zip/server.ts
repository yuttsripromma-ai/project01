import express from "express";
import cookieParser from "cookie-parser";
import path from "path";
import { google } from "googleapis";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(cookieParser());

  // OAuth helper function
  const getOAuth2Client = (req: express.Request) => {
    const redirectUri =
      process.env.REDIRECT_URI ||
      process.env.GOOGLE_REDIRECT_URI ||
      `${req.protocol}://${req.get("host")}/api/auth/google/callback`;
    const clientId = process.env.CLIENT_ID || process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.CLIENT_SECRET || process.env.GOOGLE_CLIENT_SECRET;
    return new google.auth.OAuth2(clientId, clientSecret, redirectUri);
  };

  const getAuthenticatedDriveClient = (req: express.Request) => {
    const tokensCookie = req.cookies.google_tokens;
    if (!tokensCookie) {
      throw new Error("NOT_AUTHENTICATED");
    }
    const tokens = typeof tokensCookie === "string" ? JSON.parse(tokensCookie) : tokensCookie;
    const oauth2Client = getOAuth2Client(req);
    oauth2Client.setCredentials(tokens);
    return google.drive({ version: "v3", auth: oauth2Client });
  };

  const getAuthenticatedSheetsClient = (req: express.Request) => {
    const tokensCookie = req.cookies.google_tokens;
    if (!tokensCookie) {
      throw new Error("NOT_AUTHENTICATED");
    }
    const tokens = typeof tokensCookie === "string" ? JSON.parse(tokensCookie) : tokensCookie;
    const oauth2Client = getOAuth2Client(req);
    oauth2Client.setCredentials(tokens);
    return google.sheets({ version: "v4", auth: oauth2Client });
  };

  // API Routes
  app.get("/api/auth/google/url", (req, res) => {
    try {
      const oauth2Client = getOAuth2Client(req);
      const url = oauth2Client.generateAuthUrl({
        access_type: "offline",
        prompt: "consent",
        scope: [
          "https://www.googleapis.com/auth/drive.file",
          "https://www.googleapis.com/auth/spreadsheets",
          "https://www.googleapis.com/auth/userinfo.email",
          "https://www.googleapis.com/auth/userinfo.profile",
        ],
      });
      res.json({ url });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/auth/google/callback", async (req, res) => {
    const code = req.query.code as string;
    if (!code) {
      return res.status(400).send("No authorization code provided.");
    }
    try {
      const oauth2Client = getOAuth2Client(req);
      const { tokens } = await oauth2Client.getToken(code);
      res.cookie("google_tokens", JSON.stringify(tokens), {
        httpOnly: true,
        secure: true,
        sameSite: "none",
        maxAge: 30 * 24 * 60 * 60 * 1000,
      });

      res.send(`
        <!DOCTYPE html>
        <html>
        <head><title>Authentication Complete</title></head>
        <body style="font-family: sans-serif; text-align: center; padding: 40px; background: #0f172a; color: white;">
          <h2>Google Drive Connected Successfully!</h2>
          <p>Window will close automatically...</p>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
        </body>
        </html>
      `);
    } catch (err: any) {
      console.error("Error exchanging code for token", err);
      res.status(500).send("Authentication failed: " + err.message);
    }
  });

  app.get("/api/auth/status", async (req, res) => {
    try {
      const tokensCookie = req.cookies.google_tokens;
      if (!tokensCookie) {
        return res.json({ authenticated: false });
      }
      const tokens = typeof tokensCookie === "string" ? JSON.parse(tokensCookie) : tokensCookie;
      const oauth2Client = getOAuth2Client(req);
      oauth2Client.setCredentials(tokens);

      const oauth2 = google.oauth2({ version: "v2", auth: oauth2Client });
      const userInfo = await oauth2.userinfo.get();

      res.json({
        authenticated: true,
        user: {
          email: userInfo.data.email,
          name: userInfo.data.name,
          picture: userInfo.data.picture,
        },
      });
    } catch (err) {
      res.json({ authenticated: false });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    res.clearCookie("google_tokens", {
      httpOnly: true,
      secure: true,
      sameSite: "none",
    });
    res.json({ success: true });
  });

  // Google Drive Endpoints
  app.get("/api/drive/files", async (req, res) => {
    try {
      const drive = getAuthenticatedDriveClient(req);
      const response = await drive.files.list({
        q: "name = 'mdm_database.json' and trashed = false",
        fields: "files(id, name, modifiedTime, size, webViewLink)",
      });
      res.json({ files: response.data.files || [] });
    } catch (err: any) {
      res.status(err.message === "NOT_AUTHENTICATED" ? 401 : 500).json({ error: err.message });
    }
  });

  app.post("/api/drive/sync", async (req, res) => {
    try {
      const drive = getAuthenticatedDriveClient(req);
      const data = req.body.data;
      if (!data) {
        return res.status(400).json({ error: "No data provided" });
      }

      // Check if mdm_database.json exists
      const existing = await drive.files.list({
        q: "name = 'mdm_database.json' and trashed = false",
        fields: "files(id, name, modifiedTime)",
      });

      const jsonContent = JSON.stringify(data, null, 2);
      let fileId = "";
      let modifiedTime = "";

      if (existing.data.files && existing.data.files.length > 0) {
        fileId = existing.data.files[0].id!;
        const updated = await drive.files.update({
          fileId: fileId,
          media: {
            mimeType: "application/json",
            body: jsonContent,
          },
          fields: "id, modifiedTime",
        });
        modifiedTime = updated.data.modifiedTime || new Date().toISOString();
      } else {
        const created = await drive.files.create({
          requestBody: {
            name: "mdm_database.json",
            mimeType: "application/json",
            description: "MDM Inventory Master Data Database Backup",
          },
          media: {
            mimeType: "application/json",
            body: jsonContent,
          },
          fields: "id, modifiedTime",
        });
        fileId = created.data.id!;
        modifiedTime = created.data.modifiedTime || new Date().toISOString();
      }

      res.json({ success: true, fileId, modifiedTime });
    } catch (err: any) {
      console.error("Drive sync error:", err);
      res.status(err.message === "NOT_AUTHENTICATED" ? 401 : 500).json({ error: err.message });
    }
  });

  app.get("/api/drive/load", async (req, res) => {
    try {
      const drive = getAuthenticatedDriveClient(req);
      const existing = await drive.files.list({
        q: "name = 'mdm_database.json' and trashed = false",
        fields: "files(id, name, modifiedTime)",
      });

      if (!existing.data.files || existing.data.files.length === 0) {
        return res.status(404).json({ error: "ไม่พบไฟล์สำรอง mdm_database.json ใน Google Drive" });
      }

      const fileId = existing.data.files[0].id!;
      const fileRes = await drive.files.get(
        { fileId: fileId, alt: "media" },
        { responseType: "json" }
      );

      res.json({
        success: true,
        data: fileRes.data,
        modifiedTime: existing.data.files[0].modifiedTime,
      });
    } catch (err: any) {
      console.error("Drive load error:", err);
      res.status(err.message === "NOT_AUTHENTICATED" ? 401 : 500).json({ error: err.message });
    }
  });

  // Google Sheets Endpoints
  app.get("/api/sheets/list", async (req, res) => {
    try {
      const drive = getAuthenticatedDriveClient(req);
      const response = await drive.files.list({
        q: "mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false",
        fields: "files(id, name, modifiedTime, webViewLink)",
        orderBy: "modifiedTime desc",
      });
      res.json({ spreadsheets: response.data.files || [] });
    } catch (err: any) {
      res.status(err.message === "NOT_AUTHENTICATED" ? 401 : 500).json({ error: err.message });
    }
  });

  app.post("/api/sheets/create", async (req, res) => {
    try {
      const sheets = getAuthenticatedSheetsClient(req);
      const title = req.body.title || `MDM_ERP_Database_${new Date().toISOString().slice(0, 10)}`;

      const spreadsheet = await sheets.spreadsheets.create({
        requestBody: {
          properties: { title },
          sheets: [
            { properties: { title: "RawMaterials" } },
            { properties: { title: "FinishedGoods" } },
            { properties: { title: "ProductionOrders" } },
            { properties: { title: "BOM" } },
            { properties: { title: "Shipments" } },
            { properties: { title: "InventoryLogs" } },
          ],
        },
      });

      const spreadsheetId = spreadsheet.data.spreadsheetId;
      const spreadsheetUrl = spreadsheet.data.spreadsheetUrl;

      res.json({ success: true, spreadsheetId, spreadsheetUrl, title });
    } catch (err: any) {
      console.error("Sheets create error:", err);
      res.status(err.message === "NOT_AUTHENTICATED" ? 401 : 500).json({ error: err.message });
    }
  });

  app.post("/api/sheets/sync", async (req, res) => {
    try {
      const sheets = getAuthenticatedSheetsClient(req);
      const { spreadsheetId, data } = req.body;

      if (!spreadsheetId) {
        return res.status(400).json({ error: "No spreadsheetId provided" });
      }

      // 1. Raw Materials Tab
      const rawMaterialsRows = [
        ["ID", "SKU/Code", "NameTH", "Type", "Category", "UOM", "Stock", "ReorderPoint", "UnitPrice", "Location"],
        ...(data.items || [])
          .filter((i: any) => i.type !== 'FINISHED_GOOD')
          .map((i: any) => [
            i.id, i.code, i.nameTh, i.type, i.categoryId, i.uomId, i.currentStock, i.reorderPoint, i.unitPrice, i.locationId || ''
          ])
      ];

      // 2. Finished Goods Tab
      const finishedGoodsRows = [
        ["ID", "SKU/Code", "NameTH", "Type", "Category", "UOM", "Stock", "ReorderPoint", "UnitPrice", "Location"],
        ...(data.items || [])
          .filter((i: any) => i.type === 'FINISHED_GOOD')
          .map((i: any) => [
            i.id, i.code, i.nameTh, i.type, i.categoryId, i.uomId, i.currentStock, i.reorderPoint, i.unitPrice, i.locationId || ''
          ])
      ];

      // 3. Production Orders Tab
      const productionOrderRows = [
        ["OrderNo", "TargetSKU", "TargetName", "TargetQty", "ProducedQty", "Status", "StartDate", "TargetDate", "CompletedDate", "Notes"],
        ...(data.productionOrders || []).map((p: any) => [
          p.orderNo, p.targetSku, p.targetName, p.targetQty, p.producedQty, p.status, p.startDate, p.targetDate, p.completedDate || '', p.notes || ''
        ])
      ];

      // 4. BOM Tab
      const bomRows = [
        ["FinishedGoodSKU", "RawMaterialSKU", "RawMaterialName", "RequiredQtyPerUnit"],
        ...(data.boms || []).map((b: any) => [
          b.finishedGoodSku, b.rawMaterialSku, b.rawMaterialName, b.requiredQtyPerUnit
        ])
      ];

      // 5. Shipments Tab
      const shipmentRows = [
        ["ShipmentNo", "CustomerName", "Address", "FinishedGoodSKU", "Quantity", "Status", "TrackingNo", "VehicleNo", "DispatchDate", "DeliveryDate"],
        ...(data.shipments || []).map((s: any) => [
          s.shipmentNo, s.customerName, s.address, s.finishedGoodSku, s.quantity, s.status, s.trackingNo || '', s.vehicleNo || '', s.dispatchDate || '', s.deliveryDate || ''
        ])
      ];

      // 6. Inventory Logs
      const logRows = [
        ["ID", "Timestamp", "Action", "ItemCode", "ItemName", "QuantityChange", "BalanceAfter", "Performer", "Notes"],
        ...(data.logs || []).slice(0, 500).map((l: any) => [
          l.id, l.timestamp, l.action, l.itemCode, l.itemName, l.quantityChange, l.balanceAfter, l.performer, l.notes || ''
        ])
      ];

      // Batch update ranges
      await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId,
        requestBody: {
          valueInputOption: "USER_ENTERED",
          data: [
            { range: "RawMaterials!A1", values: rawMaterialsRows },
            { range: "FinishedGoods!A1", values: finishedGoodsRows },
            { range: "ProductionOrders!A1", values: productionOrderRows },
            { range: "BOM!A1", values: bomRows },
            { range: "Shipments!A1", values: shipmentRows },
            { range: "InventoryLogs!A1", values: logRows },
          ]
        }
      });

      res.json({ success: true, spreadsheetId, updatedAt: new Date().toISOString() });
    } catch (err: any) {
      console.error("Sheets sync error:", err);
      res.status(err.message === "NOT_AUTHENTICATED" ? 401 : 500).json({ error: err.message });
    }
  });

  app.post("/api/sheets/load", async (req, res) => {
    try {
      const sheets = getAuthenticatedSheetsClient(req);
      const { spreadsheetId } = req.body;

      if (!spreadsheetId) {
        return res.status(400).json({ error: "No spreadsheetId provided" });
      }

      const response = await sheets.spreadsheets.values.batchGet({
        spreadsheetId,
        ranges: [
          "RawMaterials!A2:J1000",
          "FinishedGoods!A2:J1000",
          "ProductionOrders!A2:J1000",
          "BOM!A2:D1000",
          "Shipments!A2:J1000",
          "InventoryLogs!A2:I1000",
        ]
      });

      const valueRanges = response.data.valueRanges || [];

      // Parse Raw Materials
      const rawMaterials = (valueRanges[0]?.values || []).map((row: any) => ({
        id: row[0],
        code: row[1],
        nameTh: row[2],
        type: row[3] || 'RAW_MATERIAL',
        categoryId: row[4] || 'CAT-01',
        uomId: row[5] || 'UOM-01',
        currentStock: Number(row[6]) || 0,
        reorderPoint: Number(row[7]) || 10,
        unitPrice: Number(row[8]) || 0,
        locationId: row[9] || '',
      }));

      // Parse Finished Goods
      const finishedGoods = (valueRanges[1]?.values || []).map((row: any) => ({
        id: row[0],
        code: row[1],
        nameTh: row[2],
        type: 'FINISHED_GOOD',
        categoryId: row[4] || 'CAT-01',
        uomId: row[5] || 'UOM-01',
        currentStock: Number(row[6]) || 0,
        reorderPoint: Number(row[7]) || 10,
        unitPrice: Number(row[8]) || 0,
        locationId: row[9] || '',
      }));

      // Parse Production Orders
      const productionOrders = (valueRanges[2]?.values || []).map((row: any) => ({
        orderNo: row[0],
        targetSku: row[1],
        targetName: row[2],
        targetQty: Number(row[3]) || 0,
        producedQty: Number(row[4]) || 0,
        status: row[5] || 'DRAFT',
        startDate: row[6] || '',
        targetDate: row[7] || '',
        completedDate: row[8] || '',
        notes: row[9] || '',
      }));

      // Parse BOM
      const boms = (valueRanges[3]?.values || []).map((row: any) => ({
        finishedGoodSku: row[0],
        rawMaterialSku: row[1],
        rawMaterialName: row[2],
        requiredQtyPerUnit: Number(row[3]) || 1,
      }));

      // Parse Shipments
      const shipments = (valueRanges[4]?.values || []).map((row: any) => ({
        shipmentNo: row[0],
        customerName: row[1],
        address: row[2],
        finishedGoodSku: row[3],
        quantity: Number(row[4]) || 0,
        status: row[5] || 'PENDING',
        trackingNo: row[6] || '',
        vehicleNo: row[7] || '',
        dispatchDate: row[8] || '',
        deliveryDate: row[9] || '',
      }));

      // Parse Logs
      const logs = (valueRanges[5]?.values || []).map((row: any) => ({
        id: row[0],
        timestamp: row[1],
        action: row[2],
        itemCode: row[3],
        itemName: row[4],
        quantityChange: Number(row[5]) || 0,
        balanceAfter: Number(row[6]) || 0,
        performer: row[7] || 'System',
        notes: row[8] || '',
      }));

      res.json({
        success: true,
        data: {
          items: [...rawMaterials, ...finishedGoods],
          productionOrders,
          boms,
          shipments,
          logs,
        }
      });
    } catch (err: any) {
      console.error("Sheets load error:", err);
      res.status(err.message === "NOT_AUTHENTICATED" ? 401 : 500).json({ error: err.message });
    }
  });

  // Vite middleware for dev or static serving for prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
