export type ItemType = 'SPARE_PART' | 'RAW_MATERIAL' | 'CONSUMABLE' | 'TOOL' | 'FINISHED_GOOD';

export type MasterStatus = 'ACTIVE' | 'INACTIVE';

export interface ProductionOrder {
  id: string;
  orderNo: string; // e.g. 'PO-2026-001'
  targetSku: string;
  targetName: string;
  targetQty: number;
  producedQty: number;
  status: 'DRAFT' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  startDate: string;
  targetDate: string;
  completedDate?: string;
  notes?: string;
  createdAt: string;
}

export interface BOMItem {
  id: string;
  finishedGoodSku: string;
  rawMaterialSku: string;
  rawMaterialName: string;
  requiredQtyPerUnit: number;
}

export interface Shipment {
  id: string;
  shipmentNo: string; // e.g. 'SHP-2026-001'
  customerName: string;
  address: string;
  finishedGoodSku: string;
  finishedGoodName: string;
  quantity: number;
  status: 'PENDING' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED';
  trackingNo?: string;
  vehicleNo?: string;
  dispatchDate?: string;
  deliveryDate?: string;
  createdAt: string;
}

export interface UomConversion {
  targetUomId: string; // e.g. 'uom-pcs'
  factor: number; // e.g. 1 BOX = 10 PCS (factor = 10)
  description?: string;
}

export interface UOM {
  id: string;
  code: string; // e.g. 'PCS', 'BOX', 'KG'
  nameTh: string; // e.g. 'ชิ้น', 'กล่อง', 'กิโลกรัม'
  nameEn: string;
  symbol: string;
  description?: string;
  conversions: UomConversion[];
  status: MasterStatus;
  createdAt: string;
}

export interface Category {
  id: string;
  code: string; // e.g. 'ELEC', 'MECH'
  nameTh: string;
  nameEn: string;
  parentId?: string | null;
  color: string; // tailwind color class or hex
  description?: string;
  status: MasterStatus;
  createdAt: string;
}

export type StorageType = 'WAREHOUSE' | 'RACK' | 'SHELF' | 'BIN' | 'COLD_STORAGE' | 'HAZARDOUS';

export interface StorageLocation {
  id: string;
  code: string; // e.g. 'WH1-A1-S2-B01'
  name: string; // e.g. 'คลังหลัก - โซน A1 - ชั้น 2 - ช่อง 01'
  warehouse: string; // e.g. 'คลังสินค้าหลัก (Warehouse 1)'
  zone: string; // e.g. 'Zone A'
  rack: string; // e.g. 'Rack 1'
  shelf: string; // e.g. 'Shelf 2'
  bin: string; // e.g. 'Bin 01'
  type: StorageType;
  temperatureCondition?: string; // e.g. '25°C', '18°C Cold Room'
  maxCapacityItems: number;
  currentCapacityItems?: number;
  description?: string;
  status: MasterStatus;
  createdAt: string;
}

export interface Supplier {
  id: string;
  code: string; // e.g. 'SUP-001'
  companyName: string; // e.g. 'บริษัท ไทยฮาร์ดแวร์ แอนด์ ทูลส์ จำกัด'
  taxId: string;
  contactPerson: string;
  phone: string;
  email: string;
  lineId?: string;
  address: string;
  paymentTerm: string; // e.g. 'Credit 30 Days', 'Cash on Delivery'
  leadTimeDays: number; // e.g. 7 days
  rating: number; // 1 to 5
  notes?: string;
  status: MasterStatus;
  createdAt: string;
}

export interface MasterItem {
  id: string;
  code: string; // SKU / Item Code e.g. 'PART-2026-001'
  nameTh: string; // ชื่อภาษาไทย
  nameEn: string; // ชื่อภาษาอังกฤษ
  type: ItemType;
  categoryId: string; // Ref to Category
  uomId: string; // Ref to Primary UOM
  secondaryUomId?: string; // Ref to Secondary UOM
  locationId: string; // Ref to Location
  supplierId: string; // Ref to Primary Supplier
  secondarySupplierId?: string; // Ref to Secondary Supplier
  
  // Inventory Control Parameters
  minStock: number;
  maxStock: number;
  reorderPoint: number;
  currentStock: number;
  
  // Financial & Commercial
  unitCost: number; // Price in THB
  sellingPrice?: number;
  
  // Attributes
  brand?: string;
  modelNumber?: string;
  barcode?: string;
  specifications?: string; // e.g. 'Size: 10mm, Material: Stainless Steel 304'
  imageUrl?: string;
  
  status: MasterStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'IMPORT' | 'EXPORT';
  entityType: 'ITEM' | 'UOM' | 'CATEGORY' | 'LOCATION' | 'SUPPLIER';
  entityName: string;
  details: string;
}

export type ActiveTab = 
  | 'dashboard' 
  | 'raw_materials' 
  | 'production' 
  | 'finished_goods' 
  | 'shipping' 
  | 'items' 
  | 'google_sheets' 
  | 'uom' 
  | 'categories' 
  | 'locations' 
  | 'suppliers' 
  | 'shelf_map' 
  | 'barcode';
