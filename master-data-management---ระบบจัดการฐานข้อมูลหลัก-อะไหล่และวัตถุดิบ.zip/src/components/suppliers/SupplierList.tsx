import React from 'react';
import { MasterItem, Supplier } from '../../types';
import { Truck, Plus, Edit3, Trash2, Phone, Mail, MapPin, Star, Box, CheckCircle2, Clock } from 'lucide-react';

interface SupplierListProps {
  suppliers: Supplier[];
  items: MasterItem[];
  onAddSupplier: () => void;
  onEditSupplier: (sup: Supplier) => void;
  onDeleteSupplier: (supId: string) => void;
}

export const SupplierList: React.FC<SupplierListProps> = ({
  suppliers,
  items,
  onAddSupplier,
  onEditSupplier,
  onDeleteSupplier,
}) => {
  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Truck className="w-5 h-5 text-purple-400" />
            <span>ตารางข้อมูลผู้จัดจำหน่าย (Suppliers / Vendors Master)</span>
          </h2>
          <p className="text-xs text-slate-400">
            บริหารรายชื่อบริษัทคู่ค้า เบอร์ติดต่อ เครดิตเทอม และระยะเวลาการจัดส่งสินค้า (Lead Time)
          </p>
        </div>

        <button
          onClick={onAddSupplier}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ เพิ่มผู้จัดจำหน่ายใหม่</span>
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        {suppliers.map((sup) => {
          const suppliedCount = items.filter((i) => i.supplierId === sup.id).length;

          return (
            <div
              key={sup.id}
              className="bg-slate-800/90 border border-slate-700/80 hover:border-purple-500/50 rounded-2xl p-5 shadow-sm space-y-3 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2.5 py-1 bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-lg text-xs font-mono font-bold">
                    {sup.code}
                  </span>
                  
                  <div className="flex items-center gap-2">
                    {/* Stars */}
                    <div className="flex items-center text-amber-400">
                      {[...Array(5)].map((_, idx) => (
                        <Star
                          key={idx}
                          className={`w-3.5 h-3.5 ${idx < sup.rating ? 'fill-current' : 'text-slate-600'}`}
                        />
                      ))}
                    </div>
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      <CheckCircle2 className="w-3 h-3" /> Active
                    </span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-white leading-snug">{sup.companyName}</h3>
                
                {sup.taxId && (
                  <p className="text-[11px] font-mono text-slate-400">เลขผู้เสียภาษี: {sup.taxId}</p>
                )}

                {/* Contact Info Box */}
                <div className="mt-3 p-3 bg-slate-900/60 rounded-xl border border-slate-700/60 space-y-1.5 text-xs">
                  {sup.contactPerson && (
                    <div className="text-slate-300 font-semibold flex items-center justify-between">
                      <span>ผู้ติดต่อ: {sup.contactPerson}</span>
                      {sup.lineId && <span className="text-[10px] text-emerald-400 font-mono">Line: {sup.lineId}</span>}
                    </div>
                  )}

                  <div className="flex items-center justify-between text-slate-300">
                    <a
                      href={`tel:${sup.phone}`}
                      className="inline-flex items-center gap-1 text-blue-400 hover:underline font-mono"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>{sup.phone}</span>
                    </a>

                    {sup.email && (
                      <a
                        href={`mailto:${sup.email}`}
                        className="inline-flex items-center gap-1 text-slate-400 hover:text-white truncate max-w-[180px]"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>{sup.email}</span>
                      </a>
                    )}
                  </div>

                  {sup.address && (
                    <p className="text-[11px] text-slate-400 pt-1 border-t border-slate-800 line-clamp-2">
                      <MapPin className="w-3 h-3 inline mr-1 text-slate-500" />
                      {sup.address}
                    </p>
                  )}
                </div>

                {/* Terms */}
                <div className="mt-3 flex items-center justify-between text-xs text-slate-300">
                  <span className="bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-700 text-purple-300 font-medium">
                    เครดิต: {sup.paymentTerm}
                  </span>
                  <span className="flex items-center gap-1 text-slate-400 font-medium">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    ระยะเวลาส่งมอบ: <strong className="text-white">{sup.leadTimeDays} วัน</strong>
                  </span>
                </div>

              </div>

              {/* Footer */}
              <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Box className="w-3.5 h-3.5 text-purple-400" />
                  จ่ายอะไหล่/วัตถุดิบ <strong className="text-white">{suppliedCount}</strong> SKU
                </span>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => onEditSupplier(sup)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-blue-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="แก้ไขข้อมูลผู้จัดจำหน่าย"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteSupplier(sup.id)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-rose-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="ลบผู้จัดจำหน่าย"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
