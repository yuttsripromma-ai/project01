import React, { useState, useEffect } from 'react';
import { MasterStatus, Supplier } from '../../types';
import { X, Save, Truck, Star } from 'lucide-react';

interface SupplierModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (supplier: Supplier) => void;
  editingSupplier: Supplier | null;
}

export const SupplierModal: React.FC<SupplierModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingSupplier,
}) => {
  const [formData, setFormData] = useState<Partial<Supplier>>({
    code: '',
    companyName: '',
    taxId: '',
    contactPerson: '',
    phone: '',
    email: '',
    lineId: '',
    address: '',
    paymentTerm: 'Credit 30 Days',
    leadTimeDays: 3,
    rating: 5,
    notes: '',
    status: 'ACTIVE',
  });

  useEffect(() => {
    if (editingSupplier) {
      setFormData(editingSupplier);
    } else {
      setFormData({
        code: 'SUP-' + Math.floor(100 + Math.random() * 900),
        companyName: '',
        taxId: '',
        contactPerson: '',
        phone: '',
        email: '',
        lineId: '',
        address: '',
        paymentTerm: 'Credit 30 Days',
        leadTimeDays: 3,
        rating: 5,
        notes: '',
        status: 'ACTIVE',
      });
    }
  }, [editingSupplier, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || !formData.companyName || !formData.phone) {
      alert('กรุณากรอกรหัสผู้จัดจำหน่าย ชื่อบริษัท และเบอร์โทรศัพท์ติดต่อให้ครบถ้วน');
      return;
    }

    const finalSup: Supplier = {
      id: editingSupplier ? editingSupplier.id : 'sup-' + Date.now(),
      code: formData.code.toUpperCase().trim(),
      companyName: formData.companyName.trim(),
      taxId: formData.taxId?.trim() || '',
      contactPerson: formData.contactPerson?.trim() || '',
      phone: formData.phone.trim(),
      email: formData.email?.trim() || '',
      lineId: formData.lineId?.trim() || '',
      address: formData.address?.trim() || '',
      paymentTerm: formData.paymentTerm || 'Credit 30 Days',
      leadTimeDays: Number(formData.leadTimeDays) || 3,
      rating: Number(formData.rating) || 5,
      notes: formData.notes || '',
      status: (formData.status as MasterStatus) || 'ACTIVE',
      createdAt: editingSupplier ? editingSupplier.createdAt : new Date().toISOString(),
    };

    onSave(finalSup);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden my-8">
        
        <div className="px-6 py-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-purple-400" />
            <h2 className="text-base font-bold text-white">
              {editingSupplier ? 'แก้ไขข้อมูลผู้จัดจำหน่าย (Edit Supplier)' : 'เพิ่มผู้จัดจำหน่ายใหม่ (Add Supplier)'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                รหัสผู้จัดจำหน่าย <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                placeholder="เช่น SUP-001"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white uppercase font-mono focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                เลขประจำตัวผู้เสียภาษี (Tax ID)
              </label>
              <input
                type="text"
                value={formData.taxId}
                onChange={(e) => setFormData({ ...formData, taxId: e.target.value })}
                placeholder="เช่น 0105558012345"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              ชื่อบริษัท / ร้านค้า (Company Name) <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.companyName}
              onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
              placeholder="เช่น บริษัท ไทยฮาร์ดแวร์ แอนด์ ทูลส์ จำกัด"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ผู้ติดต่อ (Contact Person)
              </label>
              <input
                type="text"
                value={formData.contactPerson}
                onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                placeholder="เช่น คุณสมชาย"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                เบอร์โทรศัพท์ <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="เช่น 02-712-3456"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                อีเมล (Email)
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="sales@company.com"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Line ID / โซเชียล</label>
              <input
                type="text"
                value={formData.lineId}
                onChange={(e) => setFormData({ ...formData, lineId: e.target.value })}
                placeholder="@company"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">เงื่อนไขการชำระเงิน (Credit Term)</label>
              <select
                value={formData.paymentTerm}
                onChange={(e) => setFormData({ ...formData, paymentTerm: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="Cash On Delivery">เงินสดชำระเมื่อส่งสินค้า (COD)</option>
                <option value="Credit 15 Days">เครดิต 15 วัน</option>
                <option value="Credit 30 Days">เครดิต 30 วัน</option>
                <option value="Credit 60 Days">เครดิต 60 วัน</option>
                <option value="Credit 90 Days">เครดิต 90 วัน</option>
                <option value="Advance Payment">โอนชำระเงินล่วงหน้า</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">ระยะเวลาส่งมอบ (Lead Time วัน)</label>
              <input
                type="number"
                min="1"
                value={formData.leadTimeDays}
                onChange={(e) => setFormData({ ...formData, leadTimeDays: Number(e.target.value) })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              คะแนนประเมินคุณภาพผู้จัดจำหน่าย (Rating 1-5 Stars)
            </label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setFormData({ ...formData, rating: star })}
                  className={`p-1.5 rounded-lg border transition cursor-pointer ${
                    (formData.rating || 5) >= star
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                      : 'bg-slate-800 text-slate-600 border-slate-700'
                  }`}
                >
                  <Star className="w-5 h-5 fill-current" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">ที่อยู่บริษัท</label>
            <textarea
              rows={2}
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              placeholder="ที่อยู่สำหรับออกใบกำกับภาษีและจัดส่ง..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow-lg transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>บันทึกผู้จัดจำหน่าย</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
