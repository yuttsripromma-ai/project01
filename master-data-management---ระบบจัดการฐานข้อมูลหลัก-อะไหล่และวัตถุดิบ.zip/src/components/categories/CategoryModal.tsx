import React, { useState, useEffect } from 'react';
import { Category, MasterStatus } from '../../types';
import { X, Save, FolderTree } from 'lucide-react';

interface CategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (category: Category) => void;
  editingCategory: Category | null;
  allCategories: Category[];
}

const COLOR_OPTIONS = [
  { name: 'Amber / Gold', class: 'bg-amber-100 text-amber-800 border-amber-300' },
  { name: 'Blue / Indigo', class: 'bg-blue-100 text-blue-800 border-blue-300' },
  { name: 'Emerald / Green', class: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
  { name: 'Purple / Violet', class: 'bg-purple-100 text-purple-800 border-purple-300' },
  { name: 'Slate / Gray', class: 'bg-slate-100 text-slate-800 border-slate-300' },
  { name: 'Orange / Coral', class: 'bg-orange-100 text-orange-800 border-orange-300' },
  { name: 'Rose / Pink', class: 'bg-rose-100 text-rose-800 border-rose-300' },
  { name: 'Cyan / Teal', class: 'bg-cyan-100 text-cyan-800 border-cyan-300' },
];

export const CategoryModal: React.FC<CategoryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingCategory,
  allCategories,
}) => {
  const [formData, setFormData] = useState<Partial<Category>>({
    code: '',
    nameTh: '',
    nameEn: '',
    color: COLOR_OPTIONS[0].class,
    description: '',
    status: 'ACTIVE',
  });

  useEffect(() => {
    if (editingCategory) {
      setFormData(editingCategory);
    } else {
      setFormData({
        code: '',
        nameTh: '',
        nameEn: '',
        color: COLOR_OPTIONS[0].class,
        description: '',
        status: 'ACTIVE',
      });
    }
  }, [editingCategory, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || !formData.nameTh) {
      alert('กรุณากรอกรหัสหมวดหมู่และชื่อภาษาไทยให้ครบถ้วน');
      return;
    }

    const finalCat: Category = {
      id: editingCategory ? editingCategory.id : 'cat-' + Date.now(),
      code: formData.code.toUpperCase().trim(),
      nameTh: formData.nameTh.trim(),
      nameEn: formData.nameEn?.trim() || '',
      parentId: formData.parentId || null,
      color: formData.color || COLOR_OPTIONS[0].class,
      description: formData.description || '',
      status: (formData.status as MasterStatus) || 'ACTIVE',
      createdAt: editingCategory ? editingCategory.createdAt : new Date().toISOString(),
    };

    onSave(finalCat);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden my-8">
        
        <div className="px-6 py-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FolderTree className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-white">
              {editingCategory ? 'แก้ไขหมวดหมู่ (Edit Category)' : 'เพิ่มหมวดหมู่ใหม่ (Add Category)'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                รหัสหมวดหมู่ (Category Code) <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                placeholder="เช่น ELEC, MECH, CHEM"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white uppercase font-mono focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                หมวดหมู่หลัก (Parent Category)
              </label>
              <select
                value={formData.parentId || ''}
                onChange={(e) => setFormData({ ...formData, parentId: e.target.value || null })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="">-- หมวดหมู่ระดับบนสุด (Root) --</option>
                {allCategories
                  .filter((c) => c.id !== editingCategory?.id)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nameTh}
                    </option>
                  ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              ชื่อหมวดหมู่ <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.nameTh}
              onChange={(e) => setFormData({ ...formData, nameTh: e.target.value })}
              placeholder="เช่น อุปกรณ์ไฟฟ้า"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          {/* Color Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">ธีมสีแท็กหมวดหมู่ (Badge Color)</label>
            <div className="grid grid-cols-4 gap-2">
              {COLOR_OPTIONS.map((c, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setFormData({ ...formData, color: c.class })}
                  className={`p-2 rounded-lg text-center text-xs font-bold border transition cursor-pointer ${c.class} ${
                    formData.color === c.class ? 'ring-2 ring-white scale-105' : 'opacity-80 hover:opacity-100'
                  }`}
                >
                  {c.name.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">คำอธิบายหมวดหมู่</label>
            <textarea
              rows={2}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="คำอธิบายสโคปของสินค้าหรือวัตถุดิบในหมวดหมู่นี้..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow-lg transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>บันทึกหมวดหมู่</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
