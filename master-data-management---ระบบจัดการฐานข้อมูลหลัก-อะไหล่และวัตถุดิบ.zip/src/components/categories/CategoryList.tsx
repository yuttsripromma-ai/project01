import React from 'react';
import { Category, MasterItem } from '../../types';
import { FolderTree, Plus, Edit3, Trash2, Box, CheckCircle2 } from 'lucide-react';

interface CategoryListProps {
  categories: Category[];
  items: MasterItem[];
  onAddCategory: () => void;
  onEditCategory: (cat: Category) => void;
  onDeleteCategory: (catId: string) => void;
}

export const CategoryList: React.FC<CategoryListProps> = ({
  categories,
  items,
  onAddCategory,
  onEditCategory,
  onDeleteCategory,
}) => {
  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FolderTree className="w-5 h-5 text-amber-400" />
            <span>ตารางข้อมูลหมวดหมู่สินค้าและวัตถุดิบ (Categories Master)</span>
          </h2>
          <p className="text-xs text-slate-400">
            จำแนกกลุ่มอะไหล่ เครื่องมือ และวัตถุดิบเพื่อความสะดวกในการจัดหมวดหมู่และออกรายงาน
          </p>
        </div>

        <button
          onClick={onAddCategory}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ เพิ่มหมวดหมู่ใหม่</span>
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((cat) => {
          const skuCount = items.filter((i) => i.categoryId === cat.id).length;
          const parent = categories.find((c) => c.id === cat.parentId);

          return (
            <div
              key={cat.id}
              className="bg-slate-800/90 border border-slate-700/80 hover:border-amber-500/50 rounded-2xl p-5 shadow-sm space-y-3 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold border ${cat.color}`}>
                    [{cat.code}]
                  </span>
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    <CheckCircle2 className="w-3 h-3" /> Active
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white leading-snug">{cat.nameTh}</h3>
                
                {parent && (
                  <span className="text-[10px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 inline-block mt-1">
                    หมวดหลัก: {parent.nameTh}
                  </span>
                )}

                {cat.description && (
                  <p className="text-xs text-slate-300 mt-2 line-clamp-2 leading-relaxed">
                    {cat.description}
                  </p>
                )}
              </div>

              {/* Footer info */}
              <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Box className="w-3.5 h-3.5 text-amber-400" />
                  จำนวน <strong className="text-white font-mono">{skuCount}</strong> SKU
                </span>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => onEditCategory(cat)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-blue-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="แก้ไขหมวดหมู่"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteCategory(cat.id)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-rose-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="ลบหมวดหมู่"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
