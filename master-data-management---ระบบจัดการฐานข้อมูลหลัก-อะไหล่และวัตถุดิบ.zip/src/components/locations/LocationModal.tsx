import React, { useState, useEffect } from 'react';
import { StorageLocation, MasterStatus, StorageType } from '../../types';
import { X, Save, MapPin } from 'lucide-react';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (location: StorageLocation) => void;
  editingLocation: StorageLocation | null;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingLocation,
}) => {
  const [formData, setFormData] = useState<Partial<StorageLocation>>({
    code: '',
    name: '',
    warehouse: 'คลังสินค้าหลัก (Main Warehouse 1)',
    zone: 'Zone A',
    rack: 'Rack 01',
    shelf: 'Shelf 01',
    bin: 'Bin 01',
    type: 'SHELF',
    temperatureCondition: '',
    maxCapacityItems: 100,
    description: '',
    status: 'ACTIVE',
  });

  useEffect(() => {
    if (editingLocation) {
      setFormData(editingLocation);
    } else {
      setFormData({
        code: 'WH1-A1-S1-B' + Math.floor(10 + Math.random() * 89),
        name: '',
        warehouse: 'คลังสินค้าหลัก (Main Warehouse 1)',
        zone: 'Zone A',
        rack: 'Rack 01',
        shelf: 'Shelf 01',
        bin: 'Bin 01',
        type: 'SHELF',
        temperatureCondition: '',
        maxCapacityItems: 100,
        description: '',
        status: 'ACTIVE',
      });
    }
  }, [editingLocation, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || !formData.name || !formData.warehouse) {
      alert('กรุณากรอกรหัสตำแหน่ง ชื่อชั้นวาง และชื่อคลังสินค้าให้ครบถ้วน');
      return;
    }

    const finalLoc: StorageLocation = {
      id: editingLocation ? editingLocation.id : 'loc-' + Date.now(),
      code: formData.code.toUpperCase().trim(),
      name: formData.name.trim(),
      warehouse: formData.warehouse.trim(),
      zone: formData.zone?.trim() || 'Zone A',
      rack: formData.rack?.trim() || 'Rack 1',
      shelf: formData.shelf?.trim() || 'Shelf 1',
      bin: formData.bin?.trim() || 'Bin 1',
      type: (formData.type as StorageType) || 'SHELF',
      temperatureCondition: formData.temperatureCondition || '',
      maxCapacityItems: Number(formData.maxCapacityItems) || 100,
      currentCapacityItems: editingLocation?.currentCapacityItems || 0,
      description: formData.description || '',
      status: (formData.status as MasterStatus) || 'ACTIVE',
      createdAt: editingLocation ? editingLocation.createdAt : new Date().toISOString(),
    };

    onSave(finalLoc);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden my-8">
        
        <div className="px-6 py-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white">
              {editingLocation ? 'แก้ไขตำแหน่งชั้นวาง (Edit Location)' : 'เพิ่มตำแหน่งชั้นวางใหม่ (Add Location)'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                รหัสตำแหน่ง (Location Code) <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                placeholder="เช่น WH1-A1-S2-B03"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white uppercase font-mono focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ประเภทพื้นที่เก็บ (Type) <span className="text-rose-400">*</span>
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as StorageType })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="SHELF">📦 ชั้นวางสินค้า (Shelf)</option>
                <option value="BIN">📥 ช่องเก็บสินค้า (Bin)</option>
                <option value="RACK">🏗️ แร็คชั้นใหญ่ (Rack)</option>
                <option value="WAREHOUSE">🏢 พื้นที่คลังสินค้า (Warehouse Floor)</option>
                <option value="COLD_STORAGE">❄️ ห้องเย็นควบคุมอุณหภูมิ (Cold Storage)</option>
                <option value="HAZARDOUS">⚠️ ตู้จัดเก็บเคมีอันตราย (Hazardous Cabinet)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              ชื่อแสดงตำแหน่งชั้นวาง (Location Display Name) <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="เช่น คลังหลัก A - แถว A1 - ชั้น 2 - ช่อง 03"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          {/* Hierarchy Fields */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 mb-1">ชื่อคลังสินค้า</label>
              <input
                type="text"
                value={formData.warehouse}
                onChange={(e) => setFormData({ ...formData, warehouse: e.target.value })}
                placeholder="เช่น คลังสินค้า 1"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 mb-1">โซน (Zone)</label>
              <input
                type="text"
                value={formData.zone}
                onChange={(e) => setFormData({ ...formData, zone: e.target.value })}
                placeholder="เช่น Zone A"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 mb-1">แร็ค (Rack)</label>
              <input
                type="text"
                value={formData.rack}
                onChange={(e) => setFormData({ ...formData, rack: e.target.value })}
                placeholder="เช่น Rack 01"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 mb-1">ชั้น / ช่อง (Shelf/Bin)</label>
              <input
                type="text"
                value={formData.shelf}
                onChange={(e) => setFormData({ ...formData, shelf: e.target.value })}
                placeholder="เช่น Shelf 2"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ความจุจัดเก็บสูงสุด (Max Item Capacity)
              </label>
              <input
                type="number"
                min="1"
                value={formData.maxCapacityItems}
                onChange={(e) => setFormData({ ...formData, maxCapacityItems: Number(e.target.value) })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                เงื่อนไขสภาวะจัดเก็บ (ถ้ามี)
              </label>
              <input
                type="text"
                value={formData.temperatureCondition}
                onChange={(e) => setFormData({ ...formData, temperatureCondition: e.target.value })}
                placeholder="เช่น ควบคุมความเย็น 18-22°C"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">คำอธิบายเพิ่มเติม</label>
            <textarea
              rows={2}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="คำอธิบายตำแหน่ง ข้อมูลความปลอดภัย หรือการเข้าถึง..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow-lg transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>บันทึกตำแหน่ง</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
