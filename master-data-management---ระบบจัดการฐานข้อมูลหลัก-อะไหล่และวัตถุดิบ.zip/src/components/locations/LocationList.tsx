import React from 'react';
import { StorageLocation, MasterItem } from '../../types';
import { MapPin, Plus, Edit3, Trash2, Box, Thermometer, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface LocationListProps {
  locations: StorageLocation[];
  items: MasterItem[];
  onAddLocation: () => void;
  onEditLocation: (loc: StorageLocation) => void;
  onDeleteLocation: (locId: string) => void;
}

export const LocationList: React.FC<LocationListProps> = ({
  locations,
  items,
  onAddLocation,
  onEditLocation,
  onDeleteLocation,
}) => {
  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-400" />
            <span>ตารางข้อมูลที่เก็บและชั้นวาง (Storage Locations Master)</span>
          </h2>
          <p className="text-xs text-slate-400">
            ระบบระบุพิกัดคลังสินค้า โซน แร็ค ชั้น และช่องเก็บ (Warehouse & Shelf Hierarchy)
          </p>
        </div>

        <button
          onClick={onAddLocation}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ เพิ่มชั้นวาง/พิกัดใหม่</span>
        </button>
      </div>

      {/* Locations Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {locations.map((loc) => {
          // Calculate how many items are assigned to this location
          const assignedItems = items.filter((i) => i.locationId === loc.id);
          const totalUnitsInLoc = assignedItems.reduce((acc, curr) => acc + curr.currentStock, 0);

          // Capacity calculation percentage
          const capacityPct = Math.min(100, Math.round((totalUnitsInLoc / (loc.maxCapacityItems || 100)) * 100));

          return (
            <div
              key={loc.id}
              className="bg-slate-800/90 border border-slate-700/80 hover:border-emerald-500/50 rounded-2xl p-5 shadow-sm space-y-3 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-mono font-bold">
                    {loc.code}
                  </span>
                  
                  <div className="flex items-center gap-1.5">
                    {loc.type === 'COLD_STORAGE' && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-cyan-300 bg-cyan-500/20 px-2 py-0.5 rounded border border-cyan-500/30">
                        <Thermometer className="w-3 h-3" /> Cold
                      </span>
                    )}
                    {loc.type === 'HAZARDOUS' && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                        <ShieldAlert className="w-3 h-3" /> Chem
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      <CheckCircle2 className="w-3 h-3" /> Active
                    </span>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-white leading-snug">{loc.name}</h3>
                
                {/* Location Path Badges */}
                <div className="flex flex-wrap items-center gap-1 text-[10px] font-semibold text-slate-300 mt-2">
                  <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-700">{loc.warehouse}</span>
                  <span className="text-slate-500">›</span>
                  <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-700">{loc.zone}</span>
                  <span className="text-slate-500">›</span>
                  <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-700">{loc.rack}</span>
                </div>

                {loc.temperatureCondition && (
                  <p className="text-[11px] text-cyan-300 font-semibold mt-2 flex items-center gap-1">
                    <Thermometer className="w-3.5 h-3.5" />
                    <span>เงื่อนไข: {loc.temperatureCondition}</span>
                  </p>
                )}

                {loc.description && (
                  <p className="text-xs text-slate-400 mt-2 line-clamp-2">{loc.description}</p>
                )}

                {/* Capacity Progress Bar */}
                <div className="mt-4 pt-3 border-t border-slate-700/60">
                  <div className="flex justify-between items-center text-[11px] mb-1">
                    <span className="text-slate-400">อัตราครองพื้นที่จัดเก็บ (Occupancy):</span>
                    <span className="font-bold text-slate-200">
                      {totalUnitsInLoc} / {loc.maxCapacityItems} ชิ้น ({capacityPct}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-700">
                    <div
                      className={`h-full transition-all duration-500 rounded-full ${
                        capacityPct > 85 ? 'bg-rose-500' : capacityPct > 60 ? 'bg-amber-400' : 'bg-emerald-400'
                      }`}
                      style={{ width: `${capacityPct}%` }}
                    />
                  </div>
                </div>

              </div>

              {/* Action & SKU list preview */}
              <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Box className="w-3.5 h-3.5 text-emerald-400" />
                  จัดเก็บอยู่ <strong className="text-white">{assignedItems.length}</strong> SKU
                </span>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => onEditLocation(loc)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-blue-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="แก้ไขชั้นวาง"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteLocation(loc.id)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-rose-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="ลบชั้นวาง"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
