import React, { useState } from 'react';
import { StorageLocation, MasterItem } from '../../types';
import { Grid3X3, MapPin, Box, Eye, AlertTriangle, Layers, Building } from 'lucide-react';

interface ShelfVisualizerProps {
  locations: StorageLocation[];
  items: MasterItem[];
  onSelectItemForEdit?: (item: MasterItem) => void;
}

export const ShelfVisualizer: React.FC<ShelfVisualizerProps> = ({
  locations,
  items,
  onSelectItemForEdit,
}) => {
  const [selectedLocationId, setSelectedLocationId] = useState<string>(locations[0]?.id || '');

  const selectedLoc = locations.find((l) => l.id === selectedLocationId) || locations[0];
  const locItems = items.filter((i) => i.locationId === selectedLoc?.id);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div>
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Grid3X3 className="w-5 h-5 text-blue-400" />
          <span>แผนผังจำลองชั้นวางสินค้าดิจิทัล (Spatial Shelf & Rack Visualizer)</span>
        </h2>
        <p className="text-xs text-slate-400">
          แสดงตำแหน่งจัดเก็บจริงในคลังสินค้า คลิกเลือกพิกัดแร็ค/ชั้นวางเพื่อตรวจสอบรายการอะไหล่และวัตถุดิบ
        </p>
      </div>

      {/* Main Grid split: Left Locations Picker / Right Visual Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Location Picker List */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 space-y-3">
          <h3 className="text-xs font-bold uppercase text-slate-300 tracking-wider flex items-center gap-1.5">
            <Building className="w-4 h-4 text-emerald-400" /> เลือกตำแหน่งชั้นวาง (Select Rack / Bin)
          </h3>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1 scrollbar-thin">
            {locations.map((loc) => {
              const count = items.filter((i) => i.locationId === loc.id).length;
              const isSelected = loc.id === selectedLoc?.id;

              return (
                <button
                  key={loc.id}
                  onClick={() => setSelectedLocationId(loc.id)}
                  className={`w-full text-left p-3 rounded-xl border transition cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600/20 border-blue-500/80 text-white ring-1 ring-blue-500/40'
                      : 'bg-slate-900/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-xs font-bold text-emerald-300">{loc.code}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 font-semibold text-slate-300">
                      {count} SKU
                    </span>
                  </div>
                  <p className="text-xs font-medium text-slate-100 line-clamp-1">{loc.name}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {loc.warehouse} • {loc.zone}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Col: Visual Rack Layout & Items List */}
        <div className="lg:col-span-2 space-y-4">
          
          {selectedLoc && (
            <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 space-y-4 shadow-md">
              
              {/* Rack Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-700/80">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded text-xs font-mono font-bold">
                      {selectedLoc.code}
                    </span>
                    <h3 className="text-base font-bold text-white">{selectedLoc.name}</h3>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    {selectedLoc.warehouse} › {selectedLoc.zone} › {selectedLoc.rack} › {selectedLoc.shelf}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-xs text-slate-400 block">จัดเก็บทั้งหมด</span>
                  <span className="text-lg font-extrabold text-blue-400 font-mono">
                    {locItems.reduce((sum, i) => sum + i.currentStock, 0)} / {selectedLoc.maxCapacityItems} ชิ้น
                  </span>
                </div>
              </div>

              {/* Graphical Shelf Box Representation */}
              <div className="bg-slate-950 p-6 rounded-xl border-2 border-slate-700 relative overflow-hidden">
                <div className="absolute top-2 right-2 text-[10px] font-mono font-bold text-slate-500">
                  SHELF SLOT MATRIX
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-2">
                  <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg text-center">
                    <span className="text-[10px] text-slate-400 block">แร็คหลัก</span>
                    <span className="text-xs font-bold text-white">{selectedLoc.rack}</span>
                  </div>
                  <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg text-center">
                    <span className="text-[10px] text-slate-400 block">ระดับชั้น</span>
                    <span className="text-xs font-bold text-amber-300">{selectedLoc.shelf}</span>
                  </div>
                  <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg text-center col-span-2 sm:col-span-1">
                    <span className="text-[10px] text-slate-400 block">ช่องเก็บ (Bin)</span>
                    <span className="text-xs font-bold text-emerald-300">{selectedLoc.bin}</span>
                  </div>
                </div>

                {/* Items in this shelf slot */}
                <div className="mt-4 pt-4 border-t border-slate-800">
                  <h4 className="text-xs font-bold text-slate-300 mb-3 flex items-center justify-between">
                    <span>รายการอะไหล่และวัตถุดิบในพิกัดนี้ ({locItems.length} SKU):</span>
                  </h4>

                  {locItems.length === 0 ? (
                    <div className="py-8 text-center text-slate-500 text-xs italic bg-slate-900/50 rounded-lg">
                      ยังไม่มีรายการสินค้าหรือวัตถุดิบผูกกับชั้นวางนี้
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {locItems.map((item) => {
                        const isLow = item.currentStock <= item.reorderPoint;
                        return (
                          <div
                            key={item.id}
                            className="bg-slate-900 border border-slate-700/80 hover:border-blue-500/60 p-3 rounded-xl flex items-center justify-between gap-3 text-xs transition"
                          >
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-blue-300 font-bold">{item.code}</span>
                                {isLow && (
                                  <span className="px-1.5 py-0.5 bg-rose-500/20 text-rose-300 text-[9px] font-bold rounded flex items-center gap-0.5 border border-rose-500/30">
                                    <AlertTriangle className="w-3 h-3" /> Reorder Alert
                                  </span>
                                )}
                              </div>
                              <span className="text-white font-semibold block">{item.nameTh}</span>
                              <span className="text-[10px] text-slate-400 block">
                                {item.brand} {item.modelNumber}
                              </span>
                            </div>

                            <div className="text-right shrink-0">
                              <span
                                className={`text-sm font-bold font-mono block ${
                                  isLow ? 'text-rose-400' : 'text-emerald-400'
                                }`}
                              >
                                {item.currentStock} ชิ้น
                              </span>
                              <span className="text-[10px] text-slate-400">
                                ฿{item.unitCost.toLocaleString('th-TH')}/หน่วย
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
};
