import React from 'react';
import { ActiveTab } from '../types';
import { LayoutDashboard, Package, Factory, Box, Truck, FileSpreadsheet, Scale, FolderTree, MapPin, Grid3X3, QrCode, Layers } from 'lucide-react';

interface NavigationTabsProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  counts: {
    items: number;
    uoms: number;
    categories: number;
    locations: number;
    suppliers: number;
    lowStock: number;
    productionOrdersCount?: number;
    shipmentsCount?: number;
  };
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({
  activeTab,
  setActiveTab,
  counts,
}) => {
  const tabs: Array<{ id: ActiveTab; label: string; icon: React.ReactNode; badge?: number | string; alert?: boolean }> = [
    {
      id: 'dashboard',
      label: 'ภาพรวมระบบ ERP',
      icon: <LayoutDashboard className="w-4 h-4" />,
      badge: counts.lowStock > 0 ? `${counts.lowStock} สั่งเพิ่ม` : undefined,
      alert: counts.lowStock > 0,
    },
    {
      id: 'raw_materials',
      label: 'คลังอะไหล่-วัตถุดิบ',
      icon: <Package className="w-4 h-4" />,
    },
    {
      id: 'production',
      label: 'ฝ่ายผลิต & BOM',
      icon: <Factory className="w-4 h-4" />,
      badge: counts.productionOrdersCount,
    },
    {
      id: 'finished_goods',
      label: 'คลังสินค้าสำเร็จรูป',
      icon: <Box className="w-4 h-4" />,
    },
    {
      id: 'shipping',
      label: 'ส่วนงานจัดส่ง',
      icon: <Truck className="w-4 h-4" />,
      badge: counts.shipmentsCount,
    },
    {
      id: 'google_sheets',
      label: 'ฐานข้อมูล Google Sheets',
      icon: <FileSpreadsheet className="w-4 h-4 text-emerald-400" />,
    },
    {
      id: 'items',
      label: 'รายการทั้งหมด (Master)',
      icon: <Layers className="w-4 h-4" />,
      badge: counts.items,
    },
    {
      id: 'uom',
      label: 'หน่วยนับ (UOM)',
      icon: <Scale className="w-4 h-4" />,
      badge: counts.uoms,
    },
    {
      id: 'categories',
      label: 'หมวดหมู่',
      icon: <FolderTree className="w-4 h-4" />,
      badge: counts.categories,
    },
    {
      id: 'locations',
      label: 'ที่เก็บ / ชั้นวาง',
      icon: <MapPin className="w-4 h-4" />,
      badge: counts.locations,
    },
    {
      id: 'suppliers',
      label: 'ผู้จัดจำหน่าย',
      icon: <Truck className="w-4 h-4" />,
      badge: counts.suppliers,
    },
    {
      id: 'shelf_map',
      label: 'แผนผังชั้นวาง',
      icon: <Grid3X3 className="w-4 h-4" />,
    },
    {
      id: 'barcode',
      label: 'ลาเบล/บาร์โค้ด',
      icon: <QrCode className="w-4 h-4" />,
    },
  ];

  return (
    <div className="bg-slate-800 border-b border-slate-700/80 sticky top-[65px] z-20 shadow-sm">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
        <nav className="flex space-x-1 overflow-x-auto py-2 scrollbar-thin scrollbar-thumb-slate-700">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm ring-1 ring-blue-500/50'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                }`}
              >
                <span className={isActive ? 'text-white' : 'text-slate-400'}>{tab.icon}</span>
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span
                    className={`ml-1 px-1.5 py-0.5 text-[10px] rounded-full font-bold leading-none ${
                      tab.alert
                        ? 'bg-rose-500 text-white animate-pulse'
                        : isActive
                        ? 'bg-blue-800 text-blue-100'
                        : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};
