import React, { useRef } from 'react';
import { Database, Download, Upload, RotateCcw, Box, Layers, MapPin, Truck, FileSpreadsheet } from 'lucide-react';

interface HeaderProps {
  totalItemsCount: number;
  totalUomsCount: number;
  totalCategoriesCount: number;
  totalLocationsCount: number;
  totalSuppliersCount: number;
  onExportBackup: () => void;
  onExportExcel?: () => void;
  onImportBackup: (jsonText: string) => void;
  onResetData: () => void;
  googleDriveComponent?: React.ReactNode;
}

export const Header: React.FC<HeaderProps> = ({
  totalItemsCount,
  totalUomsCount,
  totalCategoriesCount,
  totalLocationsCount,
  totalSuppliersCount,
  onExportBackup,
  onExportExcel,
  onImportBackup,
  onResetData,
  googleDriveComponent,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) {
          onImportBackup(content);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Title & Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-inner">
              <Database className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-slate-100 tracking-tight leading-tight">
                  ระบบจัดการฐานข้อมูลหลัก
                </h1>
                <span className="px-2 py-0.5 text-xs font-semibold rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Master Data Management
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                รายการอะไหล่และวัตถุดิบ • หน่วยนับ • หมวดหมู่ • ชั้นวาง (Location) • ผู้จัดจำหน่าย (Supplier)
              </p>
            </div>
          </div>

          {/* Quick Metrics & Actions */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Quick Badges */}
            <div className="hidden lg:flex items-center space-x-3 text-xs bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60">
              <span className="flex items-center gap-1 text-slate-300" title="รายการอะไหล่และวัตถุดิบ">
                <Box className="w-3.5 h-3.5 text-blue-400" />
                <strong className="text-white">{totalItemsCount}</strong> SKU
              </span>
              <span className="text-slate-600">|</span>
              <span className="flex items-center gap-1 text-slate-300" title="หมวดหมู่">
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <strong className="text-white">{totalCategoriesCount}</strong> หมวด
              </span>
              <span className="text-slate-600">|</span>
              <span className="flex items-center gap-1 text-slate-300" title="ที่เก็บ/ชั้นวาง">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <strong className="text-white">{totalLocationsCount}</strong> จุด
              </span>
              <span className="text-slate-600">|</span>
              <span className="flex items-center gap-1 text-slate-300" title="ผู้จัดจำหน่าย">
                <Truck className="w-3.5 h-3.5 text-purple-400" />
                <strong className="text-white">{totalSuppliersCount}</strong> ราย
              </span>
            </div>

            {/* Action Buttons */}
            {googleDriveComponent}

            {onExportExcel && (
              <button
                onClick={onExportExcel}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition cursor-pointer"
                title="ส่งออกฐานข้อมูล Master Data ทั้งหมดเป็นไฟล์ Excel (.xlsx) แบบหลาย Sheet"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-white" />
                <span>ส่งออก Excel</span>
              </button>
            )}

            <button
              onClick={onExportBackup}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
              title="ส่งออกไฟล์ JSON สำรองข้อมูล Master Data ทั้งหมด"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span>สำรอง JSON</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
              title="นำเข้าไฟล์ JSON เพื่อกู้คืน Master Data"
            >
              <Upload className="w-3.5 h-3.5 text-emerald-400" />
              <span>นำเข้า JSON</span>
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".json"
              className="hidden"
            />

            <button
              onClick={onResetData}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-slate-800/80 hover:bg-rose-950/80 text-rose-300 border border-slate-700 hover:border-rose-800 transition cursor-pointer"
              title="รีเซ็ตข้อมูลทั้งหมดกลับเป็นค่าตั้งต้นตัวอย่าง"
            >
              <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">รีเซ็ตตัวอย่าง</span>
            </button>

          </div>

        </div>
      </div>
    </header>
  );
};
