import React, { useState, useEffect } from 'react';
import { MasterStatus, UOM, UomConversion } from '../../types';
import { X, Save, Plus, Trash2, Scale } from 'lucide-react';

interface UomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (uom: UOM) => void;
  editingUom: UOM | null;
  allUoms: UOM[];
}

export const UomModal: React.FC<UomModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingUom,
  allUoms,
}) => {
  const [formData, setFormData] = useState<Partial<UOM>>({
    code: '',
    nameTh: '',
    nameEn: '',
    symbol: '',
    description: '',
    conversions: [],
    status: 'ACTIVE',
  });

  useEffect(() => {
    if (editingUom) {
      setFormData(editingUom);
    } else {
      setFormData({
        code: '',
        nameTh: '',
        nameEn: '',
        symbol: '',
        description: '',
        conversions: [],
        status: 'ACTIVE',
      });
    }
  }, [editingUom, isOpen]);

  if (!isOpen) return null;

  const handleAddConversion = () => {
    const target = allUoms.find((u) => u.id !== editingUom?.id);
    if (!target) return;
    const newConv: UomConversion = {
      targetUomId: target.id,
      factor: 10,
      description: `1 ${formData.nameTh || 'หน่วยนี้'} = 10 ${target.nameTh}`,
    };
    setFormData((prev) => ({
      ...prev,
      conversions: [...(prev.conversions || []), newConv],
    }));
  };

  const handleRemoveConversion = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      conversions: prev.conversions?.filter((_, i) => i !== index),
    }));
  };

  const handleConversionChange = (index: number, field: keyof UomConversion, value: any) => {
    setFormData((prev) => {
      const updated = [...(prev.conversions || [])];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, conversions: updated };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || !formData.nameTh || !formData.symbol) {
      alert('กรุณากรอกรหัสหน่วยนับ ชื่อภาษาไทย และสัญลักษณ์ให้ครบถ้วน');
      return;
    }

    const finalUom: UOM = {
      id: editingUom ? editingUom.id : 'uom-' + Date.now(),
      code: formData.code.toUpperCase().trim(),
      nameTh: formData.nameTh.trim(),
      nameEn: formData.nameEn?.trim() || '',
      symbol: formData.symbol.trim(),
      description: formData.description || '',
      conversions: formData.conversions || [],
      status: (formData.status as MasterStatus) || 'ACTIVE',
      createdAt: editingUom ? editingUom.createdAt : new Date().toISOString(),
    };

    onSave(finalUom);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden my-8">
        
        <div className="px-6 py-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-blue-400" />
            <h2 className="text-base font-bold text-white">
              {editingUom ? 'แก้ไขหน่วยนับ (Edit UOM)' : 'เพิ่มหน่วยนับใหม่ (Add UOM)'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                รหัสหน่วยนับ (Code) <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                placeholder="เช่น PCS, BOX, KG"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white uppercase font-mono focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                สัญลักษณ์แสดง (Symbol) <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.symbol}
                onChange={(e) => setFormData({ ...formData, symbol: e.target.value })}
                placeholder="เช่น pcs, box, kg"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              ชื่อหน่วยนับ <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.nameTh}
              onChange={(e) => setFormData({ ...formData, nameTh: e.target.value })}
              placeholder="เช่น ชิ้น, กล่อง, ม้วน"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">คำอธิบายรายละเอียด</label>
            <input
              type="text"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="รายละเอียดการใช้งานหน่วยนับนี้..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          {/* Conversions Sub-Section */}
          <div className="pt-3 border-t border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-amber-300">
                กฎการแปลงหน่วยนับ (UOM Conversion Factor)
              </label>
              <button
                type="button"
                onClick={handleAddConversion}
                className="text-[11px] font-semibold text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> เพิ่มกฎการแปลง
              </button>
            </div>

            {formData.conversions?.length === 0 ? (
              <p className="text-[11px] text-slate-500 italic bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                ยังไม่มีการตั้งค่าการแปลงหน่วยนับ (เช่น 1 กล่อง = 10 ชิ้น)
              </p>
            ) : (
              <div className="space-y-2">
                {formData.conversions?.map((conv, idx) => (
                  <div key={idx} className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700 flex items-center gap-2 text-xs">
                    <span className="text-slate-300 whitespace-nowrap">1 {formData.nameTh || 'หน่วย'} =</span>
                    
                    <input
                      type="number"
                      min="0.001"
                      step="any"
                      value={conv.factor}
                      onChange={(e) => handleConversionChange(idx, 'factor', Number(e.target.value))}
                      className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-amber-300 font-bold outline-none"
                    />

                    <select
                      value={conv.targetUomId}
                      onChange={(e) => handleConversionChange(idx, 'targetUomId', e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white outline-none flex-1"
                    >
                      {allUoms
                        .filter((u) => u.id !== editingUom?.id)
                        .map((u) => (
                          <option key={u.id} value={u.id}>
                            {u.nameTh} ({u.symbol})
                          </option>
                        ))}
                    </select>

                    <button
                      type="button"
                      onClick={() => handleRemoveConversion(idx)}
                      className="p-1 text-rose-400 hover:bg-rose-950 rounded transition cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow-lg transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>บันทึกหน่วยนับ</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
