import React, { useState } from 'react';
import { MasterItem, UOM } from '../../types';
import { Scale, Plus, Edit3, Trash2, ArrowRightLeft, CheckCircle2, Box } from 'lucide-react';

interface UomListProps {
  uoms: UOM[];
  items: MasterItem[];
  onAddUom: () => void;
  onEditUom: (uom: UOM) => void;
  onDeleteUom: (uomId: string) => void;
}

export const UomList: React.FC<UomListProps> = ({
  uoms,
  items,
  onAddUom,
  onEditUom,
  onDeleteUom,
}) => {
  // Calculator state
  const [calcAmount, setCalcAmount] = useState<number>(1);
  const [sourceUomId, setSourceUomId] = useState<string>(uoms[0]?.id || '');
  const [targetUomId, setTargetUomId] = useState<string>(uoms[1]?.id || uoms[0]?.id || '');

  const uomMap = new Map<string, UOM>(uoms.map((u) => [u.id, u]));

  // Calculate conversion result
  const sourceUom = uomMap.get(sourceUomId);
  const targetUom = uomMap.get(targetUomId);

  let conversionResult: number | null = null;
  let conversionNote = '';

  if (sourceUom && targetUom) {
    if (sourceUomId === targetUomId) {
      conversionResult = calcAmount;
      conversionNote = 'หน่วยนับเดียวกัน';
    } else {
      // Direct conversion rule check
      const directConv = sourceUom.conversions.find((c) => c.targetUomId === targetUomId);
      if (directConv) {
        conversionResult = calcAmount * directConv.factor;
        conversionNote = `1 ${sourceUom.nameTh} = ${directConv.factor} ${targetUom.nameTh}`;
      } else {
        // Reverse conversion rule check
        const reverseConv = targetUom.conversions.find((c) => c.targetUomId === sourceUomId);
        if (reverseConv && reverseConv.factor > 0) {
          conversionResult = calcAmount / reverseConv.factor;
          conversionNote = `1 ${targetUom.nameTh} = ${reverseConv.factor} ${sourceUom.nameTh}`;
        }
      }
    }
  }

  return (
    <div className="space-y-6">
      
      {/* Interactive Conversion Calculator Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-blue-500/30 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center gap-2 mb-3">
          <div className="p-1.5 bg-blue-500/20 text-blue-400 rounded-lg">
            <ArrowRightLeft className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">เครื่องมือคำนวณแปลงหน่วยนับ (Live UOM Converter)</h3>
            <p className="text-xs text-slate-400">ทดสอบแปลงจำนวนวัตถุดิบและอะไหล่ระหว่างหน่วยนับหลักและหน่วยบรรจุ</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-center">
          
          {/* Amount */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">จำนวนที่ต้องการแปลง</label>
            <input
              type="number"
              min="0"
              value={calcAmount}
              onChange={(e) => setCalcAmount(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-amber-300 font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          {/* From UOM */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">จากหน่วยนับ (From UOM)</label>
            <select
              value={sourceUomId}
              onChange={(e) => setSourceUomId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {uoms.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.nameTh} ({u.symbol})
                </option>
              ))}
            </select>
          </div>

          {/* To UOM */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">เป็นหน่วยนับ (To UOM)</label>
            <select
              value={targetUomId}
              onChange={(e) => setTargetUomId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {uoms.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.nameTh} ({u.symbol})
                </option>
              ))}
            </select>
          </div>

          {/* Result */}
          <div className="bg-slate-950/80 border border-emerald-500/30 rounded-xl p-3 text-center sm:col-span-1">
            <span className="text-[10px] text-slate-400 block">ผลลัพธ์คำนวณ</span>
            <span className="text-base font-bold text-emerald-400 font-mono">
              {conversionResult !== null ? conversionResult.toLocaleString('th-TH') : 'ไม่มีกฎแปลง'}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">{targetUom?.symbol || ''}</span>
            {conversionNote && <span className="text-[9px] text-blue-300 block">{conversionNote}</span>}
          </div>

        </div>
      </div>

      {/* Header & Add Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Scale className="w-5 h-5 text-blue-400" />
            <span>ตารางข้อมูลหน่วยนับหลัก (Units of Measure Master)</span>
          </h2>
          <p className="text-xs text-slate-400">
            กำหนดหน่วยนับมาตรฐานสำหรับตัดสต็อกและการแปลงหน่วยบรรจุภัณฑ์
          </p>
        </div>

        <button
          onClick={onAddUom}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ เพิ่มหน่วยนับใหม่</span>
        </button>
      </div>

      {/* UOM Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {uoms.map((uom) => {
          // Count items using this uom
          const usedCount = items.filter((i) => i.uomId === uom.id || i.secondaryUomId === uom.id).length;

          return (
            <div
              key={uom.id}
              className="bg-slate-800/90 border border-slate-700/80 hover:border-blue-500/50 rounded-2xl p-5 shadow-sm space-y-3 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-lg text-xs font-mono font-bold">
                      {uom.code}
                    </span>
                    <span className="text-xs font-semibold text-slate-400">[{uom.symbol}]</span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    <CheckCircle2 className="w-3 h-3" /> Active
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white">{uom.nameTh}</h3>
                {uom.description && <p className="text-xs text-slate-300 mt-1 line-clamp-2">{uom.description}</p>}

                {/* Conversion Rules */}
                <div className="mt-3 pt-3 border-t border-slate-700/60">
                  <span className="text-[11px] font-semibold text-amber-300 block mb-1">
                    กฎการแปลงหน่วย (Conversions):
                  </span>
                  {uom.conversions.length === 0 ? (
                    <span className="text-[11px] text-slate-500 italic block">ไม่มีอัตราแปลงย่อย</span>
                  ) : (
                    <div className="space-y-1">
                      {uom.conversions.map((conv, idx) => {
                        const target = uomMap.get(conv.targetUomId);
                        return (
                          <div
                            key={idx}
                            className="text-[11px] bg-slate-900/60 px-2.5 py-1 rounded-lg border border-slate-700/60 text-slate-200 flex items-center justify-between font-mono"
                          >
                            <span>1 {uom.symbol}</span>
                            <span className="text-amber-400 font-bold">= {conv.factor}</span>
                            <span>{target?.symbol || 'หน่วย'}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* Usage & Actions */}
              <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Box className="w-3.5 h-3.5 text-blue-400" />
                  ใช้งานอยู่ <strong className="text-white">{usedCount}</strong> SKU
                </span>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => onEditUom(uom)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-blue-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="แก้ไขหน่วยนับ"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteUom(uom.id)}
                    className="p-1.5 rounded-lg bg-slate-700 hover:bg-rose-600 text-slate-200 hover:text-white transition cursor-pointer"
                    title="ลบหน่วยนับ"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
