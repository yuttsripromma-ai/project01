import React, { useState } from 'react';
import { Package, Search, Plus, AlertTriangle, ArrowDownRight, ArrowUpRight, Filter } from 'lucide-react';
import { MasterItem, Category, StorageLocation, UOM } from '../../types';

interface RawMaterialsModuleProps {
  items: MasterItem[];
  categories: Category[];
  locations: StorageLocation[];
  uoms: UOM[];
  onAddItem: () => void;
  onEditItem: (item: MasterItem) => void;
  onAdjustStock: (item: MasterItem) => void;
}

export const RawMaterialsModule: React.FC<RawMaterialsModuleProps> = ({
  items,
  categories,
  locations,
  uoms,
  onAddItem,
  onEditItem,
  onAdjustStock,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'LOW' | 'NORMAL'>('ALL');

  const rawMaterials = items.filter((i) => i.type !== 'FINISHED_GOOD');

  const filteredItems = rawMaterials.filter((item) => {
    const matchesSearch =
      item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.nameTh.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter ? item.categoryId === categoryFilter : true;
    const isLowStock = item.currentStock <= item.reorderPoint;
    const matchesStock =
      stockFilter === 'ALL'
        ? true
        : stockFilter === 'LOW'
        ? isLowStock
        : !isLowStock;

    return matchesSearch && matchesCategory && matchesStock;
  });

  const catMap = new Map(categories.map((c) => [c.id, c.nameTh]));
  const locMap = new Map(locations.map((l) => [l.id, l.name]));
  const uomMap = new Map(uoms.map((u) => [u.id, u.code]));

  const lowStockCount = rawMaterials.filter((i) => i.currentStock <= i.reorderPoint).length;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-slate-900 border border-cyan-500/30 rounded-2xl p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">สต๊อกคลังอะไหล่ & วัตถุดิบ (Raw Materials Warehouse)</h2>
            <p className="text-xs text-cyan-200/80">จัดเก็บและบริหารสต๊อกวัตถุดิบ อะไหล่ และวัสดุสิ้นเปลืองสำหรับฝ่ายผลิต</p>
          </div>
        </div>

        <button
          onClick={onAddItem}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs rounded-xl shadow-md transition"
        >
          <Plus className="w-4 h-4" />
          เพิ่มรายการวัตถุดิบใหม่
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ค้นหารหัส SKU หรือชื่อวัตถุดิบ..."
            className="w-full bg-slate-950 border border-slate-700/80 rounded-xl pl-9 pr-3 py-2 text-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-white"
          >
            <option value="">ทุกหมวดหมู่</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.nameTh}
              </option>
            ))}
          </select>

          <button
            onClick={() => setStockFilter(stockFilter === 'LOW' ? 'ALL' : 'LOW')}
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl font-semibold transition border ${
              stockFilter === 'LOW'
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            ต้องสั่งซื้อเพิ่ม ({lowStockCount})
          </button>
        </div>
      </div>

      {/* Items Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider">
            <tr>
              <th className="p-3.5">รหัส SKU</th>
              <th className="p-3.5">ชื่อวัตถุดิบ/อะไหล่</th>
              <th className="p-3.5">หมวดหมู่</th>
              <th className="p-3.5">ตำแหน่งเก็บ</th>
              <th className="p-3.5 text-right">คงเหลือ</th>
              <th className="p-3.5 text-right">จุดสั่งซื้อเพิ่ม</th>
              <th className="p-3.5 text-center">จัดการ</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredItems.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-500">
                  ไม่พบรายการวัตถุดิบ
                </td>
              </tr>
            ) : (
              filteredItems.map((item) => {
                const isLow = item.currentStock <= item.reorderPoint;
                return (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3.5 font-mono font-bold text-cyan-300">{item.code}</td>
                    <td className="p-3.5 font-semibold text-white">
                      {item.nameTh}
                      <span className="block text-[10px] text-slate-500 font-normal">
                        {item.type === 'RAW_MATERIAL' ? 'วัตถุดิบ' : item.type === 'SPARE_PART' ? 'อะไหล่' : 'วัสดุสิ้นเปลือง'}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-400">{catMap.get(item.categoryId) || '-'}</td>
                    <td className="p-3.5 text-slate-400">{locMap.get(item.locationId) || '-'}</td>
                    <td className="p-3.5 text-right">
                      <span
                        className={`font-mono font-bold px-2 py-1 rounded-lg ${
                          isLow
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : 'text-emerald-400'
                        }`}
                      >
                        {item.currentStock} {uomMap.get(item.uomId) || 'หน่วย'}
                      </span>
                    </td>
                    <td className="p-3.5 text-right font-mono text-slate-400">{item.reorderPoint}</td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => onAdjustStock(item)}
                          className="px-2.5 py-1 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 rounded-lg text-[11px] font-semibold transition"
                        >
                          ปรับสต๊อก
                        </button>
                        <button
                          onClick={() => onEditItem(item)}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[11px] transition"
                        >
                          แก้ไข
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
