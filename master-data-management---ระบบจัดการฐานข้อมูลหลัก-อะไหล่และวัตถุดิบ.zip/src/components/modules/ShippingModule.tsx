import React, { useState } from 'react';
import { Truck, Plus, CheckCircle2, Clock, Send, MapPin, User, AlertCircle } from 'lucide-react';
import { MasterItem, Shipment } from '../../types';

interface ShippingModuleProps {
  items: MasterItem[];
  shipments: Shipment[];
  onAddShipment: (shipment: Omit<Shipment, 'id' | 'createdAt'>) => void;
  onUpdateShipmentStatus: (shipmentId: string, status: Shipment['status']) => void;
  showToast: (msg: string) => void;
}

export const ShippingModule: React.FC<ShippingModuleProps> = ({
  items,
  shipments,
  onAddShipment,
  onUpdateShipmentStatus,
  showToast,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [finishedGoodSku, setFinishedGoodSku] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [trackingNo, setTrackingNo] = useState('');
  const [vehicleNo, setVehicleNo] = useState('');

  const finishedGoods = items.filter((i) => i.type === 'FINISHED_GOOD');

  const handleCreateShipment = (e: React.FormEvent) => {
    e.preventDefault();
    const fg = finishedGoods.find((i) => i.code === finishedGoodSku);
    if (!fg) {
      showToast('กรุณาเลือกสินค้าสำเร็จรูปที่จะจัดส่ง');
      return;
    }

    if (fg.currentStock < quantity) {
      if (!confirm(`เตือน: สินค้าคงเหลือในคลัง (${fg.currentStock}) น้อยกว่าจำนวนที่สั่งส่ง (${quantity}) ยืนยันทำรายการ?`)) {
        return;
      }
    }

    const shipmentNo = `SHP-${new Date().getFullYear()}-${String(shipments.length + 1).padStart(3, '0')}`;
    onAddShipment({
      shipmentNo,
      customerName,
      address,
      finishedGoodSku: fg.code,
      finishedGoodName: fg.nameTh,
      quantity,
      status: 'PENDING',
      trackingNo,
      vehicleNo,
      dispatchDate: new Date().toISOString().slice(0, 10),
    });

    setShowModal(false);
    setCustomerName('');
    setAddress('');
    setFinishedGoodSku('');
    setQuantity(1);
    setTrackingNo('');
    setVehicleNo('');
    showToast(`สร้างใบจัดส่ง ${shipmentNo} สำเร็จ`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900/40 via-slate-900 to-slate-900 border border-blue-500/30 rounded-2xl p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">ส่วนงานจัดส่ง (Shipping & Delivery Department)</h2>
            <p className="text-xs text-blue-200/80">บริหารจัดการใบส่งสินค้า ติดตามสถานะพัสดุและตัดสต๊อกสินค้าสำเร็จรูป</p>
          </div>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-xl shadow-md transition"
        >
          <Plus className="w-4 h-4" />
          สร้างใบจัดส่งใหม่ (Delivery Order)
        </button>
      </div>

      {/* Shipment Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {shipments.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400 bg-slate-900/50 border border-slate-800 rounded-2xl">
            ยังไม่มีรายการจัดส่ง กด "สร้างใบจัดส่งใหม่" เพื่อเริ่มต้น
          </div>
        ) : (
          shipments.map((s) => (
            <div
              key={s.id}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-mono font-bold text-blue-400">{s.shipmentNo}</div>
                  <h4 className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    {s.customerName}
                  </h4>
                </div>
                <span
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-full ${
                    s.status === 'DELIVERED'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : s.status === 'IN_TRANSIT'
                      ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30 animate-pulse'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  {s.status === 'DELIVERED'
                    ? 'ส่งสำเร็จแล้ว'
                    : s.status === 'IN_TRANSIT'
                    ? 'กำลังจัดส่ง'
                    : 'รอดำเนินการ'}
                </span>
              </div>

              <div className="bg-slate-950/60 rounded-xl p-3 text-xs space-y-2 border border-slate-800/80">
                <div className="flex justify-between">
                  <span className="text-slate-400">สินค้าส่งมอบ:</span>
                  <span className="font-semibold text-slate-200">{s.finishedGoodName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">จำนวน:</span>
                  <span className="font-bold text-blue-300">{s.quantity} ชิ้น</span>
                </div>
                <div className="flex items-start gap-1.5 pt-1 text-slate-400 border-t border-slate-800">
                  <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                  <span className="line-clamp-2">{s.address || 'ไม่ระบุที่อยู่'}</span>
                </div>
                {s.vehicleNo && (
                  <div className="text-[11px] text-slate-400 font-mono pt-1">
                    รถจัดส่ง: {s.vehicleNo} {s.trackingNo ? `| Tracking: ${s.trackingNo}` : ''}
                  </div>
                )}
              </div>

              {s.status === 'PENDING' && (
                <button
                  onClick={() => onUpdateShipmentStatus(s.id, 'IN_TRANSIT')}
                  className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                >
                  <Send className="w-3.5 h-3.5" />
                  ยืนยันออกรถส่งสินค้า (Dispatch)
                </button>
              )}

              {s.status === 'IN_TRANSIT' && (
                <button
                  onClick={() => onUpdateShipmentStatus(s.id, 'DELIVERED')}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  ลูกค้าได้รับสินค้าแล้ว (Delivered)
                </button>
              )}
            </div>
          ))
        )}
      </div>

      {/* New Shipment Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-md text-white">
            <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
              <Truck className="w-4 h-4 text-blue-400" />
              สร้างใบส่งสินค้าใหม่ (Delivery Order)
            </h3>
            <form onSubmit={handleCreateShipment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">ชื่อลูกค้า / หน่วยงานรับมอบ</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="เช่น บริษัท เอสซีจี โลจิสติกส์ จำกัด"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">เลือกสินค้าสำเร็จรูป (Finished Good)</label>
                <select
                  value={finishedGoodSku}
                  onChange={(e) => setFinishedGoodSku(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                >
                  <option value="">-- เลือกสินค้า --</option>
                  {finishedGoods.map((fg) => (
                    <option key={fg.id} value={fg.code}>
                      {fg.code} - {fg.nameTh} (คงเหลือ: {fg.currentStock})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">จำนวนที่จัดส่ง</label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">ที่อยู่จัดส่ง</label>
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="ระบุที่อยู่จัดส่งและเบอร์ติดต่อผู้รับ"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white h-20"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">ทะเบียนรถ/ยานพาหนะ</label>
                  <input
                    type="text"
                    value={vehicleNo}
                    onChange={(e) => setVehicleNo(e.target.value)}
                    placeholder="เช่น 7กข-8899"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">เลข Tracking / พัสดุ</label>
                  <input
                    type="text"
                    value={trackingNo}
                    onChange={(e) => setTrackingNo(e.target.value)}
                    placeholder="เช่น KERRY12345"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 bg-slate-800 rounded-xl font-semibold hover:bg-slate-700"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 rounded-xl font-semibold hover:bg-blue-500 text-white"
                >
                  สร้างใบจัดส่ง
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
