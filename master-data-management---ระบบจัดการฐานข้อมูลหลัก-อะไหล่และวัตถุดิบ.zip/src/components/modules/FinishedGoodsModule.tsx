import React, { useState } from 'react';
import { Box, Search, Plus, CheckCircle, MapPin } from 'lucide-react';
import { MasterItem, Category, StorageLocation, UOM } from '../../types';

interface FinishedGoodsModuleProps {
  items: MasterItem[];
  categories: Category[];
  locations: StorageLocation[];
  uoms: UOM[];
  onAddItem: () => void;
  onEditItem: (item: MasterItem) => void;
  onAdjustStock: (item: MasterItem) => void;
}

export const FinishedGoodsModule: React.FC<FinishedGoodsModuleProps> = ({
  items,
  categories,
  locations,
  uoms,
  onAddItem,
  onEditItem,
  onAdjustStock,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const finishedGoods = items.filter((i) => i.type === 'FINISHED_GOOD');

  const filteredItems = finishedGoods.filter(
    (item) =>
      item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.nameTh.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const locMap = new Map(locations.map((l) => [l.id, l.name]));
  const uomMap = new Map(uoms.map((u) => [u.id, u.code]));

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-slate-900 border border-purple-500/30 rounded-2xl p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
            <Box className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">สต๊อกคลังสินค้าสำเร็จรูป (Finished Goods Warehouse)</h2>
            <p className="text-xs text-purple-200/80">จัดเก็บสินค้าสำเร็จรูปที่ผลิตเสร็จแล้ว ตรวจสอบยอดคงเหลือพร้อมส่งมอบลูกค้า</p>
          </div>
        </div>

        <button
          onClick={onAddItem}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs rounded-xl shadow-md transition"
        >
          <Plus className="w-4 h-4" />
          เพิ่มรายการสินค้าสำเร็จรูป
        </button>
      </div>

      {/* Filter */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ค้นหารหัส SKU สินค้าสำเร็จรูป..."
            className="w-full bg-slate-950 border border-slate-700/80 rounded-xl pl-9 pr-3 py-2 text-white"
          />
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400 bg-slate-900/50 border border-slate-800 rounded-2xl">
            ยังไม่มีรายการสินค้าสำเร็จรูป
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-mono font-bold text-purple-400">{item.code}</span>
                  <h4 className="text-sm font-bold text-white mt-1">{item.nameTh}</h4>
                </div>
                <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  Finished Good
                </span>
              </div>

              <div className="bg-slate-950/60 rounded-xl p-3 text-xs space-y-2 border border-slate-800/80">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">สต๊อกพร้อมส่งมอบ:</span>
                  <span className="font-mono text-base font-extrabold text-emerald-400">
                    {item.currentStock} {uomMap.get(item.uomId) || 'ชิ้น'}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-400 pt-1 border-t border-slate-800">
                  <MapPin className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                  <span>ตำแหน่งจัดเก็บ: {locMap.get(item.locationId) || 'ไม่ระบุ'}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onAdjustStock(item)}
                  className="flex-1 py-2 bg-purple-950 hover:bg-purple-900 border border-purple-800 text-purple-300 rounded-xl text-xs font-semibold transition"
                >
                  ปรับสต๊อก
                </button>
                <button
                  onClick={() => onEditItem(item)}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
                >
                  แก้ไข
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
