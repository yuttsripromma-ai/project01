import React, { useState } from 'react';
import { Factory, Plus, CheckCircle, Clock, FileText, ChevronRight, AlertTriangle, Layers } from 'lucide-react';
import { MasterItem, ProductionOrder, BOMItem } from '../../types';

interface ProductionModuleProps {
  items: MasterItem[];
  productionOrders: ProductionOrder[];
  boms: BOMItem[];
  onAddProductionOrder: (order: Omit<ProductionOrder, 'id' | 'createdAt'>) => void;
  onUpdateOrderStatus: (orderId: string, status: ProductionOrder['status']) => void;
  onSaveBOM: (bom: Omit<BOMItem, 'id'>) => void;
  showToast: (msg: string) => void;
}

export const ProductionModule: React.FC<ProductionModuleProps> = ({
  items,
  productionOrders,
  boms,
  onAddProductionOrder,
  onUpdateOrderStatus,
  onSaveBOM,
  showToast,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'orders' | 'bom'>('orders');
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showBomModal, setShowBomModal] = useState(false);

  // New Production Order Form
  const [targetSku, setTargetSku] = useState('');
  const [targetQty, setTargetQty] = useState<number>(10);
  const [targetDate, setTargetDate] = useState('');
  const [notes, setNotes] = useState('');

  // New BOM Form
  const [bomFgSku, setBomFgSku] = useState('');
  const [bomRmSku, setBomRmSku] = useState('');
  const [bomQty, setBomQty] = useState<number>(1);

  const finishedGoods = items.filter((i) => i.type === 'FINISHED_GOOD');
  const rawMaterials = items.filter((i) => i.type !== 'FINISHED_GOOD');

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const fg = finishedGoods.find((i) => i.code === targetSku);
    if (!fg) {
      showToast('กรุณาเลือกสินค้าสำเร็จรูปที่ต้องการผลิต');
      return;
    }

    const orderNo = `PO-${new Date().getFullYear()}-${String(productionOrders.length + 1).padStart(3, '0')}`;
    onAddProductionOrder({
      orderNo,
      targetSku: fg.code,
      targetName: fg.nameTh,
      targetQty,
      producedQty: 0,
      status: 'IN_PROGRESS',
      startDate: new Date().toISOString().slice(0, 10),
      targetDate: targetDate || new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 10),
      notes,
    });

    setShowOrderModal(false);
    setTargetSku('');
    setTargetQty(10);
    setNotes('');
    showToast(`สร้างคำสั่งผลิต ${orderNo} เรียบร้อยแล้ว`);
  };

  const handleCreateBOM = (e: React.FormEvent) => {
    e.preventDefault();
    const rm = rawMaterials.find((i) => i.code === bomRmSku);
    if (!bomFgSku || !rm) {
      showToast('กรุณาเลือกสินค้าและวัตถุดิบ');
      return;
    }

    onSaveBOM({
      finishedGoodSku: bomFgSku,
      rawMaterialSku: rm.code,
      rawMaterialName: rm.nameTh,
      requiredQtyPerUnit: bomQty,
    });

    setShowBomModal(false);
    setBomRmSku('');
    setBomQty(1);
    showToast('เพิ่มรายการสูตรการผลิต (BOM) สำเร็จ');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-900/40 via-slate-900 to-slate-900 border border-amber-500/30 rounded-2xl p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Factory className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">ฝ่ายผลิต (Production Department)</h2>
            <p className="text-xs text-amber-200/80">บริหารจัดการคำสั่งผลิต (Production Orders) และสูตรการผลิต (BOM)</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('orders')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition ${
              activeSubTab === 'orders'
                ? 'bg-amber-600 border-amber-500 text-white'
                : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            คำสั่งผลิต ({productionOrders.length})
          </button>
          <button
            onClick={() => setActiveSubTab('bom')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition ${
              activeSubTab === 'bom'
                ? 'bg-amber-600 border-amber-500 text-white'
                : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            สูตรการผลิต (BOM {boms.length})
          </button>
        </div>
      </div>

      {activeSubTab === 'orders' ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              รายการคำสั่งผลิตทั้งหมด
            </h3>
            <button
              onClick={() => setShowOrderModal(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-xl shadow-md transition"
            >
              <Plus className="w-4 h-4" />
              เปิดสั่งผลิตใหม่
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {productionOrders.length === 0 ? (
              <div className="col-span-full py-12 text-center text-slate-400 bg-slate-900/50 border border-slate-800 rounded-2xl">
                ยังไม่มีคำสั่งผลิต กด "เปิดสั่งผลิตใหม่" เพื่อเริ่มต้น
              </div>
            ) : (
              productionOrders.map((order) => {
                const bomItems = boms.filter((b) => b.finishedGoodSku === order.targetSku);
                return (
                  <div
                    key={order.id}
                    className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition space-y-4"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-xs font-mono font-bold text-amber-400">{order.orderNo}</div>
                        <h4 className="text-sm font-bold text-white mt-1">{order.targetName}</h4>
                        <div className="text-[11px] text-slate-400">SKU: {order.targetSku}</div>
                      </div>
                      <span
                        className={`px-2.5 py-1 text-[10px] font-bold rounded-full ${
                          order.status === 'COMPLETED'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : order.status === 'IN_PROGRESS'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {order.status === 'COMPLETED'
                          ? 'ผลิตเสร็จสมบูรณ์'
                          : order.status === 'IN_PROGRESS'
                          ? 'กำลังผลิต'
                          : 'ร่างคำสั่ง'}
                      </span>
                    </div>

                    <div className="bg-slate-950/60 rounded-xl p-3 text-xs space-y-2 border border-slate-800/80">
                      <div className="flex justify-between">
                        <span className="text-slate-400">จำนวนเป้าหมาย:</span>
                        <span className="font-bold text-amber-300">{order.targetQty} ชิ้น</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">วัตถุดิบที่ต้องใช้ (BOM):</span>
                        <span className="text-slate-300">{bomItems.length} รายการ</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">กำหนดเสร็จ:</span>
                        <span className="text-slate-300">{order.targetDate}</span>
                      </div>
                    </div>

                    {order.status === 'IN_PROGRESS' && (
                      <button
                        onClick={() => onUpdateOrderStatus(order.id, 'COMPLETED')}
                        className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-sm"
                      >
                        <CheckCircle className="w-4 h-4" />
                        เสร็จสิ้นการผลิต (ตัดสต๊อกวัตถุดิบ & เติมสินค้า)
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        /* BOM Subtab */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              รายการสูตรการผลิต (Bill of Materials)
            </h3>
            <button
              onClick={() => setShowBomModal(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-xl shadow-md transition"
            >
              <Plus className="w-4 h-4" />
              เพิ่มสูตร BOM
            </button>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="p-3">สินค้าสำเร็จรูป (FG)</th>
                  <th className="p-3">วัตถุดิบ/อะไหล่ที่ใช้ (Raw Material)</th>
                  <th className="p-3 text-right">อัตราส่วนต่อ 1 หน่วย FG</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {boms.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="p-6 text-center text-slate-500">
                      ยังไม่มีรายการ BOM
                    </td>
                  </tr>
                ) : (
                  boms.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-800/40">
                      <td className="p-3 font-semibold text-amber-300">{b.finishedGoodSku}</td>
                      <td className="p-3 text-slate-200">
                        {b.rawMaterialName} <span className="text-slate-500 font-mono">({b.rawMaterialSku})</span>
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-emerald-400">
                        {b.requiredQtyPerUnit}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* New Order Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-md text-white">
            <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
              <Factory className="w-4 h-4 text-amber-400" />
              เปิดสั่งผลิตใหม่ (New Production Order)
            </h3>
            <form onSubmit={handleCreateOrder} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">เลือกสินค้าสำเร็จรูปที่ผลิต</label>
                <select
                  value={targetSku}
                  onChange={(e) => setTargetSku(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                >
                  <option value="">-- เลือกสินค้า --</option>
                  {finishedGoods.map((fg) => (
                    <option key={fg.id} value={fg.code}>
                      {fg.code} - {fg.nameTh}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">จำนวนที่ต้องการผลิต</label>
                <input
                  type="number"
                  min="1"
                  value={targetQty}
                  onChange={(e) => setTargetQty(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">กำหนดส่งมอบงานผลิต</label>
                <input
                  type="date"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">หมายเหตุเพิ่มเติม</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white h-20"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowOrderModal(false)}
                  className="flex-1 py-2 bg-slate-800 rounded-xl font-semibold hover:bg-slate-700"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-600 rounded-xl font-semibold hover:bg-amber-500 text-white"
                >
                  ยืนยันเปิดคำสั่ง
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New BOM Modal */}
      {showBomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-md text-white">
            <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              เพิ่มสูตรวัตถุดิบ (BOM Mapping)
            </h3>
            <form onSubmit={handleCreateBOM} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">สินค้าสำเร็จรูป (Finished Good)</label>
                <select
                  value={bomFgSku}
                  onChange={(e) => setBomFgSku(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                >
                  <option value="">-- เลือก FG SKU --</option>
                  {finishedGoods.map((fg) => (
                    <option key={fg.id} value={fg.code}>
                      {fg.code} - {fg.nameTh}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">วัตถุดิบ/อะไหล่ที่ต้องใช้ (Raw Material)</label>
                <select
                  value={bomRmSku}
                  onChange={(e) => setBomRmSku(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                >
                  <option value="">-- เลือกวัตถุดิบ --</option>
                  {rawMaterials.map((rm) => (
                    <option key={rm.id} value={rm.code}>
                      {rm.code} - {rm.nameTh}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">อัตราส่วนใช้งาน ต่อ 1 FG</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={bomQty}
                  onChange={(e) => setBomQty(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBomModal(false)}
                  className="flex-1 py-2 bg-slate-800 rounded-xl font-semibold hover:bg-slate-700"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-600 rounded-xl font-semibold hover:bg-amber-500 text-white"
                >
                  บันทึกสูตร
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
