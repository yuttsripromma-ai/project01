import React, { useState, useEffect } from 'react';
import { FileSpreadsheet, RefreshCw, Plus, ExternalLink, Download, Upload, CheckCircle2, AlertCircle, HardDrive, Key } from 'lucide-react';
import { SheetsService, SpreadsheetFile } from '../../services/sheetsService';
import { DriveService, DriveAuthStatus } from '../../services/driveService';

interface GoogleSheetsModuleProps {
  getDatabaseData: () => any;
  onLoadDataFromSheets: (data: any) => void;
  showToast: (msg: string) => void;
}

export const GoogleSheetsModule: React.FC<GoogleSheetsModuleProps> = ({
  getDatabaseData,
  onLoadDataFromSheets,
  showToast,
}) => {
  const [authStatus, setAuthStatus] = useState<DriveAuthStatus>({ authenticated: false });
  const [loading, setLoading] = useState(true);
  const [spreadsheets, setSpreadsheets] = useState<SpreadsheetFile[]>([]);
  const [selectedSpreadsheetId, setSelectedSpreadsheetId] = useState<string>(() => {
    return localStorage.getItem('mdm_active_spreadsheet_id') || '';
  });
  const [syncing, setSyncing] = useState(false);
  const [loadingSheets, setLoadingSheets] = useState(false);
  const [creating, setCreating] = useState(false);

  const checkAuthAndFetchSheets = async () => {
    setLoading(true);
    try {
      const status = await DriveService.getAuthStatus();
      setAuthStatus(status);
      if (status.authenticated) {
        const files = await SheetsService.listSpreadsheets();
        setSpreadsheets(files);
        if (!selectedSpreadsheetId && files.length > 0) {
          setSelectedSpreadsheetId(files[0].id);
          localStorage.setItem('mdm_active_spreadsheet_id', files[0].id);
        }
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkAuthAndFetchSheets();
  }, []);

  const handleLogin = async () => {
    try {
      setLoading(true);
      await DriveService.loginWithGoogle();
      await checkAuthAndFetchSheets();
      showToast('เชื่อมต่อ Google Account สำเร็จ!');
    } catch (err: any) {
      showToast('ข้อผิดพลาดการเชื่อมต่อ: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNewSpreadsheet = async () => {
    if (!authStatus.authenticated) {
      await handleLogin();
      return;
    }
    setCreating(true);
    try {
      const res = await SheetsService.createSpreadsheet(`MDM_ERP_Database_${new Date().toISOString().slice(0, 10)}`);
      if (res.spreadsheetId) {
        setSelectedSpreadsheetId(res.spreadsheetId);
        localStorage.setItem('mdm_active_spreadsheet_id', res.spreadsheetId);
        showToast(`สร้าง Google Sheet ใหม่ "${res.title}" สำเร็จ!`);

        // Automatically initial sync data to the newly created sheet
        const currentData = getDatabaseData();
        await SheetsService.syncToSpreadsheet(res.spreadsheetId, currentData);
        await checkAuthAndFetchSheets();
      }
    } catch (err: any) {
      showToast('สร้าง Google Sheet ล้มเหลว: ' + err.message);
    } finally {
      setCreating(false);
    }
  };

  const handleSyncToSheets = async () => {
    if (!selectedSpreadsheetId) {
      showToast('กรุณาเลือกหรือสร้าง Google Sheet ก่อน');
      return;
    }
    setSyncing(true);
    try {
      const data = getDatabaseData();
      await SheetsService.syncToSpreadsheet(selectedSpreadsheetId, data);
      showToast('ซิงค์บันทึกข้อมูลไปยัง Google Sheets สำเร็จเรียบร้อยแล้ว!');
    } catch (err: any) {
      showToast('เกิดข้อผิดพลาดในการซิงค์: ' + err.message);
    } finally {
      setSyncing(false);
    }
  };

  const handleLoadFromSheets = async () => {
    if (!selectedSpreadsheetId) {
      showToast('กรุณาเลือก Google Sheet ก่อน');
      return;
    }
    if (!confirm('ต้องการโหลดข้อมูลจาก Google Sheets มาเขียนทับข้อมูลในระบบหรือไม่?')) {
      return;
    }
    setLoadingSheets(true);
    try {
      const res = await SheetsService.loadFromSpreadsheet(selectedSpreadsheetId);
      if (res.data) {
        onLoadDataFromSheets(res.data);
        showToast('ดึงข้อมูลจาก Google Sheets สำเร็จ!');
      }
    } catch (err: any) {
      showToast('เกิดข้อผิดพลาดในการดึงข้อมูล: ' + err.message);
    } finally {
      setLoadingSheets(false);
    }
  };

  const selectedSheetObj = spreadsheets.find((s) => s.id === selectedSpreadsheetId);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Google Sheets Database Engine</h2>
            <p className="text-xs text-emerald-200/80">จัดเก็บข้อมูลระบบคลัง อะไหล่ ฝ่ายผลิต และจัดส่งลงใน Google Sheets ของคุณแบบ Real-time</p>
          </div>
        </div>

        {!authStatus.authenticated ? (
          <button
            onClick={handleLogin}
            disabled={loading}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl shadow-md transition"
          >
            <Key className="w-4 h-4" />
            เชื่อมต่อ Google Account
          </button>
        ) : (
          <div className="flex items-center gap-2 bg-emerald-950/80 border border-emerald-800 rounded-xl p-2 px-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>เชื่อมต่อแล้ว: <strong>{authStatus.user?.email}</strong></span>
          </div>
        )}
      </div>

      {/* Main Control Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Sheet Selection */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-5">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            เลือกไฟล์ Google Sheet ที่ใช้เป็นฐานข้อมูล
          </h3>

          {!authStatus.authenticated ? (
            <div className="py-8 text-center text-slate-400 space-y-3">
              <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
              <p className="text-xs">กรุณากด "เชื่อมต่อ Google Account" เพื่อเข้าถึงและจัดการไฟล์ Google Sheets ของคุณ</p>
              <button
                onClick={handleLogin}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold"
              >
                เข้าสู่ระบบ Google
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5 font-medium">รายการ Spreadsheet ใน Google Drive ของคุณ</label>
                <div className="flex gap-2">
                  <select
                    value={selectedSpreadsheetId}
                    onChange={(e) => {
                      setSelectedSpreadsheetId(e.target.value);
                      localStorage.setItem('mdm_active_spreadsheet_id', e.target.value);
                    }}
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="">-- เลือก Google Sheet --</option>
                    {spreadsheets.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} (แก้ไขล่าสุด: {new Date(s.modifiedTime).toLocaleDateString('th-TH')})
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={checkAuthAndFetchSheets}
                    className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700"
                    title="รีเฟรชรายการ"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  onClick={handleCreateNewSpreadsheet}
                  disabled={creating}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl shadow-md transition disabled:opacity-50"
                >
                  <Plus className="w-4 h-4" />
                  {creating ? 'กำลังสร้าง Sheet...' : 'สร้าง Google Sheet ใหม่เป็นฐานข้อมูล'}
                </button>

                {selectedSpreadsheetId && (
                  <a
                    href={`https://docs.google.com/spreadsheets/d/${selectedSpreadsheetId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 font-semibold text-xs rounded-xl transition"
                  >
                    <ExternalLink className="w-4 h-4" />
                    เปิดดูใน Google Sheets
                  </a>
                )}
              </div>
            </div>
          )}

          {/* Table Tabs Explanation */}
          <div className="bg-slate-950/70 rounded-xl p-4 border border-slate-800 text-xs space-y-2">
            <h4 className="font-semibold text-slate-200">โครงสร้างตาราง (Sheet Tabs) ในฐานข้อมูล Google Sheets:</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 font-mono text-[11px] text-slate-300">
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg">1. RawMaterials</div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg">2. FinishedGoods</div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg">3. ProductionOrders</div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg">4. BOM</div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg">5. Shipments</div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg">6. InventoryLogs</div>
            </div>
          </div>
        </div>

        {/* Right Col: Sync Operations */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-3">
              สั่งงานซิงค์ข้อมูล (Database Actions)
            </h3>

            <p className="text-xs text-slate-400 leading-relaxed">
              คุณสามารถส่งข้อมูลจากระบบ Web App ไปเขียนลงใน Google Sheets หรือโหลดข้อมูลตารางจาก Google Sheets กลับเข้ามาใน Web App ได้ทุกเมื่อ
            </p>

            <div className="space-y-3 pt-2">
              <button
                onClick={handleSyncToSheets}
                disabled={syncing || !selectedSpreadsheetId}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition disabled:opacity-50"
              >
                <Upload className={`w-4 h-4 ${syncing ? 'animate-bounce' : ''}`} />
                <span>{syncing ? 'กำลังบันทึกลง Sheets...' : 'บันทึกข้อมูลปัจจุบันลง Google Sheets'}</span>
              </button>

              <button
                onClick={handleLoadFromSheets}
                disabled={loadingSheets || !selectedSpreadsheetId}
                className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                <Download className={`w-4 h-4 text-emerald-400 ${loadingSheets ? 'animate-bounce' : ''}`} />
                <span>{loadingSheets ? 'กำลังดึงข้อมูล...' : 'ดึงข้อมูลจาก Google Sheets เข้าสู่ระบบ'}</span>
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>ข้อมูลจะถูกซิงค์เป็นระบบตาราง สามารถนำไปทำ Dashboard บน Looker Studio หรือนำมาประมวลผลต่อได้ง่าย</span>
          </div>
        </div>

      </div>
    </div>
  );
};
