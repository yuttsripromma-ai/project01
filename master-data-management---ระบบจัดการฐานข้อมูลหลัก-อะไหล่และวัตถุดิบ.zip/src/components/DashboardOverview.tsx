import React from 'react';
import { ActiveTab, ActivityLog, Category, StorageLocation, MasterItem, Supplier, UOM } from '../types';
import {
  Box,
  Layers,
  MapPin,
  Truck,
  AlertTriangle,
  PlusCircle,
  FileSpreadsheet,
  ArrowRight,
  ShieldCheck,
  Building,
  TrendingDown,
  Tag,
  Clock,
  Printer
} from 'lucide-react';

interface DashboardOverviewProps {
  items: MasterItem[];
  uoms: UOM[];
  categories: Category[];
  locations: StorageLocation[];
  suppliers: Supplier[];
  logs: ActivityLog[];
  onNavigateTab: (tab: ActiveTab) => void;
  onOpenAddItemModal: () => void;
  onExportCSV: () => void;
  onExportExcel?: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  items,
  uoms,
  categories,
  locations,
  suppliers,
  logs,
  onNavigateTab,
  onOpenAddItemModal,
  onExportCSV,
  onExportExcel,
}) => {
  // Calculated stats
  const sparePartsCount = items.filter((i) => i.type === 'SPARE_PART').length;
  const rawMaterialsCount = items.filter((i) => i.type === 'RAW_MATERIAL').length;
  const consumablesCount = items.filter((i) => i.type === 'CONSUMABLE').length;
  const toolsCount = items.filter((i) => i.type === 'TOOL').length;

  const lowStockItems = items.filter((i) => i.currentStock <= i.reorderPoint);

  const totalValueTHB = items.reduce((sum, item) => sum + item.currentStock * item.unitCost, 0);

  // Category counts map
  const itemsPerCategory = categories.map((cat) => {
    const count = items.filter((i) => i.categoryId === cat.id).length;
    return {
      ...cat,
      itemCount: count,
    };
  });

  return (
    <div className="space-y-6">
      
      {/* Top Banner Alert if low stock exists */}
      {lowStockItems.length > 0 && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-amber-200">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-amber-500/20 rounded-lg text-amber-400 mt-0.5">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-amber-100 text-sm">
                การแจ้งเตือนจุดสั่งซื้อ (Reorder Point Alert): พบ {lowStockItems.length} รายการที่คงเหลือน้อยกว่าจุดสั่งซื้อ
              </h3>
              <p className="text-xs text-amber-300/80 mt-0.5">
                รายการเหล่านี้มีความเสี่ยงสินค้าหมดสต็อก แนะนำให้ประสานงานผู้จัดจำหน่ายเพื่อออกใบสั่งซื้อ (PO)
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('items')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-amber-500 text-slate-950 hover:bg-amber-400 rounded-lg transition shrink-0 cursor-pointer"
          >
            <span>ดูรายการเตือนสั่งซื้อ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total SKUs */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-sm hover:border-blue-500/50 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              จำนวน SKU ทั้งหมด
            </span>
            <div className="p-2 bg-blue-500/10 text-blue-400 rounded-xl">
              <Box className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white tracking-tight">{items.length}</span>
            <span className="text-xs text-slate-400">รายการในฐานข้อมูล</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
            <span>อะไหล่: <strong className="text-blue-300">{sparePartsCount}</strong></span>
            <span>วัตถุดิบ: <strong className="text-emerald-300">{rawMaterialsCount}</strong></span>
            <span>อื่นๆ: <strong className="text-amber-300">{consumablesCount + toolsCount}</strong></span>
          </div>
        </div>

        {/* Card 2: Inventory Value */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-sm hover:border-emerald-500/50 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              มูลค่าสินค้าในสต็อกรวม
            </span>
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-emerald-400 tracking-tight">
              ฿{totalValueTHB.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
            <span>คำนวณจากราคาต้นทุนต่อหน่วย (Cost)</span>
          </div>
        </div>

        {/* Card 3: Storage Locations */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-sm hover:border-amber-500/50 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              ตำแหน่งชั้นวาง (Locations)
            </span>
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl">
              <MapPin className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white tracking-tight">{locations.length}</span>
            <span className="text-xs text-slate-400">จุดเก็บชั้นวาง/Bin</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
            <span>หมวดหมู่: <strong className="text-white">{categories.length}</strong></span>
            <span>หน่วยนับ (UOM): <strong className="text-white">{uoms.length}</strong></span>
          </div>
        </div>

        {/* Card 4: Suppliers */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-sm hover:border-purple-500/50 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              ผู้จัดจำหน่าย (Suppliers)
            </span>
            <div className="p-2 bg-purple-500/10 text-purple-400 rounded-xl">
              <Truck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white tracking-tight">{suppliers.length}</span>
            <span className="text-xs text-slate-400">บริษัทในระบบ</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1 text-purple-300">
              <Building className="w-3.5 h-3.5" /> พร้อมเครดิตเทอม
            </span>
          </div>
        </div>

      </div>

      {/* Quick Action Bar */}
      <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm text-slate-300">
          <ShieldCheck className="w-4 h-4 text-blue-400" />
          <span className="font-semibold text-white">ทางลัดการจัดการ Master Data:</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenAddItemModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition shadow-sm cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>+ เพิ่มอะไหล่/วัตถุดิบ</span>
          </button>

          <button
            onClick={() => onNavigateTab('uom')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition cursor-pointer"
          >
            <span>+ จัดการหน่วยนับ (UOM)</span>
          </button>

          <button
            onClick={() => onNavigateTab('locations')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition cursor-pointer"
          >
            <span>+ เพิ่มชั้นวาง (Location)</span>
          </button>

          <button
            onClick={() => onNavigateTab('suppliers')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition cursor-pointer"
          >
            <span>+ เพิ่มผู้จัดจำหน่าย</span>
          </button>

          <button
            onClick={() => onNavigateTab('barcode')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-purple-700 hover:bg-purple-600 text-white rounded-lg transition shadow-sm cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>พิมพ์สติกเกอร์ตามคงเหลือ</span>
          </button>

          {onExportExcel && (
            <button
              onClick={onExportExcel}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition shadow-sm cursor-pointer"
              title="ส่งออกฐานข้อมูล Master Data ทั้งหมดเป็นไฟล์ Excel (.xlsx) แบบหลาย Sheet"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>ส่งออก Excel (.xlsx)</span>
            </button>
          )}

          <button
            onClick={onExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition cursor-pointer"
          >
            <span>ส่งออก CSV</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Category Distribution & Reorder Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Category Breakdown (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>โครงสร้างหมวดหมู่ Master Data (Category Breakdown)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                สัดส่วนจำนวน SKU ตามหมวดหมู่หลักในระบบ
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('categories')}
              className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 cursor-pointer"
            >
              <span>จัดการหมวดหมู่</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {itemsPerCategory.map((cat) => (
              <div
                key={cat.id}
                className="bg-slate-900/60 border border-slate-700/60 rounded-xl p-3.5 flex items-start justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${cat.color}`}>
                      {cat.code}
                    </span>
                    <span className="text-xs font-semibold text-slate-200">{cat.nameTh}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{cat.description}</p>
                </div>
                <div className="text-right">
                  <span className="text-base font-bold text-white">{cat.itemCount}</span>
                  <span className="text-[10px] text-slate-400 block">SKU</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Low Stock Watchlist (1 Col) */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-rose-400" />
              <span>รายการต้องสั่งซื้อด่วน</span>
            </h3>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-rose-500/20 text-rose-300 rounded-full border border-rose-500/30">
              {lowStockItems.length} รายการ
            </span>
          </div>

          {lowStockItems.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs bg-slate-900/40 rounded-xl border border-dashed border-slate-700">
              <ShieldCheck className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
              <p className="text-slate-200 font-medium">สต็อกทุกรายการอยู่ในเกณฑ์ปกติ</p>
              <p className="text-slate-400 text-[11px] mt-0.5">ไม่มีสินค้าลดต่ำกว่า Reorder Point</p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1 scrollbar-thin">
              {lowStockItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-slate-900/80 border border-rose-900/40 hover:border-rose-700/60 p-3 rounded-xl flex items-center justify-between transition text-xs"
                >
                  <div className="space-y-0.5 pr-2">
                    <span className="font-mono text-[11px] text-rose-300 font-semibold block">{item.code}</span>
                    <span className="text-slate-200 font-medium line-clamp-1">{item.nameTh}</span>
                    <span className="text-[10px] text-slate-400 block">
                      Reorder Point: {item.reorderPoint} | Min: {item.minStock}
                    </span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold rounded-lg text-xs block">
                      เหลือ {item.currentStock}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Activity Log Audit Trail */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <span>บันทึกประวัติการปรับปรุง Master Data (Audit Log)</span>
          </h3>
          <span className="text-xs text-slate-400">ล่าสุด 10 รายการ</span>
        </div>

        <div className="space-y-2">
          {logs.slice(0, 6).map((log) => (
            <div
              key={log.id}
              className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-slate-900/50 border border-slate-700/40"
            >
              <div className="flex items-center gap-2.5">
                <span
                  className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                    log.action === 'CREATE'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : log.action === 'UPDATE'
                      ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      : log.action === 'DELETE'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  }`}
                >
                  {log.action}
                </span>
                <span className="text-slate-200 font-semibold">{log.entityName}</span>
                <span className="text-slate-400 hidden sm:inline">- {log.details}</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">
                {new Date(log.timestamp).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
