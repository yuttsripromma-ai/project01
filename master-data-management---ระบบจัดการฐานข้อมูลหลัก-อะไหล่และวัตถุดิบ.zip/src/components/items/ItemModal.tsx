import React, { useState, useEffect } from 'react';
import { Category, ItemType, StorageLocation, MasterItem, MasterStatus, Supplier, UOM } from '../../types';
import { X, Save, Sparkles, Box, Tag, MapPin, Truck, AlertTriangle } from 'lucide-react';

interface ItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: MasterItem) => void;
  editingItem: MasterItem | null;
  categories: Category[];
  uoms: UOM[];
  locations: StorageLocation[];
  suppliers: Supplier[];
}

export const ItemModal: React.FC<ItemModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingItem,
  categories,
  uoms,
  locations,
  suppliers,
}) => {
  const [formData, setFormData] = useState<Partial<MasterItem>>({
    code: '',
    nameTh: '',
    nameEn: '',
    type: 'SPARE_PART',
    categoryId: categories[0]?.id || '',
    uomId: uoms[0]?.id || '',
    secondaryUomId: '',
    locationId: locations[0]?.id || '',
    supplierId: suppliers[0]?.id || '',
    minStock: 5,
    maxStock: 50,
    reorderPoint: 10,
    currentStock: 15,
    unitCost: 100,
    sellingPrice: 150,
    brand: '',
    modelNumber: '',
    barcode: '',
    specifications: '',
    status: 'ACTIVE',
  });

  useEffect(() => {
    if (editingItem) {
      setFormData(editingItem);
    } else {
      setFormData({
        code: 'PART-' + new Date().getFullYear() + '-' + Math.floor(100 + Math.random() * 900),
        nameTh: '',
        nameEn: '',
        type: 'SPARE_PART',
        categoryId: categories[0]?.id || '',
        uomId: uoms[0]?.id || '',
        secondaryUomId: '',
        locationId: locations[0]?.id || '',
        supplierId: suppliers[0]?.id || '',
        minStock: 5,
        maxStock: 50,
        reorderPoint: 10,
        currentStock: 15,
        unitCost: 100,
        sellingPrice: 150,
        brand: '',
        modelNumber: '',
        barcode: '885' + Math.floor(100000000 + Math.random() * 900000000),
        specifications: '',
        status: 'ACTIVE',
      });
    }
  }, [editingItem, isOpen, categories, uoms, locations, suppliers]);

  if (!isOpen) return null;

  const handleGenerateCode = () => {
    const prefix = formData.type === 'SPARE_PART' ? 'PART' : formData.type === 'RAW_MATERIAL' ? 'RAW' : formData.type === 'CONSUMABLE' ? 'CON' : 'TOOL';
    const rand = Math.floor(1000 + Math.random() * 9000);
    setFormData((prev) => ({ ...prev, code: `${prefix}-${new Date().getFullYear()}-${rand}` }));
  };

  const handleGenerateBarcode = () => {
    const rand = Math.floor(10000000000 + Math.random() * 90000000000);
    setFormData((prev) => ({ ...prev, barcode: `885${rand}` }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || !formData.nameTh || !formData.categoryId || !formData.uomId || !formData.locationId || !formData.supplierId) {
      alert('กรุณากรอกข้อมูลสำคัญให้ครบถ้วน (รหัส, ชื่อภาษาไทย, หมวดหมู่, หน่วยนับ, ชั้นวาง และผู้จัดจำหน่าย)');
      return;
    }

    const now = new Date().toISOString();
    const finalItem: MasterItem = {
      id: editingItem ? editingItem.id : 'item-' + Date.now(),
      code: formData.code.trim(),
      nameTh: formData.nameTh.trim(),
      nameEn: formData.nameEn?.trim() || '',
      type: (formData.type as ItemType) || 'SPARE_PART',
      categoryId: formData.categoryId!,
      uomId: formData.uomId!,
      secondaryUomId: formData.secondaryUomId || undefined,
      locationId: formData.locationId!,
      supplierId: formData.supplierId!,
      minStock: Number(formData.minStock) || 0,
      maxStock: Number(formData.maxStock) || 0,
      reorderPoint: Number(formData.reorderPoint) || 0,
      currentStock: Number(formData.currentStock) || 0,
      unitCost: Number(formData.unitCost) || 0,
      sellingPrice: Number(formData.sellingPrice) || 0,
      brand: formData.brand || '',
      modelNumber: formData.modelNumber || '',
      barcode: formData.barcode || '',
      specifications: formData.specifications || '',
      status: (formData.status as MasterStatus) || 'ACTIVE',
      createdAt: editingItem ? editingItem.createdAt : now,
      updatedAt: now,
    };

    onSave(finalItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden my-8">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Box className="w-5 h-5 text-blue-400" />
            <h2 className="text-base font-bold text-white">
              {editingItem ? 'แก้ไขข้อมูลอะไหล่/วัตถุดิบ (Edit Master Item)' : 'เพิ่มอะไหล่/วัตถุดิบใหม่ (Add Master Item)'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto scrollbar-thin">
          
          {/* Section 1: General Info */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-3 flex items-center gap-1.5">
              <Tag className="w-4 h-4" /> 1. ข้อมูลทั่วไปและรหัสกำกับ (Basic Identification)
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Type */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ประเภท (Item Type) <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as ItemType })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="SPARE_PART">⚙️ อะไหล่ (Spare Part)</option>
                  <option value="RAW_MATERIAL">🧱 วัตถุดิบ (Raw Material)</option>
                  <option value="CONSUMABLE">🧪 วัสดุสิ้นเปลือง (Consumable)</option>
                  <option value="TOOL">🔧 เครื่องมือ (Tool / Equipment)</option>
                </select>
              </div>

              {/* Code SKU */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-semibold text-slate-300">
                    รหัสสินค้า / SKU <span className="text-rose-400">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateCode}
                    className="text-[10px] text-blue-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" /> สุ่มรหัส
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  placeholder="เช่น PART-2026-001"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              {/* Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ชื่อรายการ <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.nameTh}
                  onChange={(e) => setFormData({ ...formData, nameTh: e.target.value })}
                  placeholder="เช่น เบรกเกอร์ 3 เฟส 32A"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  หมวดหมู่ (Category) <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formData.categoryId}
                  onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      [{cat.code}] {cat.nameTh}
                    </option>
                  ))}
                </select>
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  สถานะการใช้งาน
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as MasterStatus })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="ACTIVE">🟢 ใช้งานปกติ (Active)</option>
                  <option value="INACTIVE">🔴 ยกเลิกใช้งาน (Inactive)</option>
                </select>
              </div>

            </div>
          </div>

          {/* Section 2: UOM & Location & Supplier */}
          <div className="pt-4 border-t border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3 flex items-center gap-1.5">
              <MapPin className="w-4 h-4" /> 2. หน่วยนับ, ตำแหน่งชั้นวาง และผู้จัดจำหน่าย (UOM, Location & Supplier)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              
              {/* Primary UOM */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  หน่วยนับหลัก (Primary UOM) <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formData.uomId}
                  onChange={(e) => setFormData({ ...formData, uomId: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {uoms.map((uom) => (
                    <option key={uom.id} value={uom.id}>
                      {uom.nameTh} ({uom.symbol})
                    </option>
                  ))}
                </select>
              </div>

              {/* Secondary UOM */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  หน่วยนับบรรจุภัณฑ์ (Secondary UOM)
                </label>
                <select
                  value={formData.secondaryUomId || ''}
                  onChange={(e) => setFormData({ ...formData, secondaryUomId: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="">-- ไม่ระบุ --</option>
                  {uoms.map((uom) => (
                    <option key={uom.id} value={uom.id}>
                      {uom.nameTh} ({uom.symbol})
                    </option>
                  ))}
                </select>
              </div>

              {/* Location Shelf */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ที่เก็บ / ชั้นวาง (Location) <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formData.locationId}
                  onChange={(e) => setFormData({ ...formData, locationId: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {locations.map((loc) => (
                    <option key={loc.id} value={loc.id}>
                      [{loc.code}] {loc.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Supplier Primary */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ผู้จัดจำหน่ายหลัก (Primary Supplier) <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formData.supplierId}
                  onChange={(e) => setFormData({ ...formData, supplierId: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {suppliers.map((sup) => (
                    <option key={sup.id} value={sup.id}>
                      [{sup.code}] {sup.companyName} (เครดิต: {sup.paymentTerm})
                    </option>
                  ))}
                </select>
              </div>

            </div>
          </div>

          {/* Section 3: Inventory Stock Controls & Cost */}
          <div className="pt-4 border-t border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-3 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" /> 3. พารามิเตอร์คงคลังและราคา (Inventory & Pricing Controls)
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  จำนวนคงเหลือปัจจุบัน
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.currentStock}
                  onChange={(e) => setFormData({ ...formData, currentStock: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-amber-300 mb-1">
                  จุดสั่งซื้อ (Reorder Point)
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.reorderPoint}
                  onChange={(e) => setFormData({ ...formData, reorderPoint: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-amber-500/40 rounded-lg px-3 py-2 text-xs text-amber-300 font-bold focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  สต็อกขั้นต่ำ (Min)
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.minStock}
                  onChange={(e) => setFormData({ ...formData, minStock: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  สต็อกสูงสุด (Max)
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.maxStock}
                  onChange={(e) => setFormData({ ...formData, maxStock: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-emerald-300 mb-1">
                  ราคาต้นทุนต่อหน่วย (฿)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.unitCost}
                  onChange={(e) => setFormData({ ...formData, unitCost: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-emerald-500/40 rounded-lg px-3 py-2 text-xs text-emerald-300 font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ราคามาตรฐาน/จำหน่าย (฿)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.sellingPrice}
                  onChange={(e) => setFormData({ ...formData, sellingPrice: Number(e.target.value) })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ยี่ห้อ / แบรนด์ (Brand)
                </label>
                <input
                  type="text"
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  placeholder="เช่น SKF, Schneider"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  รุ่น / Model Number
                </label>
                <input
                  type="text"
                  value={formData.modelNumber}
                  onChange={(e) => setFormData({ ...formData, modelNumber: e.target.value })}
                  placeholder="เช่น 6205-2RSH"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

            </div>
          </div>

          {/* Section 4: Specifications & Barcode */}
          <div className="pt-4 border-t border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-purple-400 mb-3 flex items-center gap-1.5">
              <Truck className="w-4 h-4" /> 4. คุณลักษณะเฉพาะและบาร์โค้ด (Specifications & Barcode)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-semibold text-slate-300">
                    รหัสบาร์โค้ด (Barcode EAN-13)
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="text-[10px] text-purple-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" /> สุ่มบาร์โค้ด
                  </button>
                </div>
                <input
                  type="text"
                  value={formData.barcode}
                  onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                  placeholder="เช่น 8851234567890"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  คุณลักษณะเฉพาะ / สเปก (Specifications / Attributes)
                </label>
                <textarea
                  rows={2}
                  value={formData.specifications}
                  onChange={(e) => setFormData({ ...formData, specifications: e.target.value })}
                  placeholder="เช่น ขนาดความกว้าง-ยาว-หนา, ค่าโวลต์, แรงดันใช้งาน, มาตรฐานอุตสาหกรรม"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-xs text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

            </div>
          </div>

          {/* Action Footer */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow-lg transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{editingItem ? 'บันทึกการแก้ไข' : 'บันทึกอะไหล่/วัตถุดิบ'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
