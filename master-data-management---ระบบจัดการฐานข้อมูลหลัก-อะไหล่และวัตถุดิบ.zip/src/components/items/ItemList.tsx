import React, { useState, useMemo } from 'react';
import { Category, StorageLocation, MasterItem, Supplier, UOM } from '../../types';
import {
  Search,
  Plus,
  Edit3,
  Trash2,
  Copy,
  AlertTriangle,
  FileText,
  MapPin,
  Tag,
  Truck,
  Filter,
  CheckCircle2,
  XCircle,
  LayoutGrid,
  List,
  Printer,
  QrCode,
  FileSpreadsheet
} from 'lucide-react';

interface ItemListProps {
  items: MasterItem[];
  categories: Category[];
  uoms: UOM[];
  locations: StorageLocation[];
  suppliers: Supplier[];
  onAddItem: () => void;
  onEditItem: (item: MasterItem) => void;
  onDuplicateItem: (item: MasterItem) => void;
  onDeleteItem: (itemId: string) => void;
  onPrintItemSticker?: (item?: MasterItem) => void;
  onExportExcel?: (filteredItems?: MasterItem[]) => void;
}

export const ItemList: React.FC<ItemListProps> = ({
  items,
  categories,
  uoms,
  locations,
  suppliers,
  onAddItem,
  onEditItem,
  onDuplicateItem,
  onDeleteItem,
  onPrintItemSticker,
  onExportExcel,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedLocation, setSelectedLocation] = useState<string>('ALL');
  const [selectedSupplier, setSelectedSupplier] = useState<string>('ALL');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'LOW_STOCK' | 'IN_STOCK' | 'OUT_OF_STOCK'>('ALL');
  const [viewMode, setViewMode] = useState<'TABLE' | 'GRID'>('TABLE');

  // Lookup maps for fast text rendering
  const catMap = useMemo(() => new Map<string, Category>(categories.map((c) => [c.id, c])), [categories]);
  const uomMap = useMemo(() => new Map<string, UOM>(uoms.map((u) => [u.id, u])), [uoms]);
  const locMap = useMemo(() => new Map<string, StorageLocation>(locations.map((l) => [l.id, l])), [locations]);
  const supMap = useMemo(() => new Map<string, Supplier>(suppliers.map((s) => [s.id, s])), [suppliers]);

  // Filtered Items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Search term
      const query = searchTerm.toLowerCase();
      const matchSearch =
        item.code.toLowerCase().includes(query) ||
        item.nameTh.toLowerCase().includes(query) ||
        item.nameEn.toLowerCase().includes(query) ||
        (item.brand && item.brand.toLowerCase().includes(query)) ||
        (item.modelNumber && item.modelNumber.toLowerCase().includes(query)) ||
        (item.barcode && item.barcode.toLowerCase().includes(query));

      if (!matchSearch) return false;

      // Type
      if (selectedType !== 'ALL' && item.type !== selectedType) return false;

      // Category
      if (selectedCategory !== 'ALL' && item.categoryId !== selectedCategory) return false;

      // Location
      if (selectedLocation !== 'ALL' && item.locationId !== selectedLocation) return false;

      // Supplier
      if (selectedSupplier !== 'ALL' && item.supplierId !== selectedSupplier) return false;

      // Stock filter
      if (stockFilter === 'LOW_STOCK' && item.currentStock > item.reorderPoint) return false;
      if (stockFilter === 'OUT_OF_STOCK' && item.currentStock > 0) return false;
      if (stockFilter === 'IN_STOCK' && item.currentStock <= 0) return false;

      return true;
    });
  }, [items, searchTerm, selectedType, selectedCategory, selectedLocation, selectedSupplier, stockFilter]);

  return (
    <div className="space-y-4">
      
      {/* Top Filter Controls */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 shadow-sm space-y-3">
        
        {/* Row 1: Search & Add */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ค้นหา SKU, ชื่อรายการภาษาไทย/อังกฤษ, ยี่ห้อ, รุ่น หรือ บาร์โค้ด..."
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500 outline-none"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>

          {/* Action buttons & View toggles */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-900 rounded-lg p-1 border border-slate-700/80">
              <button
                onClick={() => setViewMode('TABLE')}
                className={`p-1.5 rounded-md text-xs cursor-pointer ${
                  viewMode === 'TABLE' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="มุมมองตาราง (Table View)"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('GRID')}
                className={`p-1.5 rounded-md text-xs cursor-pointer ${
                  viewMode === 'GRID' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="มุมมองการ์ด (Grid View)"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>

            {onPrintItemSticker && (
              <button
                onClick={() => onPrintItemSticker()}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white rounded-xl shadow-md transition cursor-pointer shrink-0"
                title="พิมพ์สติกเกอร์บาร์โค้ดตามจำนวนคงเหลือ"
              >
                <Printer className="w-4 h-4" />
                <span>พิมพ์สติกเกอร์ตามคงเหลือ</span>
              </button>
            )}

            {onExportExcel && (
              <button
                onClick={() => onExportExcel(filteredItems)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-md transition cursor-pointer shrink-0"
                title="ส่งออกรายการ Master Items ที่กรองอยู่เป็นไฟล์ Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>ส่งออก Excel</span>
              </button>
            )}

            <button
              onClick={onAddItem}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-md transition cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>+ เพิ่มอะไหล่/วัตถุดิบ</span>
            </button>
          </div>

        </div>

        {/* Row 2: Select Filters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2.5 pt-2 border-t border-slate-700/60 text-xs">
          
          {/* Type Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">ประเภท (Type)</label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">ทุกประเภท (All Types)</option>
              <option value="SPARE_PART">อะไหล่ (Spare Part)</option>
              <option value="RAW_MATERIAL">วัตถุดิบ (Raw Material)</option>
              <option value="CONSUMABLE">วัสดุสิ้นเปลือง (Consumable)</option>
              <option value="TOOL">เครื่องมือ (Tool)</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">หมวดหมู่ (Category)</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">ทุกหมวดหมู่ (All Categories)</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nameTh}
                </option>
              ))}
            </select>
          </div>

          {/* Location Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">ชั้นวาง (Location)</label>
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">ทุกจุดชั้นวาง (All Locations)</option>
              {locations.map((l) => (
                <option key={l.id} value={l.id}>
                  [{l.code}] {l.name}
                </option>
              ))}
            </select>
          </div>

          {/* Supplier Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">ผู้จัดจำหน่าย (Supplier)</label>
            <select
              value={selectedSupplier}
              onChange={(e) => setSelectedSupplier(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">ทุกผู้จัดจำหน่าย (All Suppliers)</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.companyName}
                </option>
              ))}
            </select>
          </div>

          {/* Stock Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 mb-1">สถานะสต็อก (Stock Status)</label>
            <select
              value={stockFilter}
              onChange={(e) => setStockFilter(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-amber-300 font-semibold outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">ทุกสถานะสต็อก</option>
              <option value="LOW_STOCK">⚠️ ต้องสั่งเพิ่ม (Low Stock)</option>
              <option value="IN_STOCK">✅ มีพร้อมจ่าย (In Stock)</option>
              <option value="OUT_OF_STOCK">❌ สต็อกหมด (Out of Stock)</option>
            </select>
          </div>

        </div>

        {/* Filter Summary Results */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
          <span>
            พบทั้งหมด <strong className="text-white">{filteredItems.length}</strong> จาก {items.length} รายการ Master Data
          </span>
          {(selectedType !== 'ALL' || selectedCategory !== 'ALL' || selectedLocation !== 'ALL' || selectedSupplier !== 'ALL' || stockFilter !== 'ALL' || searchTerm) && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedType('ALL');
                setSelectedCategory('ALL');
                setSelectedLocation('ALL');
                setSelectedSupplier('ALL');
                setStockFilter('ALL');
              }}
              className="text-xs text-blue-400 hover:underline cursor-pointer"
            >
              ล้างตัวกรองทั้งหมด
            </button>
          )}
        </div>

      </div>

      {/* Main Content: Table or Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-12 text-center text-slate-400">
          <FileText className="w-12 h-12 text-slate-500 mx-auto mb-3 opacity-60" />
          <p className="text-base font-semibold text-slate-200">ไม่พบรายการอะไหล่หรือวัตถุดิบตามเงื่อนไขที่ระบุ</p>
          <p className="text-xs text-slate-400 mt-1">ลองเปลี่ยนคำค้นหา หรือคลิกเพิ่มรายการใหม่ด้านบน</p>
        </div>
      ) : viewMode === 'TABLE' ? (
        
        /* Table View */
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-200 border-collapse">
              <thead className="bg-slate-900/90 text-slate-400 uppercase font-semibold border-b border-slate-700/80 text-[11px]">
                <tr>
                  <th className="py-3 px-4">รหัส SKU / บาร์โค้ด</th>
                  <th className="py-3 px-4">ชื่อรายการ</th>
                  <th className="py-3 px-4">ประเภท & หมวดหมู่</th>
                  <th className="py-3 px-4">ชั้นวาง (Location)</th>
                  <th className="py-3 px-4">ผู้จัดจำหน่าย</th>
                  <th className="py-3 px-4 text-center">คงเหลือ / Reorder</th>
                  <th className="py-3 px-4 text-right">ต้นทุน (฿)</th>
                  <th className="py-3 px-4 text-center">สถานะ</th>
                  <th className="py-3 px-4 text-center">จัดการ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/60">
                {filteredItems.map((item) => {
                  const cat = catMap.get(item.categoryId);
                  const uom = uomMap.get(item.uomId);
                  const loc = locMap.get(item.locationId);
                  const sup = supMap.get(item.supplierId);
                  const isLowStock = item.currentStock <= item.reorderPoint;

                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-700/40 transition group"
                    >
                      {/* SKU & Barcode */}
                      <td className="py-3.5 px-4">
                        <span className="font-mono font-bold text-blue-300 block">{item.code}</span>
                        {item.barcode && (
                          <span className="font-mono text-[10px] text-slate-400 block mt-0.5">
                            BC: {item.barcode}
                          </span>
                        )}
                      </td>

                      {/* Name */}
                      <td className="py-3.5 px-4 max-w-xs">
                        <span className="font-semibold text-white block leading-snug">{item.nameTh}</span>
                        {(item.brand || item.modelNumber) && (
                          <span className="text-[10px] text-amber-300/90 block mt-0.5">
                            {item.brand} {item.modelNumber && `(${item.modelNumber})`}
                          </span>
                        )}
                      </td>

                      {/* Type & Category */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded mb-1 ${
                            item.type === 'SPARE_PART'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              : item.type === 'RAW_MATERIAL'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : item.type === 'CONSUMABLE'
                              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {item.type === 'SPARE_PART'
                            ? 'อะไหล่'
                            : item.type === 'RAW_MATERIAL'
                            ? 'วัตถุดิบ'
                            : item.type === 'CONSUMABLE'
                            ? 'วัสดุสิ้นเปลือง'
                            : 'เครื่องมือ'}
                        </span>
                        {cat && (
                          <span className="text-[11px] text-slate-300 block">{cat.nameTh}</span>
                        )}
                      </td>

                      {/* Location */}
                      <td className="py-3.5 px-4">
                        {loc ? (
                          <div className="space-y-0.5">
                            <span className="font-mono text-[11px] font-semibold text-emerald-300 block">
                              {loc.code}
                            </span>
                            <span className="text-[10px] text-slate-400 block line-clamp-1">{loc.name}</span>
                          </div>
                        ) : (
                          <span className="text-slate-500">-</span>
                        )}
                      </td>

                      {/* Supplier */}
                      <td className="py-3.5 px-4 max-w-[150px]">
                        {sup ? (
                          <span className="text-slate-300 font-medium line-clamp-1 block" title={sup.companyName}>
                            {sup.companyName}
                          </span>
                        ) : (
                          <span className="text-slate-500">-</span>
                        )}
                      </td>

                      {/* Current Stock */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="inline-flex flex-col items-center">
                          <span
                            className={`px-2.5 py-1 font-extrabold text-xs rounded-lg border ${
                              isLowStock
                                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                                : 'bg-slate-900 text-slate-100 border-slate-700'
                            }`}
                          >
                            {item.currentStock} {uom?.symbol || ''}
                          </span>
                          <span className="text-[10px] text-slate-400 mt-1">
                            (Min {item.minStock} / ROP {item.reorderPoint})
                          </span>
                        </div>
                      </td>

                      {/* Cost */}
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400">
                        ฿{item.unitCost.toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 text-center">
                        {item.status === 'ACTIVE' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                            <CheckCircle2 className="w-3 h-3" /> ใช้งาน
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-400 bg-slate-700/50 px-2 py-0.5 rounded-full">
                            <XCircle className="w-3 h-3" /> ยกเลิก
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center space-x-1.5">
                          {onPrintItemSticker && (
                            <button
                              onClick={() => onPrintItemSticker(item)}
                              className="p-1.5 rounded-lg bg-slate-700 hover:bg-purple-600 text-slate-300 hover:text-white transition cursor-pointer"
                              title={`พิมพ์สติกเกอร์บาร์โค้ด (${item.currentStock} ใบ)`}
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            onClick={() => onEditItem(item)}
                            className="p-1.5 rounded-lg bg-slate-700 hover:bg-blue-600 text-slate-300 hover:text-white transition cursor-pointer"
                            title="แก้ไขข้อมูล (Edit)"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDuplicateItem(item)}
                            className="p-1.5 rounded-lg bg-slate-700 hover:bg-emerald-600 text-slate-300 hover:text-white transition cursor-pointer"
                            title="คัดลอกสร้างใหม่ (Duplicate)"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteItem(item.id)}
                            className="p-1.5 rounded-lg bg-slate-700 hover:bg-rose-600 text-slate-300 hover:text-white transition cursor-pointer"
                            title="ลบรายการ (Delete)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        
        /* Grid View */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item) => {
            const cat = catMap.get(item.categoryId);
            const uom = uomMap.get(item.uomId);
            const loc = locMap.get(item.locationId);
            const sup = supMap.get(item.supplierId);
            const isLowStock = item.currentStock <= item.reorderPoint;

            return (
              <div
                key={item.id}
                className="bg-slate-800/90 border border-slate-700/80 hover:border-blue-500/50 rounded-2xl p-4 shadow-sm flex flex-col justify-between transition space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="font-mono font-bold text-xs text-blue-300 px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/20">
                      {item.code}
                    </span>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                        item.type === 'SPARE_PART'
                          ? 'bg-blue-500/20 text-blue-300'
                          : item.type === 'RAW_MATERIAL'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : item.type === 'CONSUMABLE'
                          ? 'bg-purple-500/20 text-purple-300'
                          : 'bg-amber-500/20 text-amber-300'
                      }`}
                    >
                      {item.type === 'SPARE_PART' ? 'อะไหล่' : item.type === 'RAW_MATERIAL' ? 'วัตถุดิบ' : item.type === 'CONSUMABLE' ? 'วัสดุสิ้นเปลือง' : 'เครื่องมือ'}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-white leading-snug line-clamp-2">{item.nameTh}</h4>

                  <div className="mt-3 space-y-1.5 text-xs text-slate-300 pt-3 border-t border-slate-700/60">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">หมวดหมู่:</span>
                      <span className="font-semibold text-slate-200">{cat?.nameTh || '-'}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">ที่เก็บ / ชั้นวาง:</span>
                      <span className="font-mono font-semibold text-emerald-300">{loc?.code || '-'}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">ผู้จัดจำหน่าย:</span>
                      <span className="font-semibold text-slate-300 truncate max-w-[150px]">{sup?.companyName || '-'}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] text-slate-400 block">คงเหลือ</span>
                    <span
                      className={`text-sm font-extrabold ${
                        isLowStock ? 'text-rose-400 animate-pulse' : 'text-white'
                      }`}
                    >
                      {item.currentStock} {uom?.symbol || ''}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">ราคาต้นทุน</span>
                    <span className="text-xs font-bold text-emerald-400 font-mono">
                      ฿{item.unitCost.toLocaleString('th-TH')}
                    </span>
                  </div>

                  <div className="flex items-center space-x-1">
                    {onPrintItemSticker && (
                      <button
                        onClick={() => onPrintItemSticker(item)}
                        className="p-1.5 rounded-lg bg-slate-700 hover:bg-purple-600 text-slate-200 hover:text-white transition cursor-pointer"
                        title={`พิมพ์สติกเกอร์บาร์โค้ด (${item.currentStock} ใบ)`}
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => onEditItem(item)}
                      className="p-1.5 rounded-lg bg-slate-700 hover:bg-blue-600 text-slate-200 hover:text-white transition cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      className="p-1.5 rounded-lg bg-slate-700 hover:bg-rose-600 text-slate-200 hover:text-white transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
