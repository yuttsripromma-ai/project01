import React, { useState, useEffect } from 'react';
import { StorageLocation, MasterItem, Supplier } from '../../types';
import {
  QrCode,
  Printer,
  Check,
  Search,
  Box,
  MapPin,
  RefreshCw,
  Sliders,
  Sparkles,
  Layers,
  CheckSquare,
  Square,
  AlertCircle
} from 'lucide-react';

interface BarcodeGeneratorProps {
  items: MasterItem[];
  locations: StorageLocation[];
  suppliers: Supplier[];
}

type PrintQtyMode = 'STOCK_QTY' | 'ONE_EACH' | 'CUSTOM';
type LabelLayoutMode = 'A4_2COL' | 'A4_3COL' | 'A4_4COL' | 'THERMAL_ROLL';

export const BarcodeGenerator: React.FC<BarcodeGeneratorProps> = ({
  items,
  locations,
  suppliers,
}) => {
  // Mode: Default to printing according to current stock quantity!
  const [qtyMode, setQtyMode] = useState<PrintQtyMode>('STOCK_QTY');
  const [layoutMode, setLayoutMode] = useState<LabelLayoutMode>('A4_3COL');

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('ALL');
  const [selectedLocationFilter, setSelectedLocationFilter] = useState('ALL');

  // Selected item IDs
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>(
    items.filter((i) => i.currentStock > 0).slice(0, 6).map((i) => i.id)
  );

  // Custom quantities per item map: { itemId: quantityToPrint }
  const [customQuantities, setCustomQuantities] = useState<Record<string, number>>({});

  // Display Customization Toggles
  const [showBarcode, setShowBarcode] = useState(true);
  const [showLocation, setShowLocation] = useState(true);
  const [showSequence, setShowSequence] = useState(true);
  const [showPrice, setShowPrice] = useState(false);
  const [showSupplier, setShowSupplier] = useState(true);
  const [showPrintDate, setShowPrintDate] = useState(true);

  // Initialize or update custom quantities when items change
  useEffect(() => {
    const initialQty: Record<string, number> = {};
    items.forEach((item) => {
      initialQty[item.id] = item.currentStock > 0 ? item.currentStock : 1;
    });
    setCustomQuantities(initialQty);
  }, [items]);

  // Lookup maps
  const locMap = new Map<string, StorageLocation>(locations.map((l) => [l.id, l]));
  const supMap = new Map<string, Supplier>(suppliers.map((s) => [s.id, s]));

  // Filter items for selection
  const filteredItems = items.filter((item) => {
    const query = searchTerm.toLowerCase();
    const matchSearch =
      item.code.toLowerCase().includes(query) ||
      item.nameTh.toLowerCase().includes(query) ||
      item.nameEn.toLowerCase().includes(query) ||
      (item.barcode && item.barcode.includes(query)) ||
      (item.brand && item.brand.toLowerCase().includes(query));

    if (!matchSearch) return false;
    if (selectedCategoryFilter !== 'ALL' && item.categoryId !== selectedCategoryFilter) return false;
    if (selectedLocationFilter !== 'ALL' && item.locationId !== selectedLocationFilter) return false;

    return true;
  });

  // Calculate copies for an item based on current qtyMode
  const getItemCopies = (item: MasterItem): number => {
    if (qtyMode === 'STOCK_QTY') {
      return Math.max(0, item.currentStock);
    }
    if (qtyMode === 'ONE_EACH') {
      return 1;
    }
    return customQuantities[item.id] ?? (item.currentStock > 0 ? item.currentStock : 1);
  };

  // Quick Action Selection Helpers
  const selectAllFiltered = () => {
    setSelectedItemIds(filteredItems.map((i) => i.id));
  };

  const deselectAll = () => {
    setSelectedItemIds([]);
  };

  const selectInStockOnly = () => {
    const inStock = filteredItems.filter((i) => i.currentStock > 0).map((i) => i.id);
    setSelectedItemIds(inStock);
  };

  const toggleSelectItem = (id: string) => {
    if (selectedItemIds.includes(id)) {
      setSelectedItemIds(selectedItemIds.filter((i) => i !== id));
    } else {
      setSelectedItemIds([...selectedItemIds, id]);
    }
  };

  const updateCustomQty = (itemId: string, val: number) => {
    setCustomQuantities((prev) => ({
      ...prev,
      [itemId]: Math.max(1, val),
    }));
  };

  // Set all selected items print count = current stock
  const applyStockQtyToCustom = () => {
    const updated = { ...customQuantities };
    items.forEach((item) => {
      updated[item.id] = Math.max(0, item.currentStock);
    });
    setCustomQuantities(updated);
    setQtyMode('STOCK_QTY');
  };

  // Selected items list
  const selectedItems = items.filter((i) => selectedItemIds.includes(i.id));

  // Flattened stickers array for render preview & printing
  // Example: Item A (qty 3) -> [ {item, index: 1, total: 3}, {item, index: 2, total: 3}, {item, index: 3, total: 3} ]
  const stickerInstances = selectedItems.flatMap((item) => {
    const count = getItemCopies(item);
    if (count <= 0) return [];
    return Array.from({ length: count }, (_, idx) => ({
      item,
      instanceIndex: idx + 1,
      totalInstances: count,
    }));
  });

  const handlePrint = () => {
    window.print();
  };

  const currentDateStr = new Date().toLocaleDateString('th-TH', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  return (
    <div className="space-y-6">
      
      {/* Print Specific CSS to ensure clean sticker print without dark backgrounds or navbar */}
      <style>{`
        @media print {
          /* Hide headers, sidebars, buttons, control bars */
          body {
            background-color: #ffffff !important;
            color: #000000 !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          header, nav, footer, .no-print, button, input, select {
            display: none !important;
          }
          .printable-area {
            background-color: #ffffff !important;
            color: #000000 !important;
            padding: 0 !important;
            margin: 0 !important;
            border: none !important;
            box-shadow: none !important;
          }
          .sticker-card {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
            border: 1px solid #000000 !important;
            box-shadow: none !important;
            background: #ffffff !important;
            color: #000000 !important;
          }
        }
      `}</style>

      {/* Header & Main Print Action Button */}
      <div className="no-print bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-blue-600/30 text-blue-400 rounded-xl border border-blue-500/40">
              <QrCode className="w-6 h-6" />
            </span>
            <div>
              <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                <span>ระบบพิมพ์สติกเกอร์บาร์โค้ดอะไหล่ตามจำนวนคงเหลือ</span>
                <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] rounded-full font-bold">
                  Stock Auto-Sync
                </span>
              </h2>
              <p className="text-xs text-slate-300 mt-1">
                สร้างและพิมพ์ลาเบล/สติกเกอร์รหัสอะไหล่พร้อมบาร์โค้ดและพิกัดชั้นวาง โดยคำนวณจำนวนแผ่นตามสต็อกคงเหลือจริงในคลังโดยอัตโนมัติ
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="text-right hidden lg:block">
            <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
              ยอดพิมพ์สติกเกอร์รวม
            </span>
            <span className="text-xl font-extrabold text-emerald-400 font-mono">
              {stickerInstances.length} ใบ ({selectedItems.length} SKU)
            </span>
          </div>

          <button
            onClick={handlePrint}
            disabled={stickerInstances.length === 0}
            className="inline-flex items-center gap-2 px-6 py-3 text-xs font-extrabold bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl shadow-xl transition cursor-pointer"
          >
            <Printer className="w-5 h-5" />
            <span>พิมพ์สติกเกอร์ทั้งหมด ({stickerInstances.length} ใบ)</span>
          </button>
        </div>
      </div>

      {/* Control Panel: Quantity Strategy & Sticker Layout Settings */}
      <div className="no-print bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-sm space-y-4">
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
          
          {/* Section 1: Print Quantity Strategy */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>1. โหมดกำหนดจำนวนพิมพ์สติกเกอร์ (Print Quantity Strategy):</span>
            </label>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={applyStockQtyToCustom}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 border ${
                  qtyMode === 'STOCK_QTY'
                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-md ring-2 ring-emerald-500/30'
                    : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Check className="w-4 h-4 text-emerald-300" />
                <span>พิมพ์ตามจำนวนคงเหลือจริง (Auto Stock Qty)</span>
              </button>

              <button
                onClick={() => setQtyMode('ONE_EACH')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 border ${
                  qtyMode === 'ONE_EACH'
                    ? 'bg-blue-600 text-white border-blue-400 shadow-md'
                    : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
              >
                <span>พิมพ์ 1 ใบ ต่อ 1 รายการ SKU</span>
              </button>

              <button
                onClick={() => setQtyMode('CUSTOM')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 border ${
                  qtyMode === 'CUSTOM'
                    ? 'bg-purple-600 text-white border-purple-400 shadow-md'
                    : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>กำหนดจำนวนใบเองรายชิ้น</span>
              </button>
            </div>
          </div>

          {/* Section 2: Paper & Grid Layout Size */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-white flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-blue-400" />
              <span>2. รูปแบบขนาดกระดาษสติกเกอร์ (Sticker Layout / Paper Size):</span>
            </label>
            <select
              value={layoutMode}
              onChange={(e) => setLayoutMode(e.target.value as LabelLayoutMode)}
              className="bg-slate-900 border border-slate-700 text-xs font-semibold text-white px-3 py-2 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="A4_3COL">A4 Grid 3 คอลัมน์ (ขนาดมาตรฐาน 7x4 ซม. - ยอดนิยม)</option>
              <option value="A4_2COL">A4 Grid 2 คอลัมน์ (ขนาดใหญ่ 10x6 ซม. - ติดกล่องพาเลท)</option>
              <option value="A4_4COL">A4 Grid 4 คอลัมน์ (ขนาดกะทัดรัด 5x3 ซม. - ติดลิ้นชักอะไหล่)</option>
              <option value="THERMAL_ROLL">เครื่องพิมพ์ลาเบลความร้อน Thermal Roll (1 คอลัมน์เดี่ยว)</option>
            </select>
          </div>

        </div>

        {/* Display Toggles */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
          <span className="text-slate-400 font-semibold">องค์ประกอบบนสติกเกอร์:</span>

          <div className="flex flex-wrap items-center gap-4">
            <label className="inline-flex items-center gap-1.5 text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={showBarcode}
                onChange={(e) => setShowBarcode(e.target.checked)}
                className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5 cursor-pointer"
              />
              <span>รูปบาร์โค้ด (Barcode Visual)</span>
            </label>

            <label className="inline-flex items-center gap-1.5 text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={showLocation}
                onChange={(e) => setShowLocation(e.target.checked)}
                className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5 cursor-pointer"
              />
              <span>พิกัดชั้นวาง (Shelf Location)</span>
            </label>

            <label className="inline-flex items-center gap-1.5 text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={showSequence}
                onChange={(e) => setShowSequence(e.target.checked)}
                className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5 cursor-pointer"
              />
              <span>ลำดับสติกเกอร์ (เช่น ชิ้นที่ 1/5)</span>
            </label>

            <label className="inline-flex items-center gap-1.5 text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={showSupplier}
                onChange={(e) => setShowSupplier(e.target.checked)}
                className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5 cursor-pointer"
              />
              <span>ผู้จัดจำหน่าย (Vendor)</span>
            </label>

            <label className="inline-flex items-center gap-1.5 text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={showPrice}
                onChange={(e) => setShowPrice(e.target.checked)}
                className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5 cursor-pointer"
              />
              <span>ราคาต้นทุนต่อหน่วย (Cost)</span>
            </label>

            <label className="inline-flex items-center gap-1.5 text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={showPrintDate}
                onChange={(e) => setShowPrintDate(e.target.checked)}
                className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5 cursor-pointer"
              />
              <span>วันที่พิมพ์สติกเกอร์</span>
            </label>
          </div>
        </div>

      </div>

      {/* Item Selection & Quantity Customization Bar */}
      <div className="no-print bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-sm space-y-4">
        
        {/* Search & Selection Shortcuts */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ค้นหารายการ SKU, ชื่อภาษาไทย/อังกฤษ, ยี่ห้อ หรือบาร์โค้ด..."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Quick Selection Buttons */}
          <div className="flex items-center gap-2 overflow-x-auto">
            <button
              onClick={selectInStockOnly}
              className="px-3 py-1.5 text-xs font-semibold bg-slate-700 hover:bg-emerald-600 text-slate-200 hover:text-white rounded-lg transition whitespace-nowrap cursor-pointer"
            >
              เลือกเฉพาะที่มีสต็อก (&gt; 0)
            </button>
            <button
              onClick={selectAllFiltered}
              className="px-3 py-1.5 text-xs font-semibold bg-slate-700 hover:bg-blue-600 text-slate-200 hover:text-white rounded-lg transition whitespace-nowrap cursor-pointer"
            >
              เลือกทั้งหมดในผลค้นหา
            </button>
            <button
              onClick={deselectAll}
              className="px-3 py-1.5 text-xs font-semibold bg-slate-700 hover:bg-rose-600 text-slate-200 hover:text-white rounded-lg transition whitespace-nowrap cursor-pointer"
            >
              ล้างการเลือก
            </button>
          </div>

        </div>

        {/* Item Selection Matrix Cards */}
        <div className="space-y-2 max-h-60 overflow-y-auto pr-1 scrollbar-thin">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {filteredItems.map((item) => {
              const isSelected = selectedItemIds.includes(item.id);
              const loc = locMap.get(item.locationId);
              const printCopies = getItemCopies(item);

              return (
                <div
                  key={item.id}
                  onClick={() => toggleSelectItem(item.id)}
                  className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-blue-600/20 border-blue-500/80 text-white ring-1 ring-blue-500/30'
                      : 'bg-slate-900/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      type="button"
                      className="text-blue-400 shrink-0 cursor-pointer"
                    >
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 text-blue-400" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-500" />
                      )}
                    </button>

                    <div className="truncate space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs font-bold text-blue-300">{item.code}</span>
                        {loc && <span className="font-mono text-[9px] text-emerald-400 bg-emerald-500/10 px-1 rounded">{loc.code}</span>}
                      </div>
                      <p className="text-xs font-medium text-white truncate">{item.nameTh}</p>
                      <p className="text-[10px] text-slate-400">
                        สต็อกคงเหลือ: <strong className="text-emerald-400 font-mono">{item.currentStock}</strong> ชิ้น
                      </p>
                    </div>
                  </div>

                  {/* Copies Counter */}
                  {isSelected && (
                    <div className="shrink-0 text-right space-y-0.5" onClick={(e) => e.stopPropagation()}>
                      <span className="text-[9px] text-slate-400 block font-semibold">จำนวนพิมพ์</span>
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          value={printCopies}
                          onChange={(e) => updateCustomQty(item.id, parseInt(e.target.value) || 0)}
                          className="w-12 bg-slate-950 border border-slate-700 rounded px-1 py-0.5 text-center text-xs font-bold text-emerald-300 font-mono outline-none focus:ring-1 focus:ring-blue-500"
                        />
                        <span className="text-[10px] text-slate-400">ใบ</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Live Sticker Print Canvas Area */}
      <div className="printable-area bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="no-print flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Printer className="w-4 h-4 text-blue-400" />
              <span>ตัวอย่างแผ่นพิมพ์สติกเกอร์ (Print Preview Canvas)</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              แสดงตัวอย่างสติกเกอร์จริงที่จะพิมพ์ออกมา ยอดรวมพิมพ์ทั้งหมด{' '}
              <strong className="text-emerald-400 font-mono">{stickerInstances.length}</strong> ใบ
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">
              โหมดเลือก: <strong className="text-white font-mono">{qtyMode}</strong>
            </span>
            <button
              onClick={handlePrint}
              disabled={stickerInstances.length === 0}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>สั่งพิมพ์</span>
            </button>
          </div>
        </div>

        {stickerInstances.length === 0 ? (
          <div className="no-print py-16 text-center text-slate-500 text-xs bg-slate-950/60 rounded-xl border border-dashed border-slate-800">
            <AlertCircle className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-slate-300 font-semibold">ยังไม่ได้เลือกรายการ หรือจำนวนสติกเกอร์ที่จะพิมพ์เป็น 0</p>
            <p className="text-slate-500 text-[11px] mt-1">กรุณาเลือกรายการสินค้าจากกล่องเลือกด้านบนเพื่อสร้างลาเบล</p>
          </div>
        ) : (
          <div
            className={`grid gap-3 print:gap-1.5 ${
              layoutMode === 'A4_2COL'
                ? 'grid-cols-1 sm:grid-cols-2 print:grid-cols-2'
                : layoutMode === 'A4_3COL'
                ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 print:grid-cols-3'
                : layoutMode === 'A4_4COL'
                ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 print:grid-cols-4'
                : 'grid-cols-1 max-w-sm mx-auto print:max-w-none print:grid-cols-1'
            }`}
          >
            {stickerInstances.map(({ item, instanceIndex, totalInstances }, idx) => {
              const loc = locMap.get(item.locationId);
              const sup = supMap.get(item.supplierId);

              return (
                <div
                  key={`${item.id}-${instanceIndex}-${idx}`}
                  className="sticker-card bg-white text-slate-900 p-3.5 rounded-xl border-2 border-slate-300 shadow-sm space-y-2 font-sans relative overflow-hidden flex flex-col justify-between min-h-[140px]"
                >
                  {/* Card Header */}
                  <div>
                    <div className="flex items-center justify-between border-b-2 border-slate-900 pb-1.5 mb-1.5">
                      <span className="text-[10px] font-extrabold uppercase text-slate-900 tracking-wider">
                        SPARE PART STICKER
                      </span>
                      <div className="flex items-center gap-1">
                        {showSequence && (
                          <span className="text-[9px] font-bold font-mono bg-slate-200 text-slate-800 px-1.5 py-0.5 rounded">
                            #{instanceIndex}/{totalInstances}
                          </span>
                        )}
                        <span className="font-mono text-xs font-extrabold bg-slate-900 text-white px-2 py-0.5 rounded">
                          {item.code}
                        </span>
                      </div>
                    </div>

                    {/* Title & Brand */}
                    <h4 className="text-xs font-extrabold text-slate-900 leading-snug line-clamp-2">
                      {item.nameTh}
                    </h4>

                    {(item.brand || item.modelNumber) && (
                      <p className="text-[9px] text-slate-800 font-semibold mt-0.5">
                        Brand: {item.brand || '-'} {item.modelNumber && `| Model: ${item.modelNumber}`}
                      </p>
                    )}
                  </div>

                  {/* Simulated Barcode */}
                  {showBarcode && (
                    <div className="bg-slate-50 p-1.5 rounded border border-slate-300 text-center space-y-0.5">
                      <div className="h-8 bg-slate-900 flex items-center justify-around px-2">
                        {[...Array(24)].map((_, i) => (
                          <div
                            key={i}
                            className={`h-full bg-white ${
                              i % 3 === 0 ? 'w-1' : i % 2 === 0 ? 'w-0.5' : 'w-1.5'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="font-mono text-[10px] font-bold text-slate-900 tracking-widest block">
                        {item.barcode || '8851234567890'}
                      </span>
                    </div>
                  )}

                  {/* Location & Details Footer */}
                  <div className="pt-1.5 border-t border-slate-300 space-y-1 text-[9px]">
                    <div className="flex items-center justify-between text-slate-900">
                      {showLocation && (
                        <span className="flex items-center gap-1 font-mono font-extrabold text-emerald-950 bg-emerald-100 px-1.5 py-0.5 rounded border border-emerald-300">
                          <MapPin className="w-2.5 h-2.5 text-emerald-700 inline" />
                          พิกัด: {loc?.code || 'NO-RACK'}
                        </span>
                      )}

                      <span className="font-bold font-mono text-slate-800">
                        สต็อกทั้งหมด: {item.currentStock} ชิ้น
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[8px] text-slate-600 pt-0.5">
                      {showSupplier && (
                        <span className="truncate max-w-[120px]" title={sup?.companyName}>
                          ผู้จัดส่ง: {sup?.companyName || '-'}
                        </span>
                      )}

                      {showPrice && (
                        <span className="font-mono font-bold text-slate-900">
                          ฿{item.unitCost.toLocaleString('th-TH')}
                        </span>
                      )}

                      {showPrintDate && (
                        <span className="font-mono text-slate-500">
                          Print: {currentDateStr}
                        </span>
                      )}
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
