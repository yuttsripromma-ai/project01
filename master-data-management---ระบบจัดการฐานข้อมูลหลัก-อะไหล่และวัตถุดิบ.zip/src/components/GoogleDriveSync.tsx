import React, { useState, useEffect } from 'react';
import { Cloud, CloudUpload, CloudDownload, RefreshCw, CheckCircle2, LogOut, HardDrive, AlertCircle } from 'lucide-react';
import { DriveService, DriveAuthStatus } from '../services/driveService';

interface GoogleDriveSyncProps {
  onLoadDataFromDrive: (data: any) => void;
  getDatabaseData: () => any;
  showToast: (message: string) => void;
}

export const GoogleDriveSync: React.FC<GoogleDriveSyncProps> = ({
  onLoadDataFromDrive,
  getDatabaseData,
  showToast,
}) => {
  const [authStatus, setAuthStatus] = useState<DriveAuthStatus>({ authenticated: false });
  const [loading, setLoading] = useState<boolean>(true);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [restoring, setRestoring] = useState<boolean>(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<string | null>(null);
  const [autoSync, setAutoSync] = useState<boolean>(() => {
    return localStorage.getItem('mdm_drive_auto_sync') === 'true';
  });
  const [isOpenModal, setIsOpenModal] = useState<boolean>(false);

  // Check auth status on mount
  const checkStatus = async () => {
    setLoading(true);
    try {
      const status = await DriveService.getAuthStatus();
      setAuthStatus(status);
      if (status.authenticated) {
        // Check files on drive
        const files = await DriveService.checkDriveFiles();
        if (files.length > 0) {
          setLastSyncedTime(new Date(files[0].modifiedTime).toLocaleString('th-TH'));
        }
      }
    } catch {
      setAuthStatus({ authenticated: false });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkStatus();
  }, []);

  const handleConnect = async () => {
    try {
      setLoading(true);
      await DriveService.loginWithGoogle();
      await checkStatus();
      showToast('เชื่อมต่อ Google Drive สำเร็จ');
    } catch (err: any) {
      console.error(err);
      showToast('เกิดข้อผิดพลาดในการเชื่อมต่อ Google Drive: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await DriveService.logout();
    setAuthStatus({ authenticated: false });
    setLastSyncedTime(null);
    showToast('ออกจากระบบ Google Drive แล้ว');
  };

  const handleSyncToDrive = async () => {
    if (!authStatus.authenticated) {
      handleConnect();
      return;
    }
    setSyncing(true);
    try {
      const currentData = getDatabaseData();
      const res = await DriveService.syncDatabaseToDrive(currentData);
      if (res.modifiedTime) {
        setLastSyncedTime(new Date(res.modifiedTime).toLocaleString('th-TH'));
      }
      showToast('สำรองข้อมูล MDM ไปยัง Google Drive เรียบร้อยแล้ว (mdm_database.json)');
    } catch (err: any) {
      console.error(err);
      showToast('เกิดข้อผิดพลาดในการบันทึกไปยัง Google Drive: ' + err.message);
    } finally {
      setSyncing(false);
    }
  };

  const handleLoadFromDrive = async () => {
    if (!authStatus.authenticated) {
      handleConnect();
      return;
    }
    if (!confirm('คุณต้องการดึงข้อมูลจาก Google Drive มาเขียนทับข้อมูลปัจจุบันหรือไม่?')) {
      return;
    }
    setRestoring(true);
    try {
      const res = await DriveService.loadDatabaseFromDrive();
      if (res.data) {
        onLoadDataFromDrive(res.data);
        if (res.modifiedTime) {
          setLastSyncedTime(new Date(res.modifiedTime).toLocaleString('th-TH'));
        }
        showToast('ดึงข้อมูลจาก Google Drive สำเร็จ');
        setIsOpenModal(false);
      }
    } catch (err: any) {
      console.error(err);
      showToast('ไม่สามารถดึงข้อมูลได้: ' + err.message);
    } finally {
      setRestoring(false);
    }
  };

  const toggleAutoSync = () => {
    const nextVal = !autoSync;
    setAutoSync(nextVal);
    localStorage.setItem('mdm_drive_auto_sync', String(nextVal));
    showToast(nextVal ? 'เปิดการซิงค์อัตโนมัติไปยัง Google Drive' : 'ปิดการซิงค์อัตโนมัติ');
  };

  return (
    <>
      {/* Trigger Button in Header */}
      {!authStatus.authenticated ? (
        <button
          onClick={handleConnect}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm transition cursor-pointer"
          title="เชื่อมต่อกับบัญชี Google Drive เพื่อบันทึกและซิงค์ฐานข้อมูล"
        >
          <HardDrive className="w-3.5 h-3.5 text-indigo-200" />
          <span>{loading ? 'กำลังเชื่อมต่อ...' : 'เชื่อมต่อ Google Drive'}</span>
        </button>
      ) : (
        <div className="relative inline-flex items-center gap-2">
          <button
            onClick={() => setIsOpenModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-950/80 hover:bg-indigo-900/80 text-indigo-200 border border-indigo-700/60 transition cursor-pointer"
            title="จัดการการเชื่อมต่อ Google Drive"
          >
            <Cloud className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="max-w-[120px] truncate">{authStatus.user?.email || 'Google Drive'}</span>
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          </button>
        </div>
      )}

      {/* Control Modal */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-md p-6 text-white shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <HardDrive className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100">จัดการฐานข้อมูล Google Drive</h3>
                  <p className="text-xs text-slate-400">Google Drive Database Sync</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpenModal(false)}
                className="text-slate-400 hover:text-white p-1 text-lg rounded-lg transition"
              >
                ✕
              </button>
            </div>

            {/* Account Info */}
            <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3 mb-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {authStatus.user?.picture ? (
                  <img src={authStatus.user.picture} alt="Avatar" className="w-8 h-8 rounded-full border border-indigo-400" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-xs">
                    {authStatus.user?.name?.[0] || 'G'}
                  </div>
                )}
                <div className="text-xs">
                  <div className="font-semibold text-slate-200">{authStatus.user?.name || 'Google User'}</div>
                  <div className="text-slate-400">{authStatus.user?.email}</div>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-700/50 rounded-lg transition text-xs flex items-center gap-1"
                title="ออกจากระบบ"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Sync Status Info */}
            <div className="mb-5 space-y-2 text-xs">
              <div className="flex items-center justify-between py-1.5 px-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-400">ชื่อไฟล์ใน Drive:</span>
                <span className="font-mono text-emerald-300 font-semibold">mdm_database.json</span>
              </div>
              <div className="flex items-center justify-between py-1.5 px-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-400">ซิงค์ล่าสุด:</span>
                <span className="text-slate-200 font-medium">{lastSyncedTime || 'ยังไม่มีการซิงค์'}</span>
              </div>
            </div>

            {/* Auto-Sync Toggle */}
            <div className="mb-6 flex items-center justify-between bg-indigo-950/40 border border-indigo-900/60 rounded-xl p-3">
              <div>
                <div className="text-xs font-semibold text-indigo-200">การซิงค์อัตโนมัติ (Auto-Sync)</div>
                <div className="text-[11px] text-indigo-300/70">บันทึกข้อมูลไป Google Drive เมื่อมีการแก้ไข</div>
              </div>
              <button
                onClick={toggleAutoSync}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  autoSync ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    autoSync ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleSyncToDrive}
                disabled={syncing}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
              >
                <CloudUpload className={`w-4 h-4 ${syncing ? 'animate-bounce' : ''}`} />
                <span>{syncing ? 'กำลังอัปโหลด...' : 'บันทึกไป Drive'}</span>
              </button>

              <button
                onClick={handleLoadFromDrive}
                disabled={restoring}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-semibold text-xs transition disabled:opacity-50 cursor-pointer"
              >
                <CloudDownload className={`w-4 h-4 text-emerald-400 ${restoring ? 'animate-bounce' : ''}`} />
                <span>{restoring ? 'กำลังโหลด...' : 'ดึงข้อมูลจาก Drive'}</span>
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-2 text-[11px] text-slate-400">
              <AlertCircle className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span>ไฟล์จะถูกจัดเก็บอย่างปลอดภัยใน Google Drive ส่วนตัวของคุณ</span>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
