import React, { useState, useEffect } from 'react';
import {
  ActiveTab,
  ActivityLog,
  Category,
  StorageLocation,
  MasterItem,
  Supplier,
  UOM,
  ProductionOrder,
  BOMItem,
  Shipment,
} from './types';
import { StorageService } from './services/storage';
import { exportMasterDataToExcel, exportItemsToExcel } from './services/excelExport';
import { Header } from './components/Header';
import { NavigationTabs } from './components/NavigationTabs';
import { DashboardOverview } from './components/DashboardOverview';
import { RawMaterialsModule } from './components/modules/RawMaterialsModule';
import { ProductionModule } from './components/modules/ProductionModule';
import { FinishedGoodsModule } from './components/modules/FinishedGoodsModule';
import { ShippingModule } from './components/modules/ShippingModule';
import { GoogleSheetsModule } from './components/modules/GoogleSheetsModule';
import { ItemList } from './components/items/ItemList';
import { ItemModal } from './components/items/ItemModal';
import { UomList } from './components/uom/UomList';
import { UomModal } from './components/uom/UomModal';
import { CategoryList } from './components/categories/CategoryList';
import { CategoryModal } from './components/categories/CategoryModal';
import { LocationList } from './components/locations/LocationList';
import { LocationModal } from './components/locations/LocationModal';
import { SupplierList } from './components/suppliers/SupplierList';
import { SupplierModal } from './components/suppliers/SupplierModal';
import { ShelfVisualizer } from './components/shelfMap/ShelfVisualizer';
import { BarcodeGenerator } from './components/barcode/BarcodeGenerator';
import { DeleteConfirmModal } from './components/common/DeleteConfirmModal';
import { GoogleDriveSync } from './components/GoogleDriveSync';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Master Data & ERP State
  const [items, setItems] = useState<MasterItem[]>([]);
  const [uoms, setUoms] = useState<UOM[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [locations, setLocations] = useState<StorageLocation[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);

  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>([]);
  const [boms, setBoms] = useState<BOMItem[]>([]);
  const [shipments, setShipments] = useState<Shipment[]>([]);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Modals state
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MasterItem | null>(null);

  const [isUomModalOpen, setIsUomModalOpen] = useState(false);
  const [editingUom, setEditingUom] = useState<UOM | null>(null);

  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<StorageLocation | null>(null);

  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  // Delete Confirm Modal State
  const [deleteTarget, setDeleteTarget] = useState<{
    type: 'ITEM' | 'UOM' | 'CATEGORY' | 'LOCATION' | 'SUPPLIER';
    id: string;
    name: string;
  } | null>(null);

  // Load Initial Data
  useEffect(() => {
    setItems(StorageService.getItems());
    setUoms(StorageService.getUoms());
    setCategories(StorageService.getCategories());
    setLocations(StorageService.getLocations());
    setSuppliers(StorageService.getSuppliers());
    setLogs(StorageService.getLogs());
    setProductionOrders(StorageService.getProductionOrders());
    setBoms(StorageService.getBOMs());
    setShipments(StorageService.getShipments());
  }, []);

  // --- ERP MODULE HANDLERS ---
  const handleAddProductionOrder = (order: Omit<ProductionOrder, 'id' | 'createdAt'>) => {
    const newOrder: ProductionOrder = {
      ...order,
      id: 'po-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    const updated = [newOrder, ...productionOrders];
    setProductionOrders(updated);
    StorageService.saveProductionOrders(updated);
    StorageService.addLog({
      action: 'CREATE',
      entityType: 'ITEM',
      entityName: order.orderNo,
      details: `เปิดคำสั่งผลิตใหม่: ${order.targetName} จำนวน ${order.targetQty} ชิ้น`,
    });
    setLogs(StorageService.getLogs());
  };

  const handleUpdateOrderStatus = (orderId: string, status: ProductionOrder['status']) => {
    const order = productionOrders.find((p) => p.id === orderId);
    if (!order) return;

    const updatedOrders = productionOrders.map((p) => (p.id === orderId ? { ...p, status } : p));
    setProductionOrders(updatedOrders);
    StorageService.saveProductionOrders(updatedOrders);

    // If order COMPLETED: Deduct Raw Materials based on BOM and increase FG stock
    if (status === 'COMPLETED') {
      const orderBoms = boms.filter((b) => b.finishedGoodSku === order.targetSku);
      let updatedItems = [...items];

      // Deduct raw materials
      orderBoms.forEach((bom) => {
        const requiredTotal = bom.requiredQtyPerUnit * order.targetQty;
        updatedItems = updatedItems.map((item) => {
          if (item.code === bom.rawMaterialSku) {
            return {
              ...item,
              currentStock: Math.max(0, item.currentStock - requiredTotal),
            };
          }
          return item;
        });
      });

      // Increase FG stock
      updatedItems = updatedItems.map((item) => {
        if (item.code === order.targetSku) {
          return {
            ...item,
            currentStock: item.currentStock + order.targetQty,
          };
        }
        return item;
      });

      setItems(updatedItems);
      StorageService.saveItems(updatedItems);

      StorageService.addLog({
        action: 'UPDATE',
        entityType: 'ITEM',
        entityName: order.orderNo,
        details: `เสร็จสิ้นการผลิต ${order.orderNo}: เพิ่มสต๊อก ${order.targetName} +${order.targetQty} ชิ้น และตัดสต๊อกวัตถุดิบเรียบร้อยแล้ว`,
      });
      setLogs(StorageService.getLogs());
      showToast(`เสร็จสิ้นการผลิต ${order.orderNo} ตัดสต๊อกวัตถุดิบสำเร็จ!`);
    }
  };

  const handleSaveBOM = (bom: Omit<BOMItem, 'id'>) => {
    const newBom: BOMItem = {
      ...bom,
      id: 'bom-' + Date.now(),
    };
    const updated = [...boms, newBom];
    setBoms(updated);
    StorageService.saveBOMs(updated);
    showToast('บันทึกสูตรการผลิต (BOM) สำเร็จ');
  };

  const handleAddShipment = (shipment: Omit<Shipment, 'id' | 'createdAt'>) => {
    const newShipment: Shipment = {
      ...shipment,
      id: 'shp-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    const updated = [newShipment, ...shipments];
    setShipments(updated);
    StorageService.saveShipments(updated);

    StorageService.addLog({
      action: 'CREATE',
      entityType: 'ITEM',
      entityName: shipment.shipmentNo,
      details: `สร้างใบส่งสินค้า ${shipment.shipmentNo} ลูกค้า: ${shipment.customerName}`,
    });
    setLogs(StorageService.getLogs());
  };

  const handleUpdateShipmentStatus = (shipmentId: string, status: Shipment['status']) => {
    const shipment = shipments.find((s) => s.id === shipmentId);
    if (!shipment) return;

    const updatedShipments = shipments.map((s) => (s.id === shipmentId ? { ...s, status } : s));
    setShipments(updatedShipments);
    StorageService.saveShipments(updatedShipments);

    // If Dispatching (IN_TRANSIT): Deduct FG stock
    if (status === 'IN_TRANSIT') {
      const updatedItems = items.map((item) => {
        if (item.code === shipment.finishedGoodSku) {
          return {
            ...item,
            currentStock: Math.max(0, item.currentStock - shipment.quantity),
          };
        }
        return item;
      });

      setItems(updatedItems);
      StorageService.saveItems(updatedItems);

      StorageService.addLog({
        action: 'UPDATE',
        entityType: 'ITEM',
        entityName: shipment.shipmentNo,
        details: `ออกรถส่งสินค้า ${shipment.shipmentNo}: ตัดสต๊อก ${shipment.finishedGoodName} -${shipment.quantity} ชิ้น`,
      });
      setLogs(StorageService.getLogs());
      showToast(`ออกรถส่งสินค้า ${shipment.shipmentNo} ตัดสต๊อกสินค้าสำเร็จรูปสำเร็จ`);
    }
  };

  const getDatabaseData = () => ({
    items,
    uoms,
    categories,
    locations,
    suppliers,
    productionOrders,
    boms,
    shipments,
    logs,
  });

  const handleLoadDataFromSheets = (data: any) => {
    if (data.items && Array.isArray(data.items)) {
      setItems(data.items);
      StorageService.saveItems(data.items);
    }
    if (data.productionOrders && Array.isArray(data.productionOrders)) {
      setProductionOrders(data.productionOrders);
      StorageService.saveProductionOrders(data.productionOrders);
    }
    if (data.boms && Array.isArray(data.boms)) {
      setBoms(data.boms);
      StorageService.saveBOMs(data.boms);
    }
    if (data.shipments && Array.isArray(data.shipments)) {
      setShipments(data.shipments);
      StorageService.saveShipments(data.shipments);
    }
    if (data.logs && Array.isArray(data.logs)) {
      setLogs(data.logs);
      StorageService.saveLogs(data.logs);
    }
  };

  // Show toast helper
  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // --- ITEM HANDLERS ---
  const handleSaveItem = (item: MasterItem) => {
    let updated: MasterItem[];
    const isEdit = items.some((i) => i.id === item.id);
    if (isEdit) {
      updated = items.map((i) => (i.id === item.id ? item : i));
      StorageService.addLog({
        action: 'UPDATE',
        entityType: 'ITEM',
        entityName: item.code,
        details: `ปรับปรุงข้อมูลอะไหล่/วัตถุดิบ: ${item.nameTh}`,
      });
      showToast(`บันทึกการแก้ไข ${item.code} สำเร็จ`);
    } else {
      updated = [item, ...items];
      StorageService.addLog({
        action: 'CREATE',
        entityType: 'ITEM',
        entityName: item.code,
        details: `เพิ่มรายการอะไหล่/วัตถุดิบใหม่: ${item.nameTh}`,
      });
      showToast(`เพิ่มอะไหล่/วัตถุดิบใหม่ ${item.code} สำเร็จ`);
    }
    setItems(updated);
    StorageService.saveItems(updated);
    setLogs(StorageService.getLogs());
  };

  const handleDuplicateItem = (item: MasterItem) => {
    const newItem: MasterItem = {
      ...item,
      id: 'item-' + Date.now(),
      code: item.code + '-COPY',
      nameTh: item.nameTh + ' (คัดลอก)',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newItem, ...items];
    setItems(updated);
    StorageService.saveItems(updated);
    StorageService.addLog({
      action: 'CREATE',
      entityType: 'ITEM',
      entityName: newItem.code,
      details: `คัดลอกรายการ ${item.code}`,
    });
    setLogs(StorageService.getLogs());
    showToast(`คัดลอกสร้างรายการใหม่ ${newItem.code} สำเร็จ`);
  };

  const confirmDeleteItem = (id: string) => {
    const target = items.find((i) => i.id === id);
    if (target) {
      setDeleteTarget({ type: 'ITEM', id, name: `${target.code} (${target.nameTh})` });
    }
  };

  // --- UOM HANDLERS ---
  const handleSaveUom = (uom: UOM) => {
    let updated: UOM[];
    const isEdit = uoms.some((u) => u.id === uom.id);
    if (isEdit) {
      updated = uoms.map((u) => (u.id === uom.id ? uom : u));
      showToast(`แก้ไขหน่วยนับ ${uom.code} สำเร็จ`);
    } else {
      updated = [...uoms, uom];
      showToast(`เพิ่มหน่วยนับใหม่ ${uom.code} สำเร็จ`);
    }
    setUoms(updated);
    StorageService.saveUoms(updated);
  };

  const confirmDeleteUom = (id: string) => {
    const target = uoms.find((u) => u.id === id);
    if (target) {
      setDeleteTarget({ type: 'UOM', id, name: `${target.code} (${target.nameTh})` });
    }
  };

  // --- CATEGORY HANDLERS ---
  const handleSaveCategory = (cat: Category) => {
    let updated: Category[];
    const isEdit = categories.some((c) => c.id === cat.id);
    if (isEdit) {
      updated = categories.map((c) => (c.id === cat.id ? cat : c));
      showToast(`แก้ไขหมวดหมู่ ${cat.nameTh} สำเร็จ`);
    } else {
      updated = [...categories, cat];
      showToast(`เพิ่มหมวดหมู่ใหม่ ${cat.nameTh} สำเร็จ`);
    }
    setCategories(updated);
    StorageService.saveCategories(updated);
  };

  const confirmDeleteCategory = (id: string) => {
    const target = categories.find((c) => c.id === id);
    if (target) {
      setDeleteTarget({ type: 'CATEGORY', id, name: `${target.code} (${target.nameTh})` });
    }
  };

  // --- LOCATION HANDLERS ---
  const handleSaveLocation = (loc: StorageLocation) => {
    let updated: StorageLocation[];
    const isEdit = locations.some((l) => l.id === loc.id);
    if (isEdit) {
      updated = locations.map((l) => (l.id === loc.id ? loc : l));
      showToast(`แก้ไขชั้นวาง ${loc.code} สำเร็จ`);
    } else {
      updated = [...locations, loc];
      showToast(`เพิ่มพิกัดชั้นวางใหม่ ${loc.code} สำเร็จ`);
    }
    setLocations(updated);
    StorageService.saveLocations(updated);
  };

  const confirmDeleteLocation = (id: string) => {
    const target = locations.find((l) => l.id === id);
    if (target) {
      setDeleteTarget({ type: 'LOCATION', id, name: `${target.code} (${target.name})` });
    }
  };

  // --- SUPPLIER HANDLERS ---
  const handleSaveSupplier = (sup: Supplier) => {
    let updated: Supplier[];
    const isEdit = suppliers.some((s) => s.id === sup.id);
    if (isEdit) {
      updated = suppliers.map((s) => (s.id === sup.id ? sup : s));
      showToast(`แก้ไขผู้จัดจำหน่าย ${sup.companyName} สำเร็จ`);
    } else {
      updated = [...suppliers, sup];
      showToast(`เพิ่มผู้จัดจำหน่ายใหม่ ${sup.companyName} สำเร็จ`);
    }
    setSuppliers(updated);
    StorageService.saveSuppliers(updated);
  };

  const confirmDeleteSupplier = (id: string) => {
    const target = suppliers.find((s) => s.id === id);
    if (target) {
      setDeleteTarget({ type: 'SUPPLIER', id, name: `${target.code} (${target.companyName})` });
    }
  };

  // --- GENERIC DELETE EXECUTION ---
  const handleExecuteDelete = () => {
    if (!deleteTarget) return;

    if (deleteTarget.type === 'ITEM') {
      const updated = items.filter((i) => i.id !== deleteTarget.id);
      setItems(updated);
      StorageService.saveItems(updated);
      showToast(`ลบรายการอะไหล่ ${deleteTarget.name} สำเร็จ`);
    } else if (deleteTarget.type === 'UOM') {
      const updated = uoms.filter((u) => u.id !== deleteTarget.id);
      setUoms(updated);
      StorageService.saveUoms(updated);
      showToast(`ลบหน่วยนับ ${deleteTarget.name} สำเร็จ`);
    } else if (deleteTarget.type === 'CATEGORY') {
      const updated = categories.filter((c) => c.id !== deleteTarget.id);
      setCategories(updated);
      StorageService.saveCategories(updated);
      showToast(`ลบหมวดหมู่ ${deleteTarget.name} สำเร็จ`);
    } else if (deleteTarget.type === 'LOCATION') {
      const updated = locations.filter((l) => l.id !== deleteTarget.id);
      setLocations(updated);
      StorageService.saveLocations(updated);
      showToast(`ลบตำแหน่ง ${deleteTarget.name} สำเร็จ`);
    } else if (deleteTarget.type === 'SUPPLIER') {
      const updated = suppliers.filter((s) => s.id !== deleteTarget.id);
      setSuppliers(updated);
      StorageService.saveSuppliers(updated);
      showToast(`ลบผู้จัดจำหน่าย ${deleteTarget.name} สำเร็จ`);
    }

    StorageService.addLog({
      action: 'DELETE',
      entityType: deleteTarget.type,
      entityName: deleteTarget.name,
      details: `ลบข้อมูล Master Data`,
    });
    setLogs(StorageService.getLogs());
    setDeleteTarget(null);
  };

  // --- EXPORT & IMPORT HANDLERS ---
  const handleExportBackup = () => {
    const jsonStr = StorageService.exportMasterDataJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MDM_MasterData_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('สำรองข้อมูล Master Data เป็นไฟล์ JSON เรียบร้อย');
  };

  const handleImportBackup = (jsonText: string) => {
    const success = StorageService.importMasterDataJSON(jsonText);
    if (success) {
      setItems(StorageService.getItems());
      setUoms(StorageService.getUoms());
      setCategories(StorageService.getCategories());
      setLocations(StorageService.getLocations());
      setSuppliers(StorageService.getSuppliers());
      setLogs(StorageService.getLogs());
      showToast('กู้คืนฐานข้อมูล Master Data สำเร็จ!');
    } else {
      showToast('เกิดข้อผิดพลาดในการอ่านไฟล์ JSON', 'error');
    }
  };

  const handleResetDefaults = () => {
    if (confirm('คุณแน่ใจหรือว่าต้องการคืนค่า Master Data ทั้งหมดเป็นค่าตั้งต้นตัวอย่าง?')) {
      const defaults = StorageService.resetAllToDefaults();
      setItems(defaults.items);
      setUoms(defaults.uoms);
      setCategories(defaults.categories);
      setLocations(defaults.locations);
      setSuppliers(defaults.suppliers);
      setLogs(StorageService.getLogs());
      showToast('คืนค่าMaster Data ทั้งหมดเป็นตัวอย่างตั้งต้นสำเร็จ');
    }
  };

  const handleExportCSV = () => {
    const csvContent = StorageService.exportItemsToCSV(items, categories, uoms, locations, suppliers);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MDM_Master_Items_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('ส่งออกตาราง Master Items เป็น CSV เรียบร้อย');
  };

  const handleExportExcelFull = () => {
    exportMasterDataToExcel(items, categories, uoms, locations, suppliers, logs);
    showToast('ส่งออก Master Data ทั้งหมดเป็นไฟล์ Excel (.xlsx) สำเร็จ');
  };

  const handleExportExcelItems = (filteredList?: MasterItem[]) => {
    const targetItems = filteredList && filteredList.length > 0 ? filteredList : items;
    exportItemsToExcel(targetItems, categories, uoms, locations, suppliers);
    showToast(`ส่งออกรายการ Master Items (${targetItems.length} รายการ) เป็นไฟล์ Excel (.xlsx) สำเร็จ`);
  };

  const handleLoadDataFromDrive = (data: any) => {
    if (data.items && Array.isArray(data.items)) {
      setItems(data.items);
      StorageService.saveItems(data.items);
    }
    if (data.categories && Array.isArray(data.categories)) {
      setCategories(data.categories);
      StorageService.saveCategories(data.categories);
    }
    if (data.uoms && Array.isArray(data.uoms)) {
      setUoms(data.uoms);
      StorageService.saveUoms(data.uoms);
    }
    if (data.locations && Array.isArray(data.locations)) {
      setLocations(data.locations);
      StorageService.saveLocations(data.locations);
    }
    if (data.suppliers && Array.isArray(data.suppliers)) {
      setSuppliers(data.suppliers);
      StorageService.saveSuppliers(data.suppliers);
    }
    if (data.logs && Array.isArray(data.logs)) {
      setLogs(data.logs);
      StorageService.saveLogs(data.logs);
    }
    showToast('โหลดข้อมูลจาก Google Drive สำเร็จ!');
  };

  const lowStockCount = items.filter((i) => i.currentStock <= i.reorderPoint).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      
      {/* Top Header */}
      <Header
        totalItemsCount={items.length}
        totalUomsCount={uoms.length}
        totalCategoriesCount={categories.length}
        totalLocationsCount={locations.length}
        totalSuppliersCount={suppliers.length}
        onExportBackup={handleExportBackup}
        onExportExcel={handleExportExcelFull}
        onImportBackup={handleImportBackup}
        onResetData={handleResetDefaults}
        googleDriveComponent={
          <GoogleDriveSync
            getDatabaseData={getDatabaseData}
            onLoadDataFromDrive={handleLoadDataFromDrive}
            showToast={showToast}
          />
        }
      />

      {/* Navigation Tabs */}
      <NavigationTabs
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        counts={{
          items: items.length,
          uoms: uoms.length,
          categories: categories.length,
          locations: locations.length,
          suppliers: suppliers.length,
          lowStock: lowStockCount,
          productionOrdersCount: productionOrders.filter((p) => p.status === 'IN_PROGRESS').length,
          shipmentsCount: shipments.filter((s) => s.status === 'IN_TRANSIT').length,
        }}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Toast Notification Floating */}
        {toastMessage && (
          <div
            className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-bold border transition-all animate-bounce ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950 text-emerald-200 border-emerald-500/50'
                : 'bg-rose-950 text-rose-200 border-rose-500/50'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        )}

        {/* Tab 1: Dashboard Overview */}
        {activeTab === 'dashboard' && (
          <DashboardOverview
            items={items}
            uoms={uoms}
            categories={categories}
            locations={locations}
            suppliers={suppliers}
            logs={logs}
            onNavigateTab={setActiveTab}
            onOpenAddItemModal={() => {
              setEditingItem(null);
              setIsItemModalOpen(true);
            }}
            onExportCSV={handleExportCSV}
            onExportExcel={handleExportExcelFull}
          />
        )}

        {/* Tab: Raw Materials & Spare Parts */}
        {activeTab === 'raw_materials' && (
          <RawMaterialsModule
            items={items}
            categories={categories}
            locations={locations}
            uoms={uoms}
            onAddItem={() => {
              setEditingItem(null);
              setIsItemModalOpen(true);
            }}
            onEditItem={(item) => {
              setEditingItem(item);
              setIsItemModalOpen(true);
            }}
            onAdjustStock={(item) => {
              setEditingItem(item);
              setIsItemModalOpen(true);
            }}
          />
        )}

        {/* Tab: Production & BOM */}
        {activeTab === 'production' && (
          <ProductionModule
            items={items}
            productionOrders={productionOrders}
            boms={boms}
            onAddProductionOrder={handleAddProductionOrder}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onSaveBOM={handleSaveBOM}
            showToast={showToast}
          />
        )}

        {/* Tab: Finished Goods Warehouse */}
        {activeTab === 'finished_goods' && (
          <FinishedGoodsModule
            items={items}
            categories={categories}
            locations={locations}
            uoms={uoms}
            onAddItem={() => {
              setEditingItem(null);
              setIsItemModalOpen(true);
            }}
            onEditItem={(item) => {
              setEditingItem(item);
              setIsItemModalOpen(true);
            }}
            onAdjustStock={(item) => {
              setEditingItem(item);
              setIsItemModalOpen(true);
            }}
          />
        )}

        {/* Tab: Shipping & Delivery */}
        {activeTab === 'shipping' && (
          <ShippingModule
            items={items}
            shipments={shipments}
            onAddShipment={handleAddShipment}
            onUpdateShipmentStatus={handleUpdateShipmentStatus}
            showToast={showToast}
          />
        )}

        {/* Tab: Google Sheets Database */}
        {activeTab === 'google_sheets' && (
          <GoogleSheetsModule
            getDatabaseData={getDatabaseData}
            onLoadDataFromSheets={handleLoadDataFromSheets}
            showToast={showToast}
          />
        )}

        {/* Tab 2: Master Items Catalog */}
        {activeTab === 'items' && (
          <ItemList
            items={items}
            categories={categories}
            uoms={uoms}
            locations={locations}
            suppliers={suppliers}
            onAddItem={() => {
              setEditingItem(null);
              setIsItemModalOpen(true);
            }}
            onEditItem={(item) => {
              setEditingItem(item);
              setIsItemModalOpen(true);
            }}
            onDuplicateItem={handleDuplicateItem}
            onDeleteItem={confirmDeleteItem}
            onPrintItemSticker={() => setActiveTab('barcode')}
            onExportExcel={handleExportExcelItems}
          />
        )}

        {/* Tab 3: Units of Measure (UOM) */}
        {activeTab === 'uom' && (
          <UomList
            uoms={uoms}
            items={items}
            onAddUom={() => {
              setEditingUom(null);
              setIsUomModalOpen(true);
            }}
            onEditUom={(uom) => {
              setEditingUom(uom);
              setIsUomModalOpen(true);
            }}
            onDeleteUom={confirmDeleteUom}
          />
        )}

        {/* Tab 4: Categories */}
        {activeTab === 'categories' && (
          <CategoryList
            categories={categories}
            items={items}
            onAddCategory={() => {
              setEditingCategory(null);
              setIsCategoryModalOpen(true);
            }}
            onEditCategory={(cat) => {
              setEditingCategory(cat);
              setIsCategoryModalOpen(true);
            }}
            onDeleteCategory={confirmDeleteCategory}
          />
        )}

        {/* Tab 5: Storage Locations */}
        {activeTab === 'locations' && (
          <LocationList
            locations={locations}
            items={items}
            onAddLocation={() => {
              setEditingLocation(null);
              setIsLocationModalOpen(true);
            }}
            onEditLocation={(loc) => {
              setEditingLocation(loc);
              setIsLocationModalOpen(true);
            }}
            onDeleteLocation={confirmDeleteLocation}
          />
        )}

        {/* Tab 6: Suppliers */}
        {activeTab === 'suppliers' && (
          <SupplierList
            suppliers={suppliers}
            items={items}
            onAddSupplier={() => {
              setEditingSupplier(null);
              setIsSupplierModalOpen(true);
            }}
            onEditSupplier={(sup) => {
              setEditingSupplier(sup);
              setIsSupplierModalOpen(true);
            }}
            onDeleteSupplier={confirmDeleteSupplier}
          />
        )}

        {/* Tab 7: Spatial Shelf Map */}
        {activeTab === 'shelf_map' && (
          <ShelfVisualizer locations={locations} items={items} />
        )}

        {/* Tab 8: Barcode & Label Generator */}
        {activeTab === 'barcode' && (
          <BarcodeGenerator items={items} locations={locations} suppliers={suppliers} />
        )}

      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-500 py-4 mt-12 text-center text-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            ระบบฐานข้อมูลหลัก Master Data Management (MDM) • พัฒนาสำหรับอะไหล่ วัตถุดิบ คลังสินค้า และผู้จัดจำหน่าย
          </span>
          <span className="text-slate-400 font-mono">
            Version 1.0.0 • Local Persistence Ready
          </span>
        </div>
      </footer>

      {/* Modals */}
      <ItemModal
        isOpen={isItemModalOpen}
        onClose={() => setIsItemModalOpen(false)}
        onSave={handleSaveItem}
        editingItem={editingItem}
        categories={categories}
        uoms={uoms}
        locations={locations}
        suppliers={suppliers}
      />

      <UomModal
        isOpen={isUomModalOpen}
        onClose={() => setIsUomModalOpen(false)}
        onSave={handleSaveUom}
        editingUom={editingUom}
        allUoms={uoms}
      />

      <CategoryModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        onSave={handleSaveCategory}
        editingCategory={editingCategory}
        allCategories={categories}
      />

      <LocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        onSave={handleSaveLocation}
        editingLocation={editingLocation}
      />

      <SupplierModal
        isOpen={isSupplierModalOpen}
        onClose={() => setIsSupplierModalOpen(false)}
        onSave={handleSaveSupplier}
        editingSupplier={editingSupplier}
      />

      <DeleteConfirmModal
        isOpen={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleExecuteDelete}
        title="ยืนยันการลบข้อมูล Master Data"
        message={`คุณต้องการลบข้อมูล ${deleteTarget?.name} ใช่หรือไม่? การลบจะทำให้ข้อมูลนี้หายไปจากระบบ`}
      />

    </div>
  );
}
