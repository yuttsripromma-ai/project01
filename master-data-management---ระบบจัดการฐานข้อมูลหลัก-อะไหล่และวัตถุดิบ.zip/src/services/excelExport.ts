import * as XLSX from 'xlsx';
import { Category, StorageLocation, MasterItem, Supplier, UOM, ActivityLog } from '../types';

/**
 * Export full Master Data workbook into a multi-sheet Excel file (.xlsx)
 */
export function exportMasterDataToExcel(
  items: MasterItem[],
  categories: Category[],
  uoms: UOM[],
  locations: StorageLocation[],
  suppliers: Supplier[],
  logs: ActivityLog[] = []
): void {
  const wb = XLSX.utils.book_new();

  // Lookup maps
  const catMap = new Map(categories.map((c) => [c.id, c.nameTh]));
  const uomMap = new Map(uoms.map((u) => [u.id, u.nameTh]));
  const locMap = new Map(locations.map((l) => [l.id, l.code]));
  const supMap = new Map(suppliers.map((s) => [s.id, s.companyName]));

  // 1. Master Items Sheet
  const itemRows = items.map((item, index) => ({
    'ลำดับ (No.)': index + 1,
    'รหัสสินค้า/อะไหล่ (SKU)': item.code,
    'ชื่อรายการ': item.nameTh,
    'ประเภทสินค้า': item.type === 'SPARE_PART' ? 'อะไหล่' : item.type === 'RAW_MATERIAL' ? 'วัตถุดิบ' : item.type === 'CONSUMABLE' ? 'วัสดุสิ้นเปลือง' : 'เครื่องมือ',
    'หมวดหมู่ (Category)': catMap.get(item.categoryId) || '-',
    'หน่วยนับหลัก (UOM)': uomMap.get(item.uomId) || '-',
    'พิกัดที่เก็บ (Location)': locMap.get(item.locationId) || '-',
    'ผู้จัดจำหน่าย (Supplier)': supMap.get(item.supplierId) || '-',
    'จำนวนคงเหลือ (Qty)': item.currentStock,
    'จุดสั่งซื้อ (Reorder Point)': item.reorderPoint,
    'สต็อกขั้นต่ำ (Min)': item.minStock,
    'สต็อกสูงสุด (Max)': item.maxStock,
    'ต้นทุนต่อหน่วย (บาท)': item.unitCost,
    'มูลค่าสต็อกรวม (บาท)': item.currentStock * item.unitCost,
    'ยี่ห้อ (Brand)': item.brand || '-',
    'รุ่น (Model)': item.modelNumber || '-',
    'บาร์โค้ด (Barcode)': item.barcode || '-',
    'สถานะสต็อก': item.currentStock <= 0 ? 'สินค้าหมด (Out of Stock)' : item.currentStock <= item.reorderPoint ? 'ต้องสั่งซื้อเพิ่ม (Low Stock)' : 'ปกติ (Sufficient)',
    'สถานะการใช้งาน': item.status === 'ACTIVE' ? 'ใช้งาน' : 'ยกเลิก',
  }));

  const itemsWs = XLSX.utils.json_to_sheet(itemRows);
  itemsWs['!cols'] = [
    { wch: 8 },  // No
    { wch: 22 }, // SKU
    { wch: 32 }, // Name
    { wch: 16 }, // Type
    { wch: 20 }, // Cat
    { wch: 14 }, // UOM
    { wch: 18 }, // Loc
    { wch: 25 }, // Sup
    { wch: 16 }, // Stock
    { wch: 16 }, // Reorder
    { wch: 14 }, // Min
    { wch: 14 }, // Max
    { wch: 18 }, // Cost
    { wch: 20 }, // Total Cost
    { wch: 16 }, // Brand
    { wch: 16 }, // Model
    { wch: 18 }, // Barcode
    { wch: 22 }, // Stock alert
    { wch: 14 }, // Status
  ];
  XLSX.utils.book_append_sheet(wb, itemsWs, 'รายการสินค้าและอะไหล่');

  // 2. Categories Sheet
  const categoryRows = categories.map((cat, index) => ({
    'ลำดับ': index + 1,
    'รหัสหมวดหมู่': cat.code,
    'ชื่อหมวดหมู่': cat.nameTh,
    'รายละเอียด': cat.description || '-',
    'สถานะ': cat.status === 'ACTIVE' ? 'ใช้งาน' : 'ยกเลิก',
  }));
  const categoriesWs = XLSX.utils.json_to_sheet(categoryRows);
  categoriesWs['!cols'] = [{ wch: 8 }, { wch: 18 }, { wch: 28 }, { wch: 35 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, categoriesWs, 'หมวดหมู่สินค้า');

  // 3. Storage Locations Sheet
  const locationRows = locations.map((loc, index) => ({
    'ลำดับ': index + 1,
    'รหัสตำแหน่ง (Code)': loc.code,
    'ชื่อตำแหน่ง/รายละเอียด': loc.name,
    'คลังสินค้า (Warehouse)': loc.warehouse,
    'โซน (Zone)': loc.zone,
    'แร็ค (Rack)': loc.rack,
    'ชั้นวาง (Shelf)': loc.shelf,
    'กล่อง/ช่อง (Bin)': loc.bin,
    'ประเภทที่เก็บ': loc.type,
    'เงื่อนไขอุณหภูมิ': loc.temperatureCondition || 'ปกติ',
    'ความจุสูงสุด (ชิ้น)': loc.maxCapacityItems,
    'สถานะ': loc.status === 'ACTIVE' ? 'ใช้งาน' : 'ยกเลิก',
  }));
  const locationsWs = XLSX.utils.json_to_sheet(locationRows);
  locationsWs['!cols'] = [{ wch: 8 }, { wch: 18 }, { wch: 25 }, { wch: 22 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 16 }, { wch: 18 }, { wch: 16 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, locationsWs, 'คลังและชั้นวาง');

  // 4. Unit of Measures Sheet
  const uomRows = uoms.map((uom, index) => ({
    'ลำดับ': index + 1,
    'รหัสหน่วยนับ': uom.code,
    'ชื่อหน่วยนับ': uom.nameTh,
    'สัญลักษณ์ (Symbol)': uom.symbol,
    'รายละเอียด': uom.description || '-',
    'จำนวนการแปลงหน่วย': uom.conversions ? uom.conversions.length : 0,
    'สถานะ': uom.status === 'ACTIVE' ? 'ใช้งาน' : 'ยกเลิก',
  }));
  const uomsWs = XLSX.utils.json_to_sheet(uomRows);
  uomsWs['!cols'] = [{ wch: 8 }, { wch: 18 }, { wch: 22 }, { wch: 12 }, { wch: 30 }, { wch: 18 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, uomsWs, 'หน่วยนับ');

  // 5. Suppliers Sheet
  const supplierRows = suppliers.map((sup, index) => ({
    'ลำดับ': index + 1,
    'รหัสผู้จัดจำหน่าย': sup.code,
    'ชื่อบริษัท/ร้านค้า': sup.companyName,
    'ผู้ติดต่อหลัก': sup.contactPerson || '-',
    'เบอร์โทรศัพท์': sup.phone || '-',
    'อีเมล': sup.email || '-',
    'เลขประจำตัวผู้เสียภาษี': sup.taxId || '-',
    'ที่อยู่': sup.address || '-',
    'ระยะเวลาส่งมอบ (วัน)': sup.leadTimeDays,
    'คะแนนประเมิน (Rating)': sup.rating,
    'สถานะ': sup.status === 'ACTIVE' ? 'ใช้งาน' : 'ยกเลิก',
  }));
  const suppliersWs = XLSX.utils.json_to_sheet(supplierRows);
  suppliersWs['!cols'] = [{ wch: 8 }, { wch: 18 }, { wch: 30 }, { wch: 20 }, { wch: 16 }, { wch: 22 }, { wch: 20 }, { wch: 35 }, { wch: 18 }, { wch: 14 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, suppliersWs, 'ผู้จัดจำหน่าย');

  // 6. Activity Logs Sheet
  if (logs && logs.length > 0) {
    const logRows = logs.map((log, index) => ({
      'ลำดับ': index + 1,
      'วันที่-เวลา': new Date(log.timestamp).toLocaleString('th-TH'),
      'การดำเนินการ (Action)': log.action,
      'ประเภทข้อมูล': log.entityType,
      'ชื่อรายการ': log.entityName,
      'รายละเอียด': log.details,
    }));
    const logsWs = XLSX.utils.json_to_sheet(logRows);
    logsWs['!cols'] = [{ wch: 8 }, { wch: 20 }, { wch: 16 }, { wch: 16 }, { wch: 25 }, { wch: 40 }];
    XLSX.utils.book_append_sheet(wb, logsWs, 'ประวัติทำรายการ');
  }

  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `MDM_MasterData_Export_${dateStr}.xlsx`);
}

/**
 * Export only specific Master Items array to Excel file (.xlsx)
 */
export function exportItemsToExcel(
  items: MasterItem[],
  categories: Category[],
  uoms: UOM[],
  locations: StorageLocation[],
  suppliers: Supplier[]
): void {
  const catMap = new Map(categories.map((c) => [c.id, c.nameTh]));
  const uomMap = new Map(uoms.map((u) => [u.id, u.nameTh]));
  const locMap = new Map(locations.map((l) => [l.id, l.code]));
  const supMap = new Map(suppliers.map((s) => [s.id, s.companyName]));

  const itemRows = items.map((item, index) => ({
    'ลำดับ (No.)': index + 1,
    'รหัสสินค้า/อะไหล่ (SKU)': item.code,
    'ชื่อรายการ': item.nameTh,
    'ประเภทสินค้า': item.type === 'SPARE_PART' ? 'อะไหล่' : item.type === 'RAW_MATERIAL' ? 'วัตถุดิบ' : item.type === 'CONSUMABLE' ? 'วัสดุสิ้นเปลือง' : 'เครื่องมือ',
    'หมวดหมู่ (Category)': catMap.get(item.categoryId) || '-',
    'หน่วยนับหลัก (UOM)': uomMap.get(item.uomId) || '-',
    'พิกัดที่เก็บ (Location)': locMap.get(item.locationId) || '-',
    'ผู้จัดจำหน่าย (Supplier)': supMap.get(item.supplierId) || '-',
    'จำนวนคงเหลือ (Qty)': item.currentStock,
    'จุดสั่งซื้อ (Reorder Point)': item.reorderPoint,
    'สต็อกขั้นต่ำ (Min)': item.minStock,
    'สต็อกสูงสุด (Max)': item.maxStock,
    'ต้นทุนต่อหน่วย (บาท)': item.unitCost,
    'มูลค่าสต็อกรวม (บาท)': item.currentStock * item.unitCost,
    'ยี่ห้อ (Brand)': item.brand || '-',
    'รุ่น (Model)': item.modelNumber || '-',
    'บาร์โค้ด (Barcode)': item.barcode || '-',
    'สถานะสต็อก': item.currentStock <= 0 ? 'สินค้าหมด (Out of Stock)' : item.currentStock <= item.reorderPoint ? 'ต้องสั่งซื้อเพิ่ม (Low Stock)' : 'ปกติ (Sufficient)',
    'สถานะการใช้งาน': item.status === 'ACTIVE' ? 'ใช้งาน' : 'ยกเลิก',
  }));

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(itemRows);
  ws['!cols'] = [
    { wch: 8 },  // No
    { wch: 22 }, // SKU
    { wch: 32 }, // Name
    { wch: 16 }, // Type
    { wch: 20 }, // Cat
    { wch: 14 }, // UOM
    { wch: 18 }, // Loc
    { wch: 25 }, // Sup
    { wch: 16 }, // Stock
    { wch: 16 }, // Reorder
    { wch: 14 }, // Min
    { wch: 14 }, // Max
    { wch: 18 }, // Cost
    { wch: 20 }, // Total Cost
    { wch: 16 }, // Brand
    { wch: 16 }, // Model
    { wch: 18 }, // Barcode
    { wch: 22 }, // Stock alert
    { wch: 14 }, // Status
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'รายการ Master Items');
  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `MDM_Master_Items_${dateStr}.xlsx`);
}
