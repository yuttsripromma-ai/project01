export interface GoogleUser {
  email: string;
  name: string;
  picture?: string;
}

export interface DriveAuthStatus {
  authenticated: boolean;
  user?: GoogleUser;
}

export const DriveService = {
  async getAuthStatus(): Promise<DriveAuthStatus> {
    try {
      const res = await fetch('/api/auth/status');
      if (!res.ok) return { authenticated: false };
      return await res.json();
    } catch {
      return { authenticated: false };
    }
  },

  async loginWithGoogle(): Promise<void> {
    const res = await fetch('/api/auth/google/url');
    const data = await res.json();
    if (!data.url) throw new Error('Could not get authorization URL');

    const width = 600;
    const height = 700;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;

    const popup = window.open(
      data.url,
      'GoogleDriveAuth',
      `width=${width},height=${height},left=${left},top=${top}`
    );

    return new Promise((resolve) => {
      const handleMessage = (event: MessageEvent) => {
        if (event.data && event.data.type === 'OAUTH_AUTH_SUCCESS') {
          window.removeEventListener('message', handleMessage);
          resolve();
        }
      };
      window.addEventListener('message', handleMessage);

      const checkClosed = setInterval(() => {
        if (popup && popup.closed) {
          clearInterval(checkClosed);
          window.removeEventListener('message', handleMessage);
          resolve();
        }
      }, 1000);
    });
  },

  async logout(): Promise<void> {
    await fetch('/api/auth/logout', { method: 'POST' });
  },

  async syncDatabaseToDrive(data: any): Promise<{ success: boolean; fileId?: string; modifiedTime?: string }> {
    const res = await fetch('/api/drive/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to sync with Google Drive');
    }
    return await res.json();
  },

  async loadDatabaseFromDrive(): Promise<{ success: boolean; data: any; modifiedTime?: string }> {
    const res = await fetch('/api/drive/load');
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to load from Google Drive');
    }
    return await res.json();
  },

  async checkDriveFiles(): Promise<any[]> {
    const res = await fetch('/api/drive/files');
    if (!res.ok) return [];
    const json = await res.json();
    return json.files || [];
  }
};
