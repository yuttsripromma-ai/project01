import { Category, StorageLocation, MasterItem, Supplier, UOM, ActivityLog, ProductionOrder, BOMItem, Shipment } from '../types';
import { INITIAL_CATEGORIES, INITIAL_ITEMS, INITIAL_LOCATIONS, INITIAL_SUPPLIERS, INITIAL_UOMS } from '../data/initialData';

const KEYS = {
  ITEMS: 'mdm_master_items_v1',
  UOMS: 'mdm_uoms_v1',
  CATEGORIES: 'mdm_categories_v1',
  LOCATIONS: 'mdm_locations_v1',
  SUPPLIERS: 'mdm_suppliers_v1',
  LOGS: 'mdm_activity_logs_v1',
  PRODUCTION_ORDERS: 'mdm_production_orders_v1',
  BOMS: 'mdm_boms_v1',
  SHIPMENTS: 'mdm_shipments_v1',
};

// Helper safely parse localStorage
function getFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(key);
    if (!data) return defaultValue;
    return JSON.parse(data) as T;
  } catch (err) {
    console.error(`Error reading ${key} from storage`, err);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error(`Error saving ${key} to storage`, err);
  }
}

export const StorageService = {
  getItems(): MasterItem[] {
    return getFromStorage<MasterItem[]>(KEYS.ITEMS, INITIAL_ITEMS);
  },
  saveItems(items: MasterItem[]): void {
    saveToStorage(KEYS.ITEMS, items);
  },

  getUoms(): UOM[] {
    return getFromStorage<UOM[]>(KEYS.UOMS, INITIAL_UOMS);
  },
  saveUoms(uoms: UOM[]): void {
    saveToStorage(KEYS.UOMS, uoms);
  },

  getCategories(): Category[] {
    return getFromStorage<Category[]>(KEYS.CATEGORIES, INITIAL_CATEGORIES);
  },
  saveCategories(categories: Category[]): void {
    saveToStorage(KEYS.CATEGORIES, categories);
  },

  getLocations(): StorageLocation[] {
    return getFromStorage<StorageLocation[]>(KEYS.LOCATIONS, INITIAL_LOCATIONS);
  },
  saveLocations(locations: StorageLocation[]): void {
    saveToStorage(KEYS.LOCATIONS, locations);
  },

  getSuppliers(): Supplier[] {
    return getFromStorage<Supplier[]>(KEYS.SUPPLIERS, INITIAL_SUPPLIERS);
  },
  saveSuppliers(suppliers: Supplier[]): void {
    saveToStorage(KEYS.SUPPLIERS, suppliers);
  },

  getLogs(): ActivityLog[] {
    return getFromStorage<ActivityLog[]>(KEYS.LOGS, [
      {
        id: 'log-1',
        timestamp: new Date().toISOString(),
        action: 'IMPORT',
        entityType: 'ITEM',
        entityName: 'ระบบฐานข้อมูล Master Data & ERP',
        details: 'เริ่มต้นโหลดข้อมูลตัวอย่างตัวอย่างฐานข้อมูลหลัก (Initial Master Data & ERP Loaded)',
      },
    ]);
  },
  saveLogs(logs: ActivityLog[]): void {
    saveToStorage(KEYS.LOGS, logs);
  },

  getProductionOrders(): ProductionOrder[] {
    return getFromStorage<ProductionOrder[]>(KEYS.PRODUCTION_ORDERS, [
      {
        id: 'po-01',
        orderNo: 'PO-2026-001',
        targetSku: 'FG-VALVE-01',
        targetName: 'ชุดวาล์วควบคุมแรงดันสูง (Completed Valve Unit)',
        targetQty: 20,
        producedQty: 0,
        status: 'IN_PROGRESS',
        startDate: new Date().toISOString().slice(0, 10),
        targetDate: new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 10),
        createdAt: new Date().toISOString(),
      }
    ]);
  },
  saveProductionOrders(orders: ProductionOrder[]): void {
    saveToStorage(KEYS.PRODUCTION_ORDERS, orders);
  },

  getBOMs(): BOMItem[] {
    return getFromStorage<BOMItem[]>(KEYS.BOMS, [
      {
        id: 'bom-01',
        finishedGoodSku: 'FG-VALVE-01',
        rawMaterialSku: 'RM-STEEL-10MM',
        rawMaterialName: 'เหล็กเพลาขาว 10mm (Stainless Steel Bar)',
        requiredQtyPerUnit: 2,
      },
      {
        id: 'bom-02',
        finishedGoodSku: 'FG-VALVE-01',
        rawMaterialSku: 'PART-2026-001',
        rawMaterialName: 'ลูกปืนตลับ SKF 6204',
        requiredQtyPerUnit: 1,
      }
    ]);
  },
  saveBOMs(boms: BOMItem[]): void {
    saveToStorage(KEYS.BOMS, boms);
  },

  getShipments(): Shipment[] {
    return getFromStorage<Shipment[]>(KEYS.SHIPMENTS, [
      {
        id: 'shp-01',
        shipmentNo: 'SHP-2026-001',
        customerName: 'บริษัท ไทยอุตสาหกรรม การช่าง จำกัด',
        address: '88 หมู่ 3 ถ.บางนา-ตราด กม.12 สมุทรปราการ 10540',
        finishedGoodSku: 'FG-VALVE-01',
        finishedGoodName: 'ชุดวาล์วควบคุมแรงดันสูง',
        quantity: 5,
        status: 'IN_TRANSIT',
        trackingNo: 'TH20268899',
        vehicleNo: '7กข-9900',
        dispatchDate: new Date().toISOString().slice(0, 10),
        createdAt: new Date().toISOString(),
      }
    ]);
  },
  saveShipments(shipments: Shipment[]): void {
    saveToStorage(KEYS.SHIPMENTS, shipments);
  },
  addLog(log: Omit<ActivityLog, 'id' | 'timestamp'>): void {
    const logs = this.getLogs();
    const newLog: ActivityLog = {
      ...log,
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      timestamp: new Date().toISOString(),
    };
    saveToStorage(KEYS.LOGS, [newLog, ...logs.slice(0, 99)]);
  },

  resetAllToDefaults(): {
    items: MasterItem[];
    uoms: UOM[];
    categories: Category[];
    locations: StorageLocation[];
    suppliers: Supplier[];
  } {
    saveToStorage(KEYS.ITEMS, INITIAL_ITEMS);
    saveToStorage(KEYS.UOMS, INITIAL_UOMS);
    saveToStorage(KEYS.CATEGORIES, INITIAL_CATEGORIES);
    saveToStorage(KEYS.LOCATIONS, INITIAL_LOCATIONS);
    saveToStorage(KEYS.SUPPLIERS, INITIAL_SUPPLIERS);
    this.addLog({
      action: 'UPDATE',
      entityType: 'ITEM',
      entityName: ' Master Data',
      details: 'คืนค่าข้อมูลตัวอย่างตั้งต้นทั้งหมด (Reset to Defaults)',
    });
    return {
      items: INITIAL_ITEMS,
      uoms: INITIAL_UOMS,
      categories: INITIAL_CATEGORIES,
      locations: INITIAL_LOCATIONS,
      suppliers: INITIAL_SUPPLIERS,
    };
  },

  exportMasterDataJSON(): string {
    const fullBackup = {
      appName: 'MDM Master Data System',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      items: this.getItems(),
      uoms: this.getUoms(),
      categories: this.getCategories(),
      locations: this.getLocations(),
      suppliers: this.getSuppliers(),
    };
    return JSON.stringify(fullBackup, null, 2);
  },

  importMasterDataJSON(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.items && Array.isArray(parsed.items)) this.saveItems(parsed.items);
      if (parsed.uoms && Array.isArray(parsed.uoms)) this.saveUoms(parsed.uoms);
      if (parsed.categories && Array.isArray(parsed.categories)) this.saveCategories(parsed.categories);
      if (parsed.locations && Array.isArray(parsed.locations)) this.saveLocations(parsed.locations);
      if (parsed.suppliers && Array.isArray(parsed.suppliers)) this.saveSuppliers(parsed.suppliers);

      this.addLog({
        action: 'IMPORT',
        entityType: 'ITEM',
        entityName: 'สำรองข้อมูล (JSON Backup)',
        details: 'นําเข้าฐานข้อมูล Master Data จากไฟล์ JSON สำเร็จ',
      });
      return true;
    } catch (e) {
      console.error('Failed to parse import JSON', e);
      return false;
    }
  },

  exportItemsToCSV(items: MasterItem[], categories: Category[], uoms: UOM[], locations: StorageLocation[], suppliers: Supplier[]): string {
    const catMap = new Map(categories.map(c => [c.id, c.nameTh]));
    const uomMap = new Map(uoms.map(u => [u.id, u.nameTh]));
    const locMap = new Map(locations.map(l => [l.id, l.code]));
    const supMap = new Map(suppliers.map(s => [s.id, s.companyName]));

    const headers = [
      'รหัสสินค้า/อะไหล่ (SKU)',
      'ชื่อรายการ (ไทย)',
      'ชื่อรายการ (อังกฤษ)',
      'ประเภท',
      'หมวดหมู่',
      'หน่วยนับหลัก',
      'ที่เก็บ/ชั้นวาง',
      'ผู้จัดจำหน่ายหลัก',
      'จำนวนคงเหลือ',
      'จุดสั่งซื้อ (Reorder Point)',
      'สต็อกขั้นต่ำ (Min)',
      'สต็อกสูงสุด (Max)',
      'ราคาต้นทุน/หน่วย (บาท)',
      'ยี่ห้อ (Brand)',
      'รุ่น (Model)',
      'บาร์โค้ด',
      'สถานะ',
    ];

    const rows = items.map(item => [
      `"${item.code.replace(/"/g, '""')}"`,
      `"${item.nameTh.replace(/"/g, '""')}"`,
      `"${item.nameEn.replace(/"/g, '""')}"`,
      `"${item.type === 'SPARE_PART' ? 'อะไหล่' : item.type === 'RAW_MATERIAL' ? 'วัตถุดิบ' : item.type === 'CONSUMABLE' ? 'วัสดุสิ้นเปลือง' : 'เครื่องมือ'}"`,
      `"${(catMap.get(item.categoryId) || '').replace(/"/g, '""')}"`,
      `"${(uomMap.get(item.uomId) || '').replace(/"/g, '""')}"`,
      `"${(locMap.get(item.locationId) || '').replace(/"/g, '""')}"`,
      `"${(supMap.get(item.supplierId) || '').replace(/"/g, '""')}"`,
      item.currentStock,
      item.reorderPoint,
      item.minStock,
      item.maxStock,
      item.unitCost,
      `"${(item.brand || '').replace(/"/g, '""')}"`,
      `"${(item.modelNumber || '').replace(/"/g, '""')}"`,
      `"${(item.barcode || '').replace(/"/g, '""')}"`,
      item.status === 'ACTIVE' ? 'ใช้งาน' : 'ยกเลิก',
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    return csvContent;
  },
};
