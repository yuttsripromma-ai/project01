export interface SpreadsheetFile {
  id: string;
  name: string;
  modifiedTime: string;
  webViewLink?: string;
}

export const SheetsService = {
  async listSpreadsheets(): Promise<SpreadsheetFile[]> {
    const res = await fetch('/api/sheets/list');
    if (!res.ok) return [];
    const data = await res.json();
    return data.spreadsheets || [];
  },

  async createSpreadsheet(title?: string): Promise<{ success: boolean; spreadsheetId: string; spreadsheetUrl: string; title: string }> {
    const res = await fetch('/api/sheets/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to create spreadsheet');
    }
    return await res.json();
  },

  async syncToSpreadsheet(spreadsheetId: string, data: any): Promise<{ success: boolean; updatedAt: string }> {
    const res = await fetch('/api/sheets/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ spreadsheetId, data }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to sync to Google Sheets');
    }
    return await res.json();
  },

  async loadFromSpreadsheet(spreadsheetId: string): Promise<{ success: boolean; data: any }> {
    const res = await fetch('/api/sheets/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ spreadsheetId }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to load from Google Sheets');
    }
    return await res.json();
  }
};
